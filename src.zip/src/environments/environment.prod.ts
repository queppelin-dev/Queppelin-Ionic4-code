export const environment = {
  production: true,
  baseUrl: 'http://52.28.122.46/api/'
};
