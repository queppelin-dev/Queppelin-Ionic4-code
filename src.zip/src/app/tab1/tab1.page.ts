import { Component } from '@angular/core';
import { Platform, NavController } from '@ionic/angular';
import { LanguagePopoverPage } from '../language-popover/language-popover.page';
import { PopoverController, AlertController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
//import { Events } from 'ionic-angular';
import { BusinessService } from '../services/business.service';
import { Business } from '../models/business';
import { Observable } from 'rxjs';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  public favwithlist: boolean = false;
  public favwithoutlist: boolean = true;
  public language: string;
  public themes: string = 'black';
  public businessList: Business;
  public categorys: any;
  //public businessData:Business;
  public businessData: any = [];
  public customData: any = [];
  public customDatas: any = [];
  public categorylistData: any = [];
  public categorylistDatas: any = [];
  public businessDatas: any = [];
  public position: boolean = false;
  public rating: any;
  public apiRating: any;
  public categoryData: any = {};
  public businessCategoryServiceData = {};
  public conditionbusinesslist: any;
  public businessDetails: any = {};
  public categorybusinessDetails: any = {};
  public userDetails: any = {};
  public businessfavData: any = {};
  public businessfavwithoutlist: any;
  public businessfavwithlist: any;
  public categorylist: any = {};
  public currentlocation: any;
  public categories: any = [];
  public image1: any;
  public afterlogin:boolean = false;
  public appointmentlist:any ={};
  public aferappointment:boolean = false;
  public firstTimeLogin:any;
  // public Math.round(parseFloat(rating)="3.2";
  constructor(public platform: Platform,
    private translate: TranslateService,
    private popoverCtrl: PopoverController,
    private alertCtrl: AlertController,
    public businessService: BusinessService,
    public navCtrl: NavController,
    public router: Router,
    private storage: Storage) {

    this.language = localStorage.getItem("language");
    this.themes = localStorage.getItem("themes");
    //this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
   // console.log('details', this.userDetails);
    this.currentlocation = JSON.parse(localStorage.getItem("latLong"));
    if (this.language == 'ar') {
      document.documentElement.dir = 'rtl';
      this.position = true;
    }
    //  this.getBusinessList();
    this.getCategoryService();
    this.getcategorylist();
    this.getfavlistwithoutcustomer();

  }
  ionViewDidLoad() {
 
  }
  ngOnInit() {
    this.appointmentlist = JSON.parse(localStorage.getItem("appointmentlist"));
    if(this.appointmentlist){
      this.aferappointment = true;
      this.afterlogin = false;
      }
   //  alert(1)
    // if (this.userDetails) {
    //   alert(2)
    //   this.getfavlistwithcustomer();
    // }
  }
 
  ionViewDidEnter() {
    this.appointmentlist = JSON.parse(localStorage.getItem("appointmentlist"));
    this.firstTimeLogin = localStorage.getItem("firststTimeLogin");
    if(this.appointmentlist){
      this.afterlogin = false;
      this.aferappointment = true;
      }
    this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
   
    console.log('appointlist',this.appointmentlist)
    if (this.userDetails) {
      this.getfavlistwithcustomer();
      this.afterlogin = true;
    } else {
      this.businessfavwithlist = [];
    }
   
  } 

  ionViewDidLeave() {
    this.firstTimeLogin = "no";
    localStorage.setItem("firststTimeLogin", "no");
  }

  getfavlistwithoutcustomer() {

    this.businessService.favlistwithoutcustomer().subscribe((res: any) => {
      console.log(res);
      if (res.status == "success") {
        this.favwithoutlist = true;
        this.favwithlist = false;
        this.businessfavwithoutlist = res.data.user;
        console.log('favlist', this.businessfavwithoutlist);
        for (let i = 0; i < this.businessfavwithoutlist.length; i++) {
          localStorage.setItem("businessData", JSON.stringify(this.businessfavwithoutlist));
          var maxRating = 5;
          var apiRating = this.businessfavwithoutlist[i].review_count;
          this.businessfavwithoutlist[i].ratingPercent = Math.floor((apiRating / maxRating) * 100) + '%';

          if (this.currentlocation) {
            this.businessfavwithoutlist[i].distance = this.businessService.getDistanceFromLatLonInKm(this.currentlocation.lat, this.currentlocation.long, this.businessfavwithoutlist[i].latitude, this.businessfavwithoutlist[i].longitude);
          }
          // alert( this.businessList[i].ratingPercent)

        }
      }
    });
  }
  getfavlistwithcustomer() {
    this.businessfavData = {
      "user_id": this.userDetails.id,
      "role_id": this.userDetails.role_id,
      "token": this.userDetails.token.original.token
    }
    this.businessService.favlistwithcustomer(this.businessfavData).subscribe((res: any) => {
      console.log(res);
      if (res.status == "success") {
        this.favwithlist = true;
        this.favwithoutlist = false;
        this.businessfavwithlist = res.data.user;
        console.log('favlists', this.businessfavwithlist);
        for (let i = 0; i < this.businessfavwithlist.length; i++) {
          if (this.currentlocation) {
            this.businessfavwithlist[i].distance = this.businessService.getDistanceFromLatLonInKm(this.currentlocation.lat, this.currentlocation.long, this.businessfavwithlist[i].latitude, this.businessfavwithlist[i].longitude);
          }
          localStorage.setItem("businessData", JSON.stringify(this.businessfavwithlist));
          var maxRating = 5;
          var apiRating = this.businessfavwithlist[i].review_count;
          this.businessfavwithlist[i].ratingPercent = Math.floor((apiRating / maxRating) * 100) + '%';
          // alert( this.businessList[i].ratingPercent)

        }
      }
    });
  }
  getcategorylist() {

    this.businessService.categorylist().subscribe((res: any) => {
      console.log('catglist', res);
      if (res.status == "success") {
        this.categorylist = res.data.user;
        localStorage.setItem("categoryData", JSON.stringify(this.categorylist));
        var categorylistlength = this.categorylist.length / 2;
        console.log('length', categorylistlength);
        for (let i = 0; i < categorylistlength; i++) {

           if (this.categorylist[i].image != null) {

            // if (i % 2 == 0) {
              // console.log('lmnst', this.categorylist[i]);
              // this.categorylist[i].image1 = this.categorylist[i].image;
              // this.categorylist[i].name1 = this.categorylist[i].name;
              // console.log('image1', this.customData.image1)

              this.customData.push(this.categorylist[i]);
            // }
            // else if (i % 2 != 0) {
            //   this.categorylist[i].image2 = this.categorylist[i].image;
            //   this.categorylist[i].name2 = this.categorylist[i].name;
            //   this.customData.push(this.categorylist[i]);

            // }

           }
        }

        for (let i = categorylistlength; i < this.categorylist.length; i++) {
          if (this.categorylist[i].image != null) {
            this.categorylistDatas.push(this.categorylist[i]);
            console.log('catdata2', this.categorylistData)
          }

        }
      }

    });
  }

   gotoexplorepage(items:any) {
     console.log('items',items);
     localStorage.setItem("categoryID",items.id)
    //  let navigationExtras: NavigationExtras = {
    //    queryParams: {
    //     categoryId: items.id
    //    } 
    //  };
  
     //this.router.navigate(['tab2']);

    
     this.navCtrl.navigateForward('/tabs/tab2');
     //console.log('businessct', this.categorybusinessDetails)
   }
  /* getBusinessList() {
     this.businessService.businessList().subscribe((res : Business)=>{
       console.log(res);
       if(res.status == "success"){
          this.businessList = res.data.user;
          for( let i = 0; i < this.businessList.length; i++ ){
           
             if(this.businessList[i].name != null) {
              
               this.businessData.push(this.businessList[i]);
               localStorage.setItem("businessData", JSON.stringify(this.businessData));

               console.log(this.businessData);
               var maxRating = 5;
               var apiRating = this.businessList[i].review_count;
             this.businessList[i].ratingPercent = Math.floor((apiRating / maxRating) * 100)+'%';
              // alert( this.businessList[i].ratingPercent)
              
             }
          }
       }
     }); 
   }*/
  getCategoryService() {
    this.categoryData.categoryid;
    this.businessService.category(this.categoryData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'success') {
        this.categorys = res.data.user;
        console.log(this.categorys);
      }
    });
  }

  /* goToNotificationsPage() {
     this.navCtrl.navigateForward('/notifications');
   }*/
  onRateChange(event) {
    console.log('Your rate:', event);
    this.rating = event;
  }
  goToDetailsPage(item: any) {
    console.log('item', item);

    let navigationExtras: NavigationExtras = {
      queryParams: {
        businessDetails: JSON.stringify(item)

      }
    };
    this.router.navigate(['details-page'], navigationExtras);
    console.log('business', this.businessDetails)
  }
  Education() {
    this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 7 };
    this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'success') {
        this.conditionbusinesslist = res.data.user;
        localStorage.setItem("conditionbusinesslisteducation", JSON.stringify(res.data.user));
        this.navCtrl.navigateForward('/tabs/tab2');
      }
    });
  }
  Salon() {
    this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 4 };
    this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'success') {
        this.conditionbusinesslist = res.data.user;
        localStorage.setItem("conditionbusinesslistsalon", JSON.stringify(res.data.user));
        this.navCtrl.navigateForward('/tabs/tab2');
      }
    });
  }
  Medicine() {
    this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 3 };
    this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'success') {
        this.conditionbusinesslist = res.data.user;
        this.navCtrl.navigateForward('/tabs/tab2');
      }
    });
  }
  Fitness() {
    this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 5 };
    this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'success') {
        this.conditionbusinesslist = res.data.user;
        this.navCtrl.navigateForward('/tabs/tab2');
      }
    });
  }
  Health() {
    this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 12 };
    this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'success') {
        this.conditionbusinesslist = res.data.user;
        this.navCtrl.navigateForward('/tabs/tab2');
      }
    });
  }
  Other() {
    this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 9 };
    this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'success') {
        this.conditionbusinesslist = res.data.user;
        this.navCtrl.navigateForward('/tabs/tab2');
      }
    });
  }
  Professional() {
    this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 9 };
    this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'success') {
        this.conditionbusinesslist = res.data.user;
        this.navCtrl.navigateForward('/tabs/tab2');
      }
    });
  }
  Goverment() {
    this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 2 };
    this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe((res: any) => {
      console.log(res);
      if (res.status == 'success') {
        this.conditionbusinesslist = res.data.user;
        this.navCtrl.navigateForward('/tabs/tab2');
      }
    });
  }
}
