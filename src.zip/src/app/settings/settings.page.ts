import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserService } from '../services/user.service';
import { DetailsPagePage } from '../details-page/details-page.page';
import { LanguagePopoverPage } from '../language-popover/language-popover.page';
import { PopoverController, AlertController } from '@ionic/angular';
import { LanguageService } from './../language.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
  styleUrls: ['./settings.page.scss'],
})
export class SettingsPage implements OnInit {
  public personalinformationsData:any = {};
  public personalinformations:any = {};
  public userDetails:any ={};
  public checked:boolean = true;
  public abc:any={};
  public language: string;
  languages = [];
  selected = '';
  constructor( private translate: TranslateService,
               public userService: UserService,
               private popoverCtrl: PopoverController,
                private alertCtrl: AlertController,
                private languageService: LanguageService) { 
                this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
                console.log( this.userDetails);
               
          
               }

  ngOnInit() {
    this.getPersonalInformation();
    // this.languages = this.languageService.getLanguages();
    // this.selected = this.languageService.selected;
  }
  ionViewDidEnter() {
   // this.language = localStorage.getItem("language");
  //  this.languages = this.languageService.getLanguages();
  //  this.selected = this.languageService.selected;
  //   if(this.language == 'ar') {
  //     document.documentElement.dir = 'rtl';
  //   } 
  //   else if(this.language == 'en'){
  //     document.documentElement.dir = 'ltr';
  //   }
  }
 getPersonalInformation() {
    if(this.userDetails){
    this.personalinformationsData = {
     "user_id": this.userDetails.id,
      "role_id": this.userDetails.role_id,
    "token":this.userDetails.token.original.token
   };
   console.log(this.personalinformationsData);
  }
  this.userService.personalInformation(this.personalinformationsData).subscribe((res:any)=>{
    console.log(res);
    if(res.status == 'success'){
      this.personalinformations = res.data.user.notification_setting;
    }

  });
  }
  changeToggle(personalinformations:any){
    console.log(personalinformations)
}
async openLanguagePopover(ev) {
  const popover = await this.popoverCtrl.create({
  component: LanguagePopoverPage,
  event: ev
  });
  await popover.present();
}

}
