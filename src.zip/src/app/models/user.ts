
export class User {
  name: string;
  first_name:string;
  last_name:string;
  email: string;
  password: string;
  confirmed: string;
  user: User[];
  status:string;
  data:any;
  mobileNum:number;
  message:string;
//user:any;
}
