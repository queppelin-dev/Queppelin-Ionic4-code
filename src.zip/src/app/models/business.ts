
export class Business {
  push(arg0: any) {
    throw new Error("Method not implemented.");
  }
  id: number;
  name: string;
  address:string;
  review: string;
  review_count: number;
  business_logo: string;
  image: string;
  status:string;
  user:[];
  data: any;
  length: number;
}
