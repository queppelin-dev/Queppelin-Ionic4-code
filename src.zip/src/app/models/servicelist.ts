export class ServiceList {
    id: number;
    name: string;
    price: number;
    duration: number;
    business_id: number;
    main_category_id:number;
    categoryid:number;
  user: ServiceList[];
  status:string;
  data:any;
}