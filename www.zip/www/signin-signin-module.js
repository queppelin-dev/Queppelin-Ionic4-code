(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["signin-signin-module"],{

/***/ "./node_modules/@ionic-native/facebook/ngx/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@ionic-native/facebook/ngx/index.js ***!
  \**********************************************************/
/*! exports provided: Facebook */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Facebook", function() { return Facebook; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic-native/core */ "./node_modules/@ionic-native/core/index.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var Facebook = /** @class */ (function (_super) {
    __extends(Facebook, _super);
    function Facebook() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.EVENTS = {
            EVENT_NAME_ACTIVATED_APP: 'fb_mobile_activate_app',
            EVENT_NAME_DEACTIVATED_APP: 'fb_mobile_deactivate_app',
            EVENT_NAME_SESSION_INTERRUPTIONS: 'fb_mobile_app_interruptions',
            EVENT_NAME_TIME_BETWEEN_SESSIONS: 'fb_mobile_time_between_sessions',
            EVENT_NAME_COMPLETED_REGISTRATION: 'fb_mobile_complete_registration',
            EVENT_NAME_VIEWED_CONTENT: 'fb_mobile_content_view',
            EVENT_NAME_SEARCHED: 'fb_mobile_search',
            EVENT_NAME_RATED: 'fb_mobile_rate',
            EVENT_NAME_COMPLETED_TUTORIAL: 'fb_mobile_tutorial_completion',
            EVENT_NAME_PUSH_TOKEN_OBTAINED: 'fb_mobile_obtain_push_token',
            EVENT_NAME_ADDED_TO_CART: 'fb_mobile_add_to_cart',
            EVENT_NAME_ADDED_TO_WISHLIST: 'fb_mobile_add_to_wishlist',
            EVENT_NAME_INITIATED_CHECKOUT: 'fb_mobile_initiated_checkout',
            EVENT_NAME_ADDED_PAYMENT_INFO: 'fb_mobile_add_payment_info',
            EVENT_NAME_PURCHASED: 'fb_mobile_purchase',
            EVENT_NAME_ACHIEVED_LEVEL: 'fb_mobile_level_achieved',
            EVENT_NAME_UNLOCKED_ACHIEVEMENT: 'fb_mobile_achievement_unlocked',
            EVENT_NAME_SPENT_CREDITS: 'fb_mobile_spent_credits',
            EVENT_PARAM_CURRENCY: 'fb_currency',
            EVENT_PARAM_REGISTRATION_METHOD: 'fb_registration_method',
            EVENT_PARAM_CONTENT_TYPE: 'fb_content_type',
            EVENT_PARAM_CONTENT_ID: 'fb_content_id',
            EVENT_PARAM_SEARCH_STRING: 'fb_search_string',
            EVENT_PARAM_SUCCESS: 'fb_success',
            EVENT_PARAM_MAX_RATING_VALUE: 'fb_max_rating_value',
            EVENT_PARAM_PAYMENT_INFO_AVAILABLE: 'fb_payment_info_available',
            EVENT_PARAM_NUM_ITEMS: 'fb_num_items',
            EVENT_PARAM_LEVEL: 'fb_level',
            EVENT_PARAM_DESCRIPTION: 'fb_description',
            EVENT_PARAM_SOURCE_APPLICATION: 'fb_mobile_launch_source',
            EVENT_PARAM_VALUE_YES: '1',
            EVENT_PARAM_VALUE_NO: '0'
        };
        return _this;
    }
    Facebook.prototype.login = function (permissions) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "login", {}, arguments); };
    Facebook.prototype.logout = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "logout", {}, arguments); };
    Facebook.prototype.getLoginStatus = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "getLoginStatus", {}, arguments); };
    Facebook.prototype.getAccessToken = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "getAccessToken", {}, arguments); };
    Facebook.prototype.showDialog = function (options) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "showDialog", {}, arguments); };
    Facebook.prototype.api = function (requestPath, permissions) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "api", {}, arguments); };
    Facebook.prototype.logEvent = function (name, params, valueToSum) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "logEvent", { "successIndex": 3, "errorIndex": 4 }, arguments); };
    Facebook.prototype.logPurchase = function (value, currency) { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "logPurchase", {}, arguments); };
    Facebook.prototype.getDeferredApplink = function () { return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["cordova"])(this, "getDeferredApplink", {}, arguments); };
    Facebook.pluginName = "Facebook";
    Facebook.plugin = "cordova-plugin-facebook4";
    Facebook.pluginRef = "facebookConnectPlugin";
    Facebook.repo = "https://github.com/jeduan/cordova-plugin-facebook4";
    Facebook.install = "ionic cordova plugin add cordova-plugin-facebook4 --variable APP_ID=\"123456789\" --variable APP_NAME=\"myApplication\"";
    Facebook.installVariables = ["APP_ID", "APP_NAME"];
    Facebook.platforms = ["Android", "iOS", "Browser"];
    Facebook = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])()
    ], Facebook);
    return Facebook;
}(_ionic_native_core__WEBPACK_IMPORTED_MODULE_1__["IonicNativePlugin"]));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL2ZhY2Vib29rL25neC9pbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLDhCQUFzQyxNQUFNLG9CQUFvQixDQUFDOztJQXFIMUMsNEJBQWlCOzs7UUFDN0MsWUFBTSxHQUFHO1lBQ1Asd0JBQXdCLEVBQUUsd0JBQXdCO1lBQ2xELDBCQUEwQixFQUFFLDBCQUEwQjtZQUN0RCxnQ0FBZ0MsRUFBRSw2QkFBNkI7WUFDL0QsZ0NBQWdDLEVBQUUsaUNBQWlDO1lBQ25FLGlDQUFpQyxFQUFFLGlDQUFpQztZQUNwRSx5QkFBeUIsRUFBRSx3QkFBd0I7WUFDbkQsbUJBQW1CLEVBQUUsa0JBQWtCO1lBQ3ZDLGdCQUFnQixFQUFFLGdCQUFnQjtZQUNsQyw2QkFBNkIsRUFBRSwrQkFBK0I7WUFDOUQsOEJBQThCLEVBQUUsNkJBQTZCO1lBQzdELHdCQUF3QixFQUFFLHVCQUF1QjtZQUNqRCw0QkFBNEIsRUFBRSwyQkFBMkI7WUFDekQsNkJBQTZCLEVBQUUsOEJBQThCO1lBQzdELDZCQUE2QixFQUFFLDRCQUE0QjtZQUMzRCxvQkFBb0IsRUFBRSxvQkFBb0I7WUFDMUMseUJBQXlCLEVBQUUsMEJBQTBCO1lBQ3JELCtCQUErQixFQUFFLGdDQUFnQztZQUNqRSx3QkFBd0IsRUFBRSx5QkFBeUI7WUFDbkQsb0JBQW9CLEVBQUUsYUFBYTtZQUNuQywrQkFBK0IsRUFBRSx3QkFBd0I7WUFDekQsd0JBQXdCLEVBQUUsaUJBQWlCO1lBQzNDLHNCQUFzQixFQUFFLGVBQWU7WUFDdkMseUJBQXlCLEVBQUUsa0JBQWtCO1lBQzdDLG1CQUFtQixFQUFFLFlBQVk7WUFDakMsNEJBQTRCLEVBQUUscUJBQXFCO1lBQ25ELGtDQUFrQyxFQUFFLDJCQUEyQjtZQUMvRCxxQkFBcUIsRUFBRSxjQUFjO1lBQ3JDLGlCQUFpQixFQUFFLFVBQVU7WUFDN0IsdUJBQXVCLEVBQUUsZ0JBQWdCO1lBQ3pDLDhCQUE4QixFQUFFLHlCQUF5QjtZQUN6RCxxQkFBcUIsRUFBRSxHQUFHO1lBQzFCLG9CQUFvQixFQUFFLEdBQUc7U0FDMUIsQ0FBQzs7O0lBd0JGLHdCQUFLLGFBQUMsV0FBcUI7SUFXM0IseUJBQU07SUErQk4saUNBQWM7SUFVZCxpQ0FBYztJQXNCZCw2QkFBVSxhQUFDLE9BQVk7SUFrQnZCLHNCQUFHLGFBQUMsV0FBbUIsRUFBRSxXQUFxQjtJQWdCOUMsMkJBQVEsYUFBQyxJQUFZLEVBQUUsTUFBZSxFQUFFLFVBQW1CO0lBWTNELDhCQUFXLGFBQUMsS0FBYSxFQUFFLFFBQWdCO0lBUzNDLHFDQUFrQjs7Ozs7Ozs7SUEzTFAsUUFBUTtRQURwQixVQUFVLEVBQUU7T0FDQSxRQUFRO21CQXRIckI7RUFzSDhCLGlCQUFpQjtTQUFsQyxRQUFRIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29yZG92YSwgSW9uaWNOYXRpdmVQbHVnaW4sIFBsdWdpbiB9IGZyb20gJ0Bpb25pYy1uYXRpdmUvY29yZSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgRmFjZWJvb2tMb2dpblJlc3BvbnNlIHtcbiAgc3RhdHVzOiBzdHJpbmc7XG5cbiAgYXV0aFJlc3BvbnNlOiB7XG4gICAgc2Vzc2lvbl9rZXk6IGJvb2xlYW47XG5cbiAgICBhY2Nlc3NUb2tlbjogc3RyaW5nO1xuXG4gICAgZXhwaXJlc0luOiBudW1iZXI7XG5cbiAgICBzaWc6IHN0cmluZztcblxuICAgIHNlY3JldDogc3RyaW5nO1xuXG4gICAgdXNlcklEOiBzdHJpbmc7XG4gIH07XG59XG5cbi8qKlxuICogQG5hbWUgRmFjZWJvb2tcbiAqIEBkZXNjcmlwdGlvblxuICogVXNlIHRoZSBGYWNlYm9vayBDb25uZWN0IHBsdWdpbiB0byBvYnRhaW4gYWNjZXNzIHRvIHRoZSBuYXRpdmUgRkIgYXBwbGljYXRpb24gb24gaU9TIGFuZCBBbmRyb2lkLlxuICpcbiAqIFJlcXVpcmVzIENvcmRvdmEgcGx1Z2luOiBgY29yZG92YS1wbHVnaW4tZmFjZWJvb2s0YC4gRm9yIG1vcmUgaW5mbywgcGxlYXNlIHNlZSB0aGUgW0ZhY2Vib29rIENvbm5lY3RdKGh0dHBzOi8vZ2l0aHViLmNvbS9qZWR1YW4vY29yZG92YS1wbHVnaW4tZmFjZWJvb2s0KS5cbiAqXG4gKiAjIyMjIEluc3RhbGxhdGlvblxuICpcbiAqICBUbyB1c2UgdGhlIEZCIHBsdWdpbiwgeW91IGZpcnN0IGhhdmUgdG8gY3JlYXRlIGEgbmV3IEZhY2Vib29rIEFwcCBpbnNpZGUgb2YgdGhlIEZhY2Vib29rIGRldmVsb3BlciBwb3J0YWwgYXQgW2h0dHBzOi8vZGV2ZWxvcGVycy5mYWNlYm9vay5jb20vYXBwc10oaHR0cHM6Ly9kZXZlbG9wZXJzLmZhY2Vib29rLmNvbS9hcHBzKS5cbiAqXG4gKiBbIVtmYi1nZXRzdGFydGVkLTFdKC9pbWcvZG9jcy9uYXRpdmUvRmFjZWJvb2svMS5wbmcpXShodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2FwcHMvKVxuICpcbiAqIFJldHJpZXZlIHRoZSBgQXBwIElEYCBhbmQgYEFwcCBOYW1lYC5cbiAqXG4gKiBbIVtmYi1nZXRzdGFydGVkLTJdKC9pbWcvZG9jcy9uYXRpdmUvRmFjZWJvb2svMi5wbmcpXShodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2FwcHMvKVxuICpcbiAqIFRoZW4gdHlwZSBpbiB0aGUgZm9sbG93aW5nIGNvbW1hbmQgaW4geW91ciBUZXJtaW5hbCwgd2hlcmUgQVBQX0lEIGFuZCBBUFBfTkFNRSBhcmUgdGhlIHZhbHVlcyBmcm9tIHRoZSBGYWNlYm9vayBEZXZlbG9wZXIgcG9ydGFsLlxuICpcbiAqIGBgYGJhc2hcbiAqICBpb25pYyBjb3Jkb3ZhIHBsdWdpbiBhZGQgY29yZG92YS1wbHVnaW4tZmFjZWJvb2s0IC0tdmFyaWFibGUgQVBQX0lEPVwiMTIzNDU2Nzg5XCIgLS12YXJpYWJsZSBBUFBfTkFNRT1cIm15QXBwbGljYXRpb25cIlxuICogYGBgXG4gKlxuICogQWZ0ZXIsIHlvdSdsbCBuZWVkIHRvIGFkZCB0aGUgbmF0aXZlIHBsYXRmb3JtcyB5b3UnbGwgYmUgdXNpbmcgdG8geW91ciBhcHAgaW4gdGhlIEZhY2Vib29rIERldmVsb3BlciBwb3J0YWwgdW5kZXIgeW91ciBhcHAncyBTZXR0aW5nczpcbiAqXG4gKiBbIVtmYi1nZXRzdGFydGVkLTNdKC9pbWcvZG9jcy9uYXRpdmUvRmFjZWJvb2svMy5wbmcpXShodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2FwcHMvKVxuICpcbiAqIENsaWNrIGAnQWRkIFBsYXRmb3JtJ2AuXG4gKlxuICogWyFbZmItZ2V0c3RhcnRlZC00XSgvaW1nL2RvY3MvbmF0aXZlL0ZhY2Vib29rLzQucG5nKV0oaHR0cHM6Ly9kZXZlbG9wZXJzLmZhY2Vib29rLmNvbS9hcHBzLylcbiAqXG4gKiBBdCB0aGlzIHBvaW50IHlvdSdsbCBuZWVkIHRvIG9wZW4geW91ciBwcm9qZWN0J3MgW2Bjb25maWcueG1sYF0oaHR0cHM6Ly9jb3Jkb3ZhLmFwYWNoZS5vcmcvZG9jcy9lbi9sYXRlc3QvY29uZmlnX3JlZi9pbmRleC5odG1sKSBmaWxlLCBmb3VuZCBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgeW91ciBwcm9qZWN0LlxuICpcbiAqIFRha2Ugbm90ZSBvZiB0aGUgYGlkYCBmb3IgdGhlIG5leHQgc3RlcDpcbiAqIGBgYFxuICogPHdpZGdldCBpZD1cImNvbS5teWNvbXBhbnkudGVzdGFwcFwiIHZlcnNpb249XCIwLjAuMVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvbnMvd2lkZ2V0c1wiIHhtbG5zOmNkdj1cImh0dHA6Ly9jb3Jkb3ZhLmFwYWNoZS5vcmcvbnMvMS4wXCI+XG4gKiBgYGBcbiAqXG4gKiBZb3UgY2FuIGFsc28gZWRpdCB0aGUgYGlkYCB0byB3aGF0ZXZlciB5b3UnZCBsaWtlIGl0IHRvIGJlLlxuICpcbiAqICMjIyMgaU9TIEluc3RhbGxcbiAqIFVuZGVyICdCdW5kbGUgSUQnLCBhZGQgdGhlIGBpZGAgZnJvbSB5b3VyIGBjb25maWcueG1sYCBmaWxlOlxuICpcbiAqIFshW2ZiLWdldHN0YXJ0ZWQtNV0oL2ltZy9kb2NzL25hdGl2ZS9GYWNlYm9vay81LnBuZyldKGh0dHBzOi8vZGV2ZWxvcGVycy5mYWNlYm9vay5jb20vYXBwcy8pXG4gKlxuICpcbiAqICMjIyMgQW5kcm9pZCBJbnN0YWxsXG4gKiBVbmRlciAnR29vZ2xlIFBsYXkgUGFja2FnZSBOYW1lJywgYWRkIHRoZSBgaWRgIGZyb20geW91ciBgY29uZmlnLnhtbGAgZmlsZTpcbiAqXG4gKiBbIVtmYi1nZXRzdGFydGVkLTZdKC9pbWcvZG9jcy9uYXRpdmUvRmFjZWJvb2svNi5wbmcpXShodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2FwcHMvKVxuICpcbiAqXG4gKiBBbmQgdGhhdCdzIGl0ISBZb3UgY2FuIG5vdyBtYWtlIGNhbGxzIHRvIEZhY2Vib29rIHVzaW5nIHRoZSBwbHVnaW4uXG4gKlxuICogIyMgRXZlbnRzXG4gKlxuICogQXBwIGV2ZW50cyBhbGxvdyB5b3UgdG8gdW5kZXJzdGFuZCB0aGUgbWFrZXVwIG9mIHVzZXJzIGVuZ2FnaW5nIHdpdGggeW91ciBhcHAsIG1lYXN1cmUgdGhlIHBlcmZvcm1hbmNlIG9mIHlvdXIgRmFjZWJvb2sgbW9iaWxlIGFwcCBhZHMsIGFuZCByZWFjaCBzcGVjaWZpYyBzZXRzIG9mIHlvdXIgdXNlcnMgd2l0aCBGYWNlYm9vayBtb2JpbGUgYXBwIGFkcy5cbiAqXG4gKiAtIFtpT1NdIFtodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2RvY3MvaW9zL2FwcC1ldmVudHNdKGh0dHBzOi8vZGV2ZWxvcGVycy5mYWNlYm9vay5jb20vZG9jcy9pb3MvYXBwLWV2ZW50cylcbiAqIC0gW0FuZHJvaWRdIFtodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2RvY3MvYW5kcm9pZC9hcHAtZXZlbnRzXShodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2RvY3MvYW5kcm9pZC9hcHAtZXZlbnRzKVxuICogLSBbSlNdIERvZXMgbm90IGhhdmUgYW4gRXZlbnRzIEFQSSwgc28gdGhlIHBsdWdpbiBmdW5jdGlvbnMgYXJlIGVtcHR5IGFuZCB3aWxsIHJldHVybiBhbiBhdXRvbWF0aWMgc3VjY2Vzc1xuICpcbiAqIEFjdGl2YXRpb24gZXZlbnRzIGFyZSBhdXRvbWF0aWNhbGx5IHRyYWNrZWQgZm9yIHlvdSBpbiB0aGUgcGx1Z2luLlxuICpcbiAqIEV2ZW50cyBhcmUgbGlzdGVkIG9uIHRoZSBbaW5zaWdodHMgcGFnZV0oaHR0cHM6Ly93d3cuZmFjZWJvb2suY29tL2luc2lnaHRzLykuXG4gKlxuICogRm9yIHRyYWNraW5nIGV2ZW50cywgc2VlIGBsb2dFdmVudGAgYW5kIGBsb2dQdXJjaGFzZWAuXG4gKlxuICogQHVzYWdlXG4gKiBgYGB0eXBlc2NyaXB0XG4gKiBpbXBvcnQgeyBGYWNlYm9vaywgRmFjZWJvb2tMb2dpblJlc3BvbnNlIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9mYWNlYm9vay9uZ3gnO1xuICpcbiAqIGNvbnN0cnVjdG9yKHByaXZhdGUgZmI6IEZhY2Vib29rKSB7IH1cbiAqXG4gKiAuLi5cbiAqXG4gKiB0aGlzLmZiLmxvZ2luKFsncHVibGljX3Byb2ZpbGUnLCAndXNlcl9mcmllbmRzJywgJ2VtYWlsJ10pXG4gKiAgIC50aGVuKChyZXM6IEZhY2Vib29rTG9naW5SZXNwb25zZSkgPT4gY29uc29sZS5sb2coJ0xvZ2dlZCBpbnRvIEZhY2Vib29rIScsIHJlcykpXG4gKiAgIC5jYXRjaChlID0+IGNvbnNvbGUubG9nKCdFcnJvciBsb2dnaW5nIGludG8gRmFjZWJvb2snLCBlKSk7XG4gKlxuICpcbiAqIHRoaXMuZmIubG9nRXZlbnQodGhpcy5mYi5FVkVOVFMuRVZFTlRfTkFNRV9BRERFRF9UT19DQVJUKTtcbiAqXG4gKiBgYGBcbiAqXG4gKi9cbkBQbHVnaW4oe1xuICBwbHVnaW5OYW1lOiAnRmFjZWJvb2snLFxuICBwbHVnaW46ICdjb3Jkb3ZhLXBsdWdpbi1mYWNlYm9vazQnLFxuICBwbHVnaW5SZWY6ICdmYWNlYm9va0Nvbm5lY3RQbHVnaW4nLFxuICByZXBvOiAnaHR0cHM6Ly9naXRodWIuY29tL2plZHVhbi9jb3Jkb3ZhLXBsdWdpbi1mYWNlYm9vazQnLFxuICBpbnN0YWxsOlxuICAgICdpb25pYyBjb3Jkb3ZhIHBsdWdpbiBhZGQgY29yZG92YS1wbHVnaW4tZmFjZWJvb2s0IC0tdmFyaWFibGUgQVBQX0lEPVwiMTIzNDU2Nzg5XCIgLS12YXJpYWJsZSBBUFBfTkFNRT1cIm15QXBwbGljYXRpb25cIicsXG4gIGluc3RhbGxWYXJpYWJsZXM6IFsnQVBQX0lEJywgJ0FQUF9OQU1FJ10sXG4gIHBsYXRmb3JtczogWydBbmRyb2lkJywgJ2lPUycsICdCcm93c2VyJ11cbn0pXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgRmFjZWJvb2sgZXh0ZW5kcyBJb25pY05hdGl2ZVBsdWdpbiB7XG4gIEVWRU5UUyA9IHtcbiAgICBFVkVOVF9OQU1FX0FDVElWQVRFRF9BUFA6ICdmYl9tb2JpbGVfYWN0aXZhdGVfYXBwJyxcbiAgICBFVkVOVF9OQU1FX0RFQUNUSVZBVEVEX0FQUDogJ2ZiX21vYmlsZV9kZWFjdGl2YXRlX2FwcCcsXG4gICAgRVZFTlRfTkFNRV9TRVNTSU9OX0lOVEVSUlVQVElPTlM6ICdmYl9tb2JpbGVfYXBwX2ludGVycnVwdGlvbnMnLFxuICAgIEVWRU5UX05BTUVfVElNRV9CRVRXRUVOX1NFU1NJT05TOiAnZmJfbW9iaWxlX3RpbWVfYmV0d2Vlbl9zZXNzaW9ucycsXG4gICAgRVZFTlRfTkFNRV9DT01QTEVURURfUkVHSVNUUkFUSU9OOiAnZmJfbW9iaWxlX2NvbXBsZXRlX3JlZ2lzdHJhdGlvbicsXG4gICAgRVZFTlRfTkFNRV9WSUVXRURfQ09OVEVOVDogJ2ZiX21vYmlsZV9jb250ZW50X3ZpZXcnLFxuICAgIEVWRU5UX05BTUVfU0VBUkNIRUQ6ICdmYl9tb2JpbGVfc2VhcmNoJyxcbiAgICBFVkVOVF9OQU1FX1JBVEVEOiAnZmJfbW9iaWxlX3JhdGUnLFxuICAgIEVWRU5UX05BTUVfQ09NUExFVEVEX1RVVE9SSUFMOiAnZmJfbW9iaWxlX3R1dG9yaWFsX2NvbXBsZXRpb24nLFxuICAgIEVWRU5UX05BTUVfUFVTSF9UT0tFTl9PQlRBSU5FRDogJ2ZiX21vYmlsZV9vYnRhaW5fcHVzaF90b2tlbicsXG4gICAgRVZFTlRfTkFNRV9BRERFRF9UT19DQVJUOiAnZmJfbW9iaWxlX2FkZF90b19jYXJ0JyxcbiAgICBFVkVOVF9OQU1FX0FEREVEX1RPX1dJU0hMSVNUOiAnZmJfbW9iaWxlX2FkZF90b193aXNobGlzdCcsXG4gICAgRVZFTlRfTkFNRV9JTklUSUFURURfQ0hFQ0tPVVQ6ICdmYl9tb2JpbGVfaW5pdGlhdGVkX2NoZWNrb3V0JyxcbiAgICBFVkVOVF9OQU1FX0FEREVEX1BBWU1FTlRfSU5GTzogJ2ZiX21vYmlsZV9hZGRfcGF5bWVudF9pbmZvJyxcbiAgICBFVkVOVF9OQU1FX1BVUkNIQVNFRDogJ2ZiX21vYmlsZV9wdXJjaGFzZScsXG4gICAgRVZFTlRfTkFNRV9BQ0hJRVZFRF9MRVZFTDogJ2ZiX21vYmlsZV9sZXZlbF9hY2hpZXZlZCcsXG4gICAgRVZFTlRfTkFNRV9VTkxPQ0tFRF9BQ0hJRVZFTUVOVDogJ2ZiX21vYmlsZV9hY2hpZXZlbWVudF91bmxvY2tlZCcsXG4gICAgRVZFTlRfTkFNRV9TUEVOVF9DUkVESVRTOiAnZmJfbW9iaWxlX3NwZW50X2NyZWRpdHMnLFxuICAgIEVWRU5UX1BBUkFNX0NVUlJFTkNZOiAnZmJfY3VycmVuY3knLFxuICAgIEVWRU5UX1BBUkFNX1JFR0lTVFJBVElPTl9NRVRIT0Q6ICdmYl9yZWdpc3RyYXRpb25fbWV0aG9kJyxcbiAgICBFVkVOVF9QQVJBTV9DT05URU5UX1RZUEU6ICdmYl9jb250ZW50X3R5cGUnLFxuICAgIEVWRU5UX1BBUkFNX0NPTlRFTlRfSUQ6ICdmYl9jb250ZW50X2lkJyxcbiAgICBFVkVOVF9QQVJBTV9TRUFSQ0hfU1RSSU5HOiAnZmJfc2VhcmNoX3N0cmluZycsXG4gICAgRVZFTlRfUEFSQU1fU1VDQ0VTUzogJ2ZiX3N1Y2Nlc3MnLFxuICAgIEVWRU5UX1BBUkFNX01BWF9SQVRJTkdfVkFMVUU6ICdmYl9tYXhfcmF0aW5nX3ZhbHVlJyxcbiAgICBFVkVOVF9QQVJBTV9QQVlNRU5UX0lORk9fQVZBSUxBQkxFOiAnZmJfcGF5bWVudF9pbmZvX2F2YWlsYWJsZScsXG4gICAgRVZFTlRfUEFSQU1fTlVNX0lURU1TOiAnZmJfbnVtX2l0ZW1zJyxcbiAgICBFVkVOVF9QQVJBTV9MRVZFTDogJ2ZiX2xldmVsJyxcbiAgICBFVkVOVF9QQVJBTV9ERVNDUklQVElPTjogJ2ZiX2Rlc2NyaXB0aW9uJyxcbiAgICBFVkVOVF9QQVJBTV9TT1VSQ0VfQVBQTElDQVRJT046ICdmYl9tb2JpbGVfbGF1bmNoX3NvdXJjZScsXG4gICAgRVZFTlRfUEFSQU1fVkFMVUVfWUVTOiAnMScsXG4gICAgRVZFTlRfUEFSQU1fVkFMVUVfTk86ICcwJ1xuICB9O1xuXG4gIC8qKlxuICAgKiBMb2dpbiB0byBGYWNlYm9vayB0byBhdXRoZW50aWNhdGUgdGhpcyBhcHAuXG4gICAqXG4gICAqIGBgYHR5cGVzY3JpcHRcbiAgICoge1xuICAgKiAgIHN0YXR1czogJ2Nvbm5lY3RlZCcsXG4gICAqICAgYXV0aFJlc3BvbnNlOiB7XG4gICAqICAgICBzZXNzaW9uX2tleTogdHJ1ZSxcbiAgICogICAgIGFjY2Vzc1Rva2VuOiAna2draDNnNDJraDRnMjNraDRnMmtoMzRnMmtnNGsyaDRna2gzZzRrMmg0Z2syM2g0Z2syaDM0Z2syMzRnazJoMzRBbmRTb09uJyxcbiAgICogICAgIGV4cGlyZXNJbjogNTE4Mzk3OSxcbiAgICogICAgIHNpZzogJy4uLicsXG4gICAqICAgICBzZWNyZXQ6ICcuLi4nLFxuICAgKiAgICAgdXNlcklEOiAnNjM0NTY1NDM1J1xuICAgKiAgIH1cbiAgICogfVxuICAgKlxuICAgKiBgYGBcbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gIHBlcm1pc3Npb25zIExpc3Qgb2YgW3Blcm1pc3Npb25zXShodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2RvY3MvZmFjZWJvb2stbG9naW4vcGVybWlzc2lvbnMpIHRoaXMgYXBwIGhhcyB1cG9uIGxvZ2dpbmcgaW4uXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPEZhY2Vib29rTG9naW5SZXNwb25zZT59IFJldHVybnMgYSBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCBhIHN0YXR1cyBvYmplY3QgaWYgbG9naW4gc3VjY2VlZHMsIGFuZCByZWplY3RzIGlmIGxvZ2luIGZhaWxzLlxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBsb2dpbihwZXJtaXNzaW9uczogc3RyaW5nW10pOiBQcm9taXNlPEZhY2Vib29rTG9naW5SZXNwb25zZT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBMb2dvdXQgb2YgRmFjZWJvb2suXG4gICAqXG4gICAqIEZvciBtb3JlIGluZm8gc2VlIHRoZSBbRmFjZWJvb2sgZG9jc10oaHR0cHM6Ly9kZXZlbG9wZXJzLmZhY2Vib29rLmNvbS9kb2NzL3JlZmVyZW5jZS9qYXZhc2NyaXB0L0ZCLmxvZ291dClcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn0gUmV0dXJucyBhIFByb21pc2UgdGhhdCByZXNvbHZlcyBvbiBhIHN1Y2Nlc3NmdWwgbG9nb3V0LCBhbmQgcmVqZWN0cyBpZiBsb2dvdXQgZmFpbHMuXG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGxvZ291dCgpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZXRlcm1pbmUgaWYgYSB1c2VyIGlzIGxvZ2dlZCBpbiB0byBGYWNlYm9vayBhbmQgaGFzIGF1dGhlbnRpY2F0ZWQgeW91ciBhcHAuICBUaGVyZSBhcmUgdGhyZWUgcG9zc2libGUgc3RhdGVzIGZvciBhIHVzZXI6XG4gICAqXG4gICAqIDEpIHRoZSB1c2VyIGlzIGxvZ2dlZCBpbnRvIEZhY2Vib29rIGFuZCBoYXMgYXV0aGVudGljYXRlZCB5b3VyIGFwcGxpY2F0aW9uIChjb25uZWN0ZWQpXG4gICAqIDIpIHRoZSB1c2VyIGlzIGxvZ2dlZCBpbnRvIEZhY2Vib29rIGJ1dCBoYXMgbm90IGF1dGhlbnRpY2F0ZWQgeW91ciBhcHBsaWNhdGlvbiAobm90X2F1dGhvcml6ZWQpXG4gICAqIDMpIHRoZSB1c2VyIGlzIGVpdGhlciBub3QgbG9nZ2VkIGludG8gRmFjZWJvb2sgb3IgZXhwbGljaXRseSBsb2dnZWQgb3V0IG9mIHlvdXIgYXBwbGljYXRpb24gc28gaXQgZG9lc24ndCBhdHRlbXB0IHRvIGNvbm5lY3QgdG8gRmFjZWJvb2sgYW5kIHRodXMsIHdlIGRvbid0IGtub3cgaWYgdGhleSd2ZSBhdXRoZW50aWNhdGVkIHlvdXIgYXBwbGljYXRpb24gb3Igbm90ICh1bmtub3duKVxuICAgKlxuICAgKiBSZXNvbHZlcyB3aXRoIGEgcmVzcG9uc2UgbGlrZTpcbiAgICpcbiAgICogYGBgXG4gICAqIHtcbiAgICogICBhdXRoUmVzcG9uc2U6IHtcbiAgICogICAgIHVzZXJJRDogJzEyMzQ1Njc4OTEyMzQ1JyxcbiAgICogICAgIGFjY2Vzc1Rva2VuOiAna2draDNnNDJraDRnMjNraDRnMmtoMzRnMmtnNGsyaDRna2gzZzRrMmg0Z2syM2g0Z2syaDM0Z2syMzRnazJoMzRBbmRTb09uJyxcbiAgICogICAgIHNlc3Npb25fS2V5OiB0cnVlLFxuICAgKiAgICAgZXhwaXJlc0luOiAnNTE4MzczOCcsXG4gICAqICAgICBzaWc6ICcuLi4nXG4gICAqICAgfSxcbiAgICogICBzdGF0dXM6ICdjb25uZWN0ZWQnXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIEZvciBtb3JlIGluZm9ybWF0aW9uIHNlZSB0aGUgW0ZhY2Vib29rIGRvY3NdKGh0dHBzOi8vZGV2ZWxvcGVycy5mYWNlYm9vay5jb20vZG9jcy9yZWZlcmVuY2UvamF2YXNjcmlwdC9GQi5nZXRMb2dpblN0YXR1cylcbiAgICpcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn0gUmV0dXJucyBhIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIGEgc3RhdHVzLCBvciByZWplY3RzIHdpdGggYW4gZXJyb3JcbiAgICovXG4gIEBDb3Jkb3ZhKClcbiAgZ2V0TG9naW5TdGF0dXMoKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogR2V0IGEgRmFjZWJvb2sgYWNjZXNzIHRva2VuIGZvciB1c2luZyBGYWNlYm9vayBzZXJ2aWNlcy5cbiAgICpcbiAgICogQHJldHVybnMge1Byb21pc2U8c3RyaW5nPn0gUmV0dXJucyBhIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIGFuIGFjY2VzcyB0b2tlbiwgb3IgcmVqZWN0cyB3aXRoIGFuIGVycm9yXG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGdldEFjY2Vzc1Rva2VuKCk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFNob3cgb25lIG9mIHZhcmlvdXMgRmFjZWJvb2sgZGlhbG9ncy4gRXhhbXBsZSBvZiBvcHRpb25zIGZvciBhIFNoYXJlIGRpYWxvZzpcbiAgICpcbiAgICogYGBgXG4gICAqIHtcbiAgICogICBtZXRob2Q6ICdzaGFyZScsXG4gICAqICAgaHJlZjogJ2h0dHA6Ly9leGFtcGxlLmNvbScsXG4gICAqICAgY2FwdGlvbjogJ1N1Y2ggY2FwdGlvbiwgdmVyeSBmZWVkLicsXG4gICAqICAgZGVzY3JpcHRpb246ICdNdWNoIGRlc2NyaXB0aW9uJyxcbiAgICogICBwaWN0dXJlOiAnaHR0cDovL2V4YW1wbGUuY29tL2ltYWdlLnBuZydcbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogRm9yIG1vcmUgb3B0aW9ucyBzZWUgdGhlIFtDb3Jkb3ZhIHBsdWdpbiBkb2NzXShodHRwczovL2dpdGh1Yi5jb20vamVkdWFuL2NvcmRvdmEtcGx1Z2luLWZhY2Vib29rNCNzaG93LWEtZGlhbG9nKSBhbmQgdGhlIFtGYWNlYm9vayBkb2NzXShodHRwczovL2RldmVsb3BlcnMuZmFjZWJvb2suY29tL2RvY3MvamF2YXNjcmlwdC9yZWZlcmVuY2UvRkIudWkpXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIFRoZSBkaWFsb2cgb3B0aW9uc1xuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fSBSZXR1cm5zIGEgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggc3VjY2VzcyBkYXRhLCBvciByZWplY3RzIHdpdGggYW4gZXJyb3JcbiAgICovXG4gIEBDb3Jkb3ZhKClcbiAgc2hvd0RpYWxvZyhvcHRpb25zOiBhbnkpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBNYWtlIGEgY2FsbCB0byBGYWNlYm9vayBHcmFwaCBBUEkuIENhbiB0YWtlIGFkZGl0aW9uYWwgcGVybWlzc2lvbnMgYmV5b25kIHRob3NlIGdyYW50ZWQgb24gbG9naW4uXG4gICAqXG4gICAqIEZvciBtb3JlIGluZm9ybWF0aW9uIHNlZTpcbiAgICpcbiAgICogIENhbGxpbmcgdGhlIEdyYXBoIEFQSSAtIGh0dHBzOi8vZGV2ZWxvcGVycy5mYWNlYm9vay5jb20vZG9jcy9qYXZhc2NyaXB0L3JlZmVyZW5jZS9GQi5hcGlcbiAgICogIEdyYXBoIEV4cGxvcmVyIC0gaHR0cHM6Ly9kZXZlbG9wZXJzLmZhY2Vib29rLmNvbS90b29scy9leHBsb3JlclxuICAgKiAgR3JhcGggQVBJIC0gaHR0cHM6Ly9kZXZlbG9wZXJzLmZhY2Vib29rLmNvbS9kb2NzL2dyYXBoLWFwaVxuICAgKlxuICAgKiBAcGFyYW0ge3N0cmluZ30gIHJlcXVlc3RQYXRoIEdyYXBoIEFQSSBlbmRwb2ludCB5b3Ugd2FudCB0byBjYWxsXG4gICAqIEBwYXJhbSB7c3RyaW5nW119ICBwZXJtaXNzaW9ucyBMaXN0IG9mIFtwZXJtaXNzaW9uc10oaHR0cHM6Ly9kZXZlbG9wZXJzLmZhY2Vib29rLmNvbS9kb2NzL2ZhY2Vib29rLWxvZ2luL3Blcm1pc3Npb25zKSBmb3IgdGhpcyByZXF1ZXN0LlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fSBSZXR1cm5zIGEgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHJlc3VsdCBvZiB0aGUgcmVxdWVzdCwgb3IgcmVqZWN0cyB3aXRoIGFuIGVycm9yXG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGFwaShyZXF1ZXN0UGF0aDogc3RyaW5nLCBwZXJtaXNzaW9uczogc3RyaW5nW10pOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBMb2cgYW4gZXZlbnQuICBGb3IgbW9yZSBpbmZvcm1hdGlvbiBzZWUgdGhlIEV2ZW50cyBzZWN0aW9uIGFib3ZlLlxuICAgKlxuICAgKiBAcGFyYW0ge3N0cmluZ30gIG5hbWUgTmFtZSBvZiB0aGUgZXZlbnRcbiAgICogQHBhcmFtIHtPYmplY3R9ICBbcGFyYW1zXSBBbiBvYmplY3QgY29udGFpbmluZyBleHRyYSBkYXRhIHRvIGxvZyB3aXRoIHRoZSBldmVudFxuICAgKiBAcGFyYW0ge251bWJlcn0gIFt2YWx1ZVRvU3VtXSBhbnkgdmFsdWUgdG8gYmUgYWRkZWQgdG8gYWRkZWQgdG8gYSBzdW0gb24gZWFjaCBldmVudFxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHN1Y2Nlc3NJbmRleDogMyxcbiAgICBlcnJvckluZGV4OiA0XG4gIH0pXG4gIGxvZ0V2ZW50KG5hbWU6IHN0cmluZywgcGFyYW1zPzogT2JqZWN0LCB2YWx1ZVRvU3VtPzogbnVtYmVyKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogTG9nIGEgcHVyY2hhc2UuIEZvciBtb3JlIGluZm9ybWF0aW9uIHNlZSB0aGUgRXZlbnRzIHNlY3Rpb24gYWJvdmUuXG4gICAqXG4gICAqIEBwYXJhbSB7bnVtYmVyfSAgdmFsdWUgVmFsdWUgb2YgdGhlIHB1cmNoYXNlLlxuICAgKiBAcGFyYW0ge3N0cmluZ30gIGN1cnJlbmN5IFRoZSBjdXJyZW5jeSwgYXMgYW4gW0lTTyA0MjE3IGN1cnJlbmN5IGNvZGVdKGh0dHA6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSVNPXzQyMTcpXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSgpXG4gIGxvZ1B1cmNoYXNlKHZhbHVlOiBudW1iZXIsIGN1cnJlbmN5OiBzdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBkZWZlcnJlZCBhcHAgbGlua1xuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoKVxuICBnZXREZWZlcnJlZEFwcGxpbmsoKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICByZXR1cm47XG4gIH1cbn1cbiJdfQ==

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/signin/signin.page.html":
/*!*******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/signin/signin.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\" mode=\"ios\" *ngIf=\"Signin\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title class=\"fs12 fontMoteret\">{{ 'signin.signinto' | translate }} <span class=\"clr\">{{ 'signin.continue' | translate }}</span></ion-title>\n  </ion-toolbar>\n  <ion-toolbar color=\"primary\" mode=\"ios\" *ngIf=\"Confirmation\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title class=\"fs12 fontMoteret\">{{ 'signin.enterphone' | translate }} <span class=\"clr\">{{ 'signin.number' | translate }}</span></ion-title>\n  </ion-toolbar> \n  <ion-toolbar color=\"primary\" mode=\"ios\" *ngIf=\"signup || email\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button></ion-back-button>\n      </ion-buttons>\n      <ion-title class=\"fs12 fontMoteret\">{{ 'signin.enteremail' | translate }}</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<!--<div class=\"mt30 txtcntr\" [ngStyle]=\"{'background-image':bgImg}\"  *ngIf=\"Signin\">\n<ion-label><img src=\"assets/images/Signin.svg\"></ion-label>\n<div class=\"mt10\">\n<ion-label class=\"fontSans fs15\">{{ 'signin.signin' | translate }}</ion-label>\n</div>\n<div class=\"mt5\">\n<ion-label  class=\"fontSans fs11\">{{ 'signin.continueappointment' | translate }}</ion-label>\n</div>\n<div class=\"mt15 ml5 mr10\">\n  <ion-button class=\"emailbtn\" fill=\"clear\" (click)=\"goToPhonenoPage()\">\n    {{ 'signin.continuephone' | translate }}\n  </ion-button>\n</div>\n<div class=\"or-seperator\">\n    <div class=\"or\">or</div>\n    </div>\n<div class=\"mt15 ml5 mr10\">\n    <ion-button class=\"emailbtn\" fill=\"clear\" (click)=\"goToEmailPage()\" >\n      {{ 'signin.contineemail' | translate }}\n    </ion-button>\n  </div>\n<div class=\"or-seperator\">\n<div class=\"or\">or</div>\n</div>\n<div class=\"mt15 ml5 mr10\">\n  <ion-button class=\"facebookbtn\" fill=\"clear\"  >\n  <img src=\"assets/images/icon_Landing_Facebook.svg\">{{ 'signin.continuefacebook' | translate }}\n  </ion-button>\n</div>\n<div class=\"unwanteddetails\" >\n  <ion-label class=\"fontSans fs9\">{{ 'signin.unwanteddetails' | translate }}</ion-label>\n</div>\n</div>-->\n\n<!--<div class=\"mt30 txtcntr\" *ngIf=\"Phoneno\">\n  <ion-label><img src=\"assets/images/Enrer_mobile_number.svg\"></ion-label>\n  <div class=\"mt10\">\n    <ion-label class=\"fontSans fs15\">{{ 'signin.enterphonenumber' | translate }}</ion-label>\n    </div>\n    <div class=\"mt5\">\n    <ion-label  class=\"fontSans fs11\">{{ 'signin.entervalidnumber' | translate }}</ion-label>\n    </div>\n    <div class=\"enternumber\">\n      <ion-item>\n        <img src=\"assets/images/smartphone.svg\">&nbsp;&nbsp;<ion-input  type=\"number\" placeholder=\"{{ 'signin.phonenumber' | translate }}\"></ion-input>\n      </ion-item>      \n    </div>\n    <div class=\"mt15 ml5 mr10\">\n      <ion-button class=\"donebtn\" fill=\"clear\" (click)=\"goToConfirmationPage()\">\n        {{ 'signin.donebtn' | translate }}\n      </ion-button>\n    </div>\n</div>-->\n<div class= \"company_logo pt30 txtcntr\"  [ngStyle]=\"{'background-image':bgImg}\"  *ngIf=\"Signin\">\n  <ion-label><img src=\"assets/images/Signin.svg\"></ion-label>\n  <div class=\"mt10\">\n  <ion-label class=\"fontSans fs15 clrw\">{{ 'signin.signin' | translate }}</ion-label>\n  </div>\n  <div class=\"mt5\">\n  <ion-label  class=\"fontSans fs11 clrw\">{{ 'signin.continueappointment' | translate }}</ion-label>\n  </div>\n  <div class=\"mt15 ml5 mr10\">\n    <ion-button class=\"emailbtn\" fill=\"clear\" (click)=\"goToPhonenoPage()\">\n      {{ 'signin.continuephone' | translate }}\n    </ion-button>\n  </div>\n  <!--<div class=\"or-seperator\">\n      <div class=\"or\">or</div>\n      </div>-->\n      <div class=\"ormid\">or</div>\n  <div class=\"mt15 ml5 mr10\">\n      <ion-button class=\"emailbtn\" fill=\"clear\" (click)=\"goToEmailPage()\" >\n        {{ 'signin.contineemail' | translate }}\n      </ion-button>\n    </div>\n  <div class=\"ormid\">or</div>\n  <div class=\"mt15 ml5 mr10\">\n    <ion-button class=\"facebookbtn\" fill=\"clear\"  (click)=\"loginWithFb()\">\n    <img src=\"assets/images/icon_Landing_Facebook.svg\">{{ 'signin.continuefacebook' | translate }}\n    </ion-button>\n  </div>\n  <div class=\"mt15 ml5 mr10\">\n    <ion-button class=\"facebookbtn\" fill=\"clear\"  (click)=\"doGoogleLogin()\">\n    <img src=\"assets/images/icon_Landing_Facebook.svg\">Google\n    </ion-button>\n  </div>\n  <div class=\"unwanteddetails\" >\n    <ion-label class=\"fontSans fs9 clrw\">{{ 'signin.unwanteddetails' | translate }}</ion-label>\n  </div>\n</div>\n   <!--<div class=\"mt30 txtcntr company_logo\" id=\"random\" [ngStyle]=\"{'background-image':bgImg}\" *ngIf=\"email\"> \n    <ion-label><img src=\"assets/images/Enrer_mobile_number.svg\"></ion-label>\n    <div class=\"mt10\">\n      <ion-label class=\"fontSans fs15\">  {{ 'signin.enteremail' | translate }}</ion-label>\n      </div>\n      <div class=\"mt5\">\n      <ion-label  class=\"fontSans fs11\"> {{ 'signin.entervaildemail' | translate }}</ion-label>\n      </div>\n      <div class=\"enternumber\">\n        <ion-item class=\"items\">\n         &nbsp;&nbsp;<ion-input  type=\"email\" [(ngModel)]=\"loginData.email\" name=\"email\" placeholder=\"{{ 'signin.email' | translate }}\"></ion-input>\n        </ion-item>      \n      </div>\n      <div class=\"enternumber\">\n          <ion-item class=\"items\">\n           &nbsp;&nbsp;<ion-input  type=\"password\" [(ngModel)]=\"loginData.password\" name=\"password\" placeholder=\"{{ 'signin.password' | translate }}\"></ion-input>\n          </ion-item>      \n        </div>\n      <div class=\"mt15 ml5 mr10\">\n        <ion-button class=\"donebtn\" fill=\"clear\" (click)=\"goToSchedulixPage()\">\n          {{ 'signin.signin' | translate }}\n        </ion-button>\n      </div>\n      <div class=\"mt10 ml5 mr10\">\n        <ion-button class=\"donebtn\" fill=\"clear\" (click)=\"goToSignupPage()\">\n          {{ 'signin.signup' | translate }}\n        </ion-button>\n      </div>\n    </div>-->\n    <div class= \"company_logo\"  [ngStyle]=\"{'background-image':bgImg}\"  *ngIf=\"email\">\n      <div class=\"pt10 pl10 pr10\">\n          <ion-label class=\"title\">schedul<span class=\"tit\">ix</span></ion-label>\n      </div>\n      <div class=\"position\">\n        <div class=\"ml8 mr8\">\n        <ion-label class=\"fontSans clrw fnt22\">  {{ 'signin.GetthebestHealth&Wellness' | translate }}</ion-label>\n        </div>\n      <div class=\"mt10 ml8 mr8\">\n        <ion-label class=\"fontSans clrw fnt9\">{{ 'signin.EducationSalon&BeautyProfessional Services' | translate }}</ion-label>\n      </div>\n      <div class=\"mt10\">\n       <div class=\"bg_image\">\n         <div class=\"pt5\">\n         <div class=\"mt10 ml8 mr8\">\n           <ion-label  class=\"fontSans clrw\">{{ 'signin.Logintoyouraccount' | translate }}</ion-label>\n         </div>\n         <div class=\"mt10 ml8 mr8\">\n            <ion-label  class=\"fontSans clrw fnt9\">{{ 'signin.Manageyouraccountandseeyouappointmentshistory' | translate }}</ion-label>\n          </div>\n         <div class=\"mt10 ml8 mr8\">\n            <ion-item class=\"item\"><ion-icon ios=\"ios-mail\" md=\"md-mail\"></ion-icon>&nbsp;&nbsp;\n              <ion-input  type=\"email\" [(ngModel)]=\"loginData.email\" name=\"email\" placeholder=\"{{ 'signin.email' | translate }}\"></ion-input>\n            </ion-item>\n          </div>\n          <div class=\"mt10 ml8 mr8\">\n              <ion-item class=\"item\"><img src=\"assets/images/padlock.svg\">&nbsp;&nbsp;\n                <ion-input  type=\"password\" [(ngModel)]=\"loginData.password\" name=\"password\" placeholder=\"{{ 'signin.password' | translate }}\"></ion-input>\n              <span><a href=\"#\">{{ 'signin.Forgot' | translate }}</a></span></ion-item>\n            </div>\n            <div class=\"mt10 ml8 mr8\"  (click)=\"goToSchedulixPage()\">\n              <ion-button class=\"loc\" fill=\"clear\" >\n                {{ 'signin.Login' | translate }}\n              </ion-button>\n            </div>\n            <div class=\"ml8 mr8 txtcntr\">\n              <ion-button fill=\"clear\" (click)=\"goToSignupPage()\">\n                {{ 'signin.Don’thaveanaccount' | translate }} <a style=\"color:white\"> {{ 'signin.signup' | translate }}</a>\n              </ion-button>\n            </div>\n          </div>\n      </div>\n      </div>\n      </div>\n    </div>\n  <!---<div class= \"company_logo\"  [ngStyle]=\"{'background-image':bgImg}\"  *ngIf=\"Phoneno\">\n  <div class=\"pt10 pl10 pr10\">\n      <ion-label class=\"title\">schedul<span class=\"tit\">ix</span></ion-label>\n  </div>\n  <div class=\"position\">\n    <div class=\"ml8 mr8\">\n    <ion-label class=\"fontSans clrw fnt22\">Get the best Health & Wellness,</ion-label>\n    </div>\n  <div class=\"mt10 ml8 mr8\">\n    <ion-label class=\"fontSans clrw fnt9\">Education, Salon & Beauty, Professional Services</ion-label>\n  </div>\n  <div class=\"mt10\">\n   <div class=\"bg_image\">\n     <div class=\"pt5\">\n     <div class=\"mt10 ml8 mr8\">\n       <ion-label  class=\"fontSans clrw\">Login to your account</ion-label>\n     </div>\n     <div class=\"mt10 ml8 mr8\">\n        <ion-label  class=\"fontSans clrw fnt9\">Manage your account and see you appointments history</ion-label>\n      </div>\n     <div class=\"mt10 ml8 mr8\">\n        <ion-item class=\"item\"><img src=\"assets/images/smartphone1.svg\">&nbsp;&nbsp;\n          <ion-input type=\"number\" placeholder=\"Phone number\"></ion-input>\n        </ion-item>\n      </div>\n      <div class=\"mt10 ml8 mr8\">\n          <ion-item class=\"item\"><img src=\"assets/images/padlock.svg\">&nbsp;&nbsp;\n            <ion-input type=\"password\" placeholder=\"Password\"></ion-input>\n          <span><a href=\"#\">Forgot</a></span></ion-item>\n        </div>\n        <div class=\"mt10 ml8 mr8\" (click)=\"goToConfirmationPage()\">\n          <ion-button class=\"loc\" fill=\"clear\" >\n            Login\n          </ion-button>\n        </div>\n        <div class=\"ml8 mr8 txtcntr\">\n          <ion-button fill=\"clear\" (click)=\"goToenterPhonenoPage()\">\n            Don’t have an account? <a style=\"color:white\">Sign up</a>\n          </ion-button>\n        </div>\n      </div>\n  </div>\n  </div>\n  </div>\n</div>-->\n<div class= \"company_logo pt30 txtcntr\"  [ngStyle]=\"{'background-image':bgImg}\"  *ngIf=\"enterPhoneno\">\n        <ion-label><img src=\"assets/images/Enrer_mobile_number.svg\"></ion-label>\n        <div class=\"mt10\">\n          <ion-label class=\"fontSans fs15 clrw\">{{ 'signin.enterphonenumber' | translate }}</ion-label>\n          </div>\n          <div class=\"mt5\">\n          <ion-label  class=\"fontSans fs11 clrw\">{{ 'signin.entervalidnumber' | translate }}</ion-label>\n          </div>\n          <div class=\"enternumber\">\n            <ion-item>\n              <img src=\"assets/images/smartphone.svg\">\n              <ion-select placeholder=\"Country code\"  [(ngModel)]=\"otpdata.mobile\" name=\"mobile\">\n             <ion-select-option value=\"+91\">+91</ion-select-option>\n            <ion-select-option value=\"+92\">+92</ion-select-option>\n            <ion-select-option value=\"+966\"> +966</ion-select-option>\n             </ion-select>\n              <ion-input  type=\"text\" [(ngModel)]=\"otpdata.mobile\" name=\"mobile\" placeholder=\"{{ 'signin.phonenumber' | translate }}\"></ion-input>\n            </ion-item>      \n          </div>\n          <div class=\"mt15 ml5 mr10\">\n            <ion-button class=\"donebtn\" fill=\"clear\" (click)=\"goToConfirmationPage()\">\n              {{ 'signin.SendOtp' | translate }}\n            </ion-button>\n          </div>\n</div>\n<div class= \"company_logo pt30 txtcntr\"  [ngStyle]=\"{'background-image':bgImg}\"  *ngIf=\"signup\">\n  <div class=\"mt10\">\n    <ion-label class=\"fontSans fs15\">{{ 'signin.signup' | translate }}</ion-label>\n  </div>\n <!--<div class=\"enternumber\">\n    <ion-item class=\"items\">\n        &nbsp;&nbsp;<ion-input  type=\"text\"  [(ngModel)]=\"userData.name\" name=\"name\" placeholder=\"{{ 'signin.name' | translate }}\"></ion-input>\n    </ion-item> \n  </div>-->\n  <div class=\"enternumber\">\n    <ion-item class=\"items\">\n     &nbsp;&nbsp;<ion-input  type=\"text\" [(ngModel)]=\"userData.first_name\" name=\"first_name\" placeholder=\"{{ 'signin.firstname' | translate}}\"></ion-input>\n    </ion-item>      \n  </div> \n  <div class=\"enternumber\">\n    <ion-item class=\"items\">\n     &nbsp;&nbsp;<ion-input  type=\"text\" [(ngModel)]=\"userData.last_name\" name=\"last_name\" placeholder=\"{{ 'signin.lastname' | translate }}\"></ion-input>\n    </ion-item>      \n  </div> \n  <div class=\"enternumber\">\n    <ion-item class=\"items\">\n     &nbsp;&nbsp;<ion-input  type=\"email\" [(ngModel)]=\"userData.email\" name=\"email\" placeholder=\"{{ 'signin.email' | translate }}\"></ion-input>\n    </ion-item>      \n  </div>\n  <div class=\"enternumber\">\n      <ion-item class=\"items\">\n       &nbsp;&nbsp;<ion-input  type=\"password\" [(ngModel)]=\"userData.password\" name=\"password\" placeholder=\"{{ 'signin.password' | translate }}\"></ion-input>\n      </ion-item>      \n    </div>\n    <div class=\"enternumber\">\n        <ion-item class=\"items\">\n         &nbsp;&nbsp;<ion-input  type=\"password\" [(ngModel)]=\"userData.confirmed\" name=\"confirmed\"  placeholder=\"{{ 'signin.confirmpassword' | translate }}\"></ion-input>\n        </ion-item>      \n    </div>\n    <div class=\"mt10 ml5 mr10\">\n        <ion-button class=\"donebtn\" fill=\"clear\" (click)=\"goToMainPage()\">\n          {{ 'signin.registerbtn' | translate }}\n        </ion-button>\n    </div>\n</div>\n<div class= \"company_logo pt30 txtcntr\"  [ngStyle]=\"{'background-image':bgImg}\"  *ngIf=\"Confirmation\">\n  <ion-label><img src=\"assets/images/Enrer_mobile_number.svg\"></ion-label>\n<div class=\"mt10\">\n  <ion-label class=\"fontSans fs15\"> {{ 'signin.confirmationcode' | translate }}</ion-label>\n  </div>\n  <div class=\"mt5\">\n  <ion-label  class=\"fontSans fs11\">{{ 'signin.confirmationtext' | translate }}</ion-label>\n  </div>\n  <div class=\"ml5 mr5\">\n  <div class=\"bt0\">\n    <ion-row text-center>\n      <ion-col>\n       <ion-input class=\"otp\"  required maxLength=\"1\"  tabindex=\"1\" (keyup)=\"moveToNext(b)\"  [(ngModel)]=\"otps.otp1\" name=\"otp1\">\n       </ion-input>\n       <ion-input class=\"otp\"  required maxLength=\"1\" tabindex=\"2\" #b (keyup)=\"moveToNext(c)\" [(ngModel)]=\"otps.otp2\" name=\"otp2\">\n       </ion-input>\n       <ion-input class=\"otp\" required maxLength=\"1\"  tabindex=\"3\" #c (keyup)=\"moveToNext(d)\" [(ngModel)]=\"otps.otp3\" name=\"otp3\">\n       </ion-input>\n       <ion-input class=\"otp\"   required maxLength=\"1\" tabindex=\"4\" #d (keyup)=\"moveToNext(e)\" [(ngModel)]=\"otps.otp4\" name=\"otp4\">\n       </ion-input>\n       <ion-input class=\"otp\"  required maxLength=\"1\" tabindex=\"5\" #e (keyup)=\"moveToNext(f)\"  [(ngModel)]=\"otps.otp5\" name=\"otp5\">\n        </ion-input>\n        <ion-input class=\"otp\"  required maxLength=\"1\" tabindex=\"6\" #f   [(ngModel)]=\"otps.otp6\" name=\"otp6\">\n          </ion-input>\n      </ion-col>\n    </ion-row>\n  </div>\n</div>\n  <div class=\"mt5 ml5 mr5\">\n    <ion-row>\n      <ion-col (click)=\"resendcode()\">\n      <button style=\"background:none;\"><ion-label class=\"ft5 clr\">{{ 'signin.resendcode' | translate }} <br>to {{otpusers.mobileNum}}</ion-label></button> \n  </ion-col>\n  <ion-col (click)=\"gotophonepage()\">\n   <button style=\"background:none;\"> <ion-label class=\"ft5 clr\">{{ 'signin.changephoneno' | translate }}</ion-label></button>\n  </ion-col>\n    </ion-row>\n  </div>\n  <div class=\"mt15 ml5 mr10\">\n    <ion-button class=\"donebtn\" fill=\"clear\" (click)=\"registrationCheck()\">\n      {{ 'signin.nextbtn' | translate }}\n    </ion-button>\n  </div>\n</div>\n<div class= \"company_logo pt30 txtcntr\"  [ngStyle]=\"{'background-image':bgImg}\"  *ngIf=\"signupformobile\">\n    <div class=\"enternumber\">\n        <ion-item class=\"items\">\n            &nbsp;&nbsp;<ion-input  type=\"text\"  [(ngModel)]=\"mobileregData.first_name\" name=\"first_name\" placeholder=\"{{ 'signin.firstname' | translate }}\"></ion-input>\n        </ion-item> \n      </div>     \n      <div class=\"enternumber\">\n        <ion-item class=\"items\">\n         &nbsp;&nbsp;<ion-input  type=\"text\" [(ngModel)]=\"mobileregData.last_name\" name=\"last_name\" placeholder=\"{{ 'signin.lastname' | translate }}\"></ion-input>\n        </ion-item>      \n      </div>\n        <div class=\"mt10 ml5 mr10\">\n            <ion-button class=\"donebtn\" fill=\"clear\" (click)=\"goToDashboardPages()\">\n              {{ 'signin.registerbtn' | translate }}\n            </ion-button>\n        </div>\n</div>\n</ion-content>"

/***/ }),

/***/ "./src/app/signin/signin.module.ts":
/*!*****************************************!*\
  !*** ./src/app/signin/signin.module.ts ***!
  \*****************************************/
/*! exports provided: SigninPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SigninPageModule", function() { return SigninPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _signin_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./signin.page */ "./src/app/signin/signin.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/ngx/index.js");
/* harmony import */ var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/google-plus/ngx */ "./node_modules/@ionic-native/google-plus/ngx/index.js");










var routes = [
    {
        path: '',
        component: _signin_page__WEBPACK_IMPORTED_MODULE_6__["SigninPage"]
    }
];
var SigninPageModule = /** @class */ (function () {
    function SigninPageModule() {
    }
    SigninPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_signin_page__WEBPACK_IMPORTED_MODULE_6__["SigninPage"]],
            providers: [_ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_8__["Facebook"], _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_9__["GooglePlus"]]
        })
    ], SigninPageModule);
    return SigninPageModule;
}());



/***/ }),

/***/ "./src/app/signin/signin.page.scss":
/*!*****************************************!*\
  !*** ./src/app/signin/signin.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  --background:#2A2A2A;\n  padding: 5px;\n}\n\n.fontMoteret {\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n}\n\n.clr {\n  color: #ED145B;\n}\n\n.fs12 {\n  font-size: 12pt;\n}\n\n.mt30 {\n  margin-top: 30px;\n}\n\n.txtcntr {\n  text-align: center;\n}\n\n.fontSans {\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n\n.mt10 {\n  margin-top: 10px;\n}\n\n.fs15 {\n  font-size: 15pt;\n}\n\n.mt5 {\n  margin-top: 5px;\n}\n\n.fs11 {\n  font-size: 11pt;\n}\n\n.emailbtn {\n  --border-color:white;\n  --color:white;\n  --border-width:1px;\n  --color-activated:white;\n  text-transform: none;\n  border: 1px solid white;\n  width: 100%;\n  --color-focused:white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  background: black;\n}\n\n.mt15 {\n  margin-top: 15px;\n}\n\n.or-seperator {\n  margin-top: 20px;\n  text-align: center;\n  border-top: 1px solid #ccc;\n  position: relative;\n}\n\n.or {\n  position: absolute;\n  top: -10px;\n  left: 135px;\n}\n\n.facebookbtn {\n  --border-color:white;\n  --color:white;\n  --border-width:1px;\n  --color-activated:white;\n  text-transform: none;\n  border: 1px solid white;\n  width: 100%;\n  --color-focused:white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  background: #0B5998;\n}\n\n.ml5 {\n  margin-left: 5px;\n}\n\n.mr10 {\n  margin-right: 10px;\n}\n\n.fs9 {\n  font-size: 9pt;\n}\n\n.enternumber {\n  margin-top: 15px;\n  margin-left: 5px;\n  margin-right: 5px;\n}\n\n.donebtn {\n  --border-color:white;\n  --color:white;\n  --border-width:1px;\n  --color-activated:white;\n  text-transform: none;\n  border: 1px solid white;\n  width: 100%;\n  --color-focused:white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  background: black;\n}\n\nion-input.otp {\n  display: inline-block;\n  width: 51px;\n  height: 50px;\n  margin: 4px;\n  --padding-start: 7px;\n  border: 1px solid gray;\n}\n\n.bt0 {\n  border-bottom: 0.5px solid gray;\n}\n\n.ml10 {\n  margin-left: 10px;\n}\n\n.mr5 {\n  margin-right: 5px;\n}\n\n.left {\n  text-align: left;\n}\n\n.right {\n  text-align: right;\n}\n\n.fs8 {\n  font-size: 8pt;\n}\n\n.company_logo {\n  background-repeat: no-repeat;\n  background-size: contain;\n  background-size: 100% 100%;\n  background-position: center;\n  height: 100%;\n  z-index: 1;\n  opacity: 1;\n  box-shadow: inset 0 0 5px 2px #282a2d;\n}\n\n.title {\n  font-size: 32pt;\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n}\n\n.tit {\n  color: #ED145B;\n}\n\n.pt10 {\n  padding-top: 10px;\n}\n\n.pl10 {\n  padding-left: 10px;\n}\n\n.pr10 {\n  padding-right: 10px;\n}\n\n.mt135 {\n  margin-top: 135px;\n}\n\n.clrw {\n  color: black;\n}\n\n.fnt22 {\n  font-size: 22pt;\n}\n\n.ml8 {\n  margin-left: 8px;\n}\n\n.mr8 {\n  margin-right: 8px;\n}\n\n.fnt9 {\n  font-size: 9pt;\n}\n\n.bg_image {\n  background-color: #8E8989;\n  z-index: 1;\n  opacity: 0.9;\n  height: 315px !important;\n  border-radius: 8px 8px 0px 0px;\n}\n\n.item {\n  --background: #d8d3d3;\n  border-radius: 8px;\n}\n\nion-button.loc {\n  --border-color:white;\n  --color:white;\n  --border-width:1px;\n  --color-activated:white;\n  text-transform: none;\n  border: 1px solid white;\n  width: 100%;\n  --color-focused:white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n\nion-button {\n  --color:white;\n  --color-activated:white;\n  text-transform: none;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n\n.txtcntr {\n  text-align: center;\n}\n\n.pt5 {\n  padding-top: 5px;\n}\n\n.items {\n  --background:white !important;\n}\n\n.position {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n}\n\n.pt30 {\n  padding-top: 30px;\n}\n\n.clrw {\n  color: black;\n}\n\n.ormid {\n  margin-top: 10px;\n  color: black;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL3NpZ25pbi9zaWduaW4ucGFnZS5zY3NzIiwic3JjL2FwcC9zaWduaW4vc2lnbmluLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9CQUFBO0VBQ0EsWUFBQTtBQ0NGOztBRENBO0VBQ0UsZ0RBQUE7RUFDQSxZQUFBO0FDRUY7O0FEQUE7RUFDQSxjQUFBO0FDR0E7O0FEREE7RUFDRSxlQUFBO0FDSUY7O0FERkE7RUFFRSxnQkFBQTtBQ0lGOztBREZBO0VBQ0Usa0JBQUE7QUNLRjs7QURIQTtFQUNFLHFEQUFBO0FDTUY7O0FESkE7RUFDRSxnQkFBQTtBQ09GOztBRExBO0VBQ0UsZUFBQTtBQ1FGOztBRE5BO0VBQ0UsZUFBQTtBQ1NGOztBRFBBO0VBQ0UsZUFBQTtBQ1VGOztBRFJBO0VBQ0Esb0JBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLG9CQUFBO0VBQ0EsdUJBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxxREFBQTtFQUNBLGlCQUFBO0FDV0E7O0FEVEE7RUFDQSxnQkFBQTtBQ1lBOztBRFZBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLDBCQUFBO0VBQ0Esa0JBQUE7QUNhQTs7QURUQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7QUNZQTs7QURUQTtFQUNBLG9CQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQyxvQkFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0VBQ0EscURBQUE7RUFDQSxtQkFBQTtBQ1lEOztBRFZBO0VBRUEsZ0JBQUE7QUNZQTs7QURWQTtFQUVBLGtCQUFBO0FDWUE7O0FEVkE7RUFDQSxjQUFBO0FDYUE7O0FEWEE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUNjQTs7QURWQTtFQUNBLG9CQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxvQkFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0VBQ0EscURBQUE7RUFDQSxpQkFBQTtBQ2FBOztBRFhBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUNBLHNCQUFBO0FDY0E7O0FEWkE7RUFDQSwrQkFBQTtBQ2VBOztBRGJBO0VBQ0EsaUJBQUE7QUNnQkE7O0FEZEE7RUFDQSxpQkFBQTtBQ2lCQTs7QURmQTtFQUNBLGdCQUFBO0FDa0JBOztBRGhCQTtFQUNBLGlCQUFBO0FDbUJBOztBRGpCQTtFQUNBLGNBQUE7QUNvQkE7O0FEbEJBO0VBQ0EsNEJBQUE7RUFDQSx3QkFBQTtFQUNBLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7RUFFQSxxQ0FBQTtBQ29CQTs7QURmQTtFQUNBLGVBQUE7RUFDQSxnREFBQTtFQUNBLFlBQUE7QUNrQkE7O0FEaEJBO0VBQ0UsY0FBQTtBQ21CRjs7QURqQkE7RUFDRSxpQkFBQTtBQ29CRjs7QURsQkE7RUFDRSxrQkFBQTtBQ3FCRjs7QURuQkE7RUFDRSxtQkFBQTtBQ3NCRjs7QURwQkE7RUFDRSxpQkFBQTtBQ3VCRjs7QURyQkE7RUFDRSxZQUFBO0FDd0JGOztBRHRCQTtFQUNFLGVBQUE7QUN5QkY7O0FEdkJBO0VBQ0EsZ0JBQUE7QUMwQkE7O0FEeEJBO0VBQ0UsaUJBQUE7QUMyQkY7O0FEekJBO0VBQ0UsY0FBQTtBQzRCRjs7QUQxQkE7RUFHQSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0Esd0JBQUE7RUFHQSw4QkFBQTtBQ3lCQTs7QUR2QkE7RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0FDMEJGOztBRHZCQTtFQUNFLG9CQUFBO0VBQ0EsYUFBQTtFQUNELGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxvQkFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0VBQ0EscURBQUE7QUMwQkQ7O0FEeEJBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0Qsb0JBQUE7RUFDQSxxREFBQTtBQzJCRDs7QUR6QkE7RUFDRSxrQkFBQTtBQzRCRjs7QUQxQkE7RUFDRSxnQkFBQTtBQzZCRjs7QUQzQkE7RUFDRSw2QkFBQTtBQzhCRjs7QUQ1QkE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtBQytCQTs7QUQ3QkE7RUFDQSxpQkFBQTtBQ2dDQTs7QUQ5QkE7RUFDQSxZQUFBO0FDaUNBOztBRC9CQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQ2tDQSIsImZpbGUiOiJzcmMvYXBwL3NpZ25pbi9zaWduaW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXJ7XG4gIC0tYmFja2dyb3VuZDojMkEyQTJBO1xuICBwYWRkaW5nOjVweDtcbn1cbi5mb250TW90ZXJldHtcbiAgZm9udC1mYW1pbHk6ICdNb250c2VycmF0Jywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBjb2xvcjp3aGl0ZTtcbn1cbi5jbHJ7XG5jb2xvcjojRUQxNDVCO1xufVxuLmZzMTJ7XG4gIGZvbnQtc2l6ZToxMnB0O1xufVxuLm10MzBcbntcbiAgbWFyZ2luLXRvcDozMHB4O1xufVxuLnR4dGNudHJ7XG4gIHRleHQtYWxpZ246Y2VudGVyO1xufVxuLmZvbnRTYW5ze1xuICBmb250LWZhbWlseTonU291cmNlIFNhbnMgUHJvJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuLm10MTB7XG4gIG1hcmdpbi10b3A6MTBweDtcbn1cbi5mczE1e1xuICBmb250LXNpemU6MTVwdDtcbn1cbi5tdDV7XG4gIG1hcmdpbi10b3A6NXB4O1xufVxuLmZzMTF7XG4gIGZvbnQtc2l6ZToxMXB0O1xufVxuLmVtYWlsYnRue1xuLS1ib3JkZXItY29sb3I6d2hpdGU7XG4tLWNvbG9yOndoaXRlO1xuLS1ib3JkZXItd2lkdGg6MXB4O1xuLS1jb2xvci1hY3RpdmF0ZWQ6d2hpdGU7XG50ZXh0LXRyYW5zZm9ybTpub25lO1xuYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG53aWR0aDogMTAwJTtcbi0tY29sb3ItZm9jdXNlZDp3aGl0ZTtcbmZvbnQtZmFtaWx5OidTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG5iYWNrZ3JvdW5kOiBibGFjaztcbn1cbi5tdDE1e1xubWFyZ2luLXRvcDoxNXB4O1xufVxuLm9yLXNlcGVyYXRvciB7XG5tYXJnaW4tdG9wOiAyMHB4O1xudGV4dC1hbGlnbjogY2VudGVyO1xuYm9yZGVyLXRvcDogMXB4IHNvbGlkICNjY2M7XG5wb3NpdGlvbjpyZWxhdGl2ZTtcbi8vICBtYXJnaW4tbGVmdDogMTBweDtcbi8vIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5vciB7XG5wb3NpdGlvbjogYWJzb2x1dGU7XG50b3A6IC0xMHB4O1xubGVmdDogMTM1cHg7XG4vLyBiYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cbi5mYWNlYm9va2J0bntcbi0tYm9yZGVyLWNvbG9yOndoaXRlO1xuLS1jb2xvcjp3aGl0ZTtcbi0tYm9yZGVyLXdpZHRoOjFweDtcbi0tY29sb3ItYWN0aXZhdGVkOndoaXRlO1xuIHRleHQtdHJhbnNmb3JtOm5vbmU7XG4gYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gd2lkdGg6IDEwMCU7XG4gLS1jb2xvci1mb2N1c2VkOndoaXRlO1xuIGZvbnQtZmFtaWx5OidTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gYmFja2dyb3VuZDogIzBCNTk5ODtcbn1cbi5tbDVcbntcbm1hcmdpbi1sZWZ0OiA1cHg7XG59XG4ubXIxMFxue1xubWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuLmZzOXtcbmZvbnQtc2l6ZTo5cHQ7XG59XG4uZW50ZXJudW1iZXJ7XG5tYXJnaW4tdG9wOiAxNXB4O1xubWFyZ2luLWxlZnQ6IDVweDtcbm1hcmdpbi1yaWdodDogNXB4O1xuLy9ib3JkZXItdG9wOiAycHggc29saWQgI2RhZDZkNjtcbi8vYm9yZGVyLWJvdHRvbToxcHggc29saWQgI2RhZDZkNjtcbn1cbi5kb25lYnRue1xuLS1ib3JkZXItY29sb3I6d2hpdGU7XG4tLWNvbG9yOndoaXRlO1xuLS1ib3JkZXItd2lkdGg6MXB4O1xuLS1jb2xvci1hY3RpdmF0ZWQ6d2hpdGU7XG50ZXh0LXRyYW5zZm9ybTpub25lO1xuYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG53aWR0aDogMTAwJTtcbi0tY29sb3ItZm9jdXNlZDp3aGl0ZTtcbmZvbnQtZmFtaWx5OidTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG5iYWNrZ3JvdW5kOiBibGFjaztcbn1cbmlvbi1pbnB1dC5vdHB7XG5kaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG53aWR0aDogNTFweDtcbmhlaWdodDogNTBweDtcbm1hcmdpbjogNHB4O1xuLS1wYWRkaW5nLXN0YXJ0OiA3cHg7XG5ib3JkZXI6IDFweCBzb2xpZCBncmF5O1xufVxuLmJ0MHtcbmJvcmRlci1ib3R0b206MC41cHggc29saWQgZ3JheTtcbn1cbi5tbDEwe1xubWFyZ2luLWxlZnQ6MTBweDtcbn1cbi5tcjV7XG5tYXJnaW4tcmlnaHQ6NXB4O1xufVxuLmxlZnR7XG50ZXh0LWFsaWduOmxlZnRcbn1cbi5yaWdodHtcbnRleHQtYWxpZ246cmlnaHQ7XG59XG4uZnM4e1xuZm9udC1zaXplOjhwdDtcbn1cbi5jb21wYW55X2xvZ297XG5iYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuYmFja2dyb3VuZC1zaXplOmNvbnRhaW47XG5iYWNrZ3JvdW5kLXNpemU6MTAwJSAxMDAlO1xuYmFja2dyb3VuZC1wb3NpdGlvbjpjZW50ZXI7XG5oZWlnaHQ6MTAwJTtcbnotaW5kZXg6MTtcbm9wYWNpdHk6IDE7IFxuLy9maWx0ZXI6IGFscGhhKG9wYWNpdHk9OTApO1xuYm94LXNoYWRvdzogaW5zZXQgMCAwIDVweCAycHggIzI4MmEyZDtcblxuXG59XG5cbi50aXRsZXtcbmZvbnQtc2l6ZTozMnB0O1xuZm9udC1mYW1pbHk6ICdNb250c2VycmF0Jywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuY29sb3I6d2hpdGU7XG59XG4udGl0e1xuICBjb2xvcjojRUQxNDVCO1xufVxuLnB0MTB7XG4gIHBhZGRpbmctdG9wOjEwcHg7XG59XG4ucGwxMHtcbiAgcGFkZGluZy1sZWZ0OjEwcHg7XG59XG4ucHIxMHtcbiAgcGFkZGluZy1yaWdodDoxMHB4O1xufVxuLm10MTM1e1xuICBtYXJnaW4tdG9wOjEzNXB4O1xufVxuLmNscnd7XG4gIGNvbG9yOmJsYWNrO1xufVxuLmZudDIye1xuICBmb250LXNpemU6MjJwdDtcbn1cbi5tbDh7XG5tYXJnaW4tbGVmdDo4cHg7XG59XG4ubXI4e1xuICBtYXJnaW4tcmlnaHQ6OHB4O1xufVxuLmZudDl7XG4gIGZvbnQtc2l6ZTo5cHQ7XG59XG4uYmdfaW1hZ2V7XG4vLyBmaWx0ZXI6IGJsdXIoOHB4KTtcbi8vLXdlYmtpdC1maWx0ZXI6IGJsdXIoOHB4KTtcbmJhY2tncm91bmQtY29sb3I6XHQjOEU4OTg5O1xuei1pbmRleDoxO1xub3BhY2l0eTowLjk7XG5oZWlnaHQ6MzE1cHggIWltcG9ydGFudDtcbi8vZmlsdGVyOmFscGhhKG9wYWNpdHk9NTApO1xuLy8gd2Via2l0LWZpbHRlcjogYWxwaGEob3BhY2l0eT01MCk7XG5ib3JkZXItcmFkaXVzOiA4cHggOHB4IDBweCAwcHg7XG59XG4uaXRlbXtcbiAgLS1iYWNrZ3JvdW5kOiAjZDhkM2QzO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG5cbn1cbmlvbi1idXR0b24ubG9je1xuICAtLWJvcmRlci1jb2xvcjp3aGl0ZTtcbiAgLS1jb2xvcjp3aGl0ZTtcbiAtLWJvcmRlci13aWR0aDoxcHg7XG4gLS1jb2xvci1hY3RpdmF0ZWQ6d2hpdGU7XG4gdGV4dC10cmFuc2Zvcm06bm9uZTtcbiBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiB3aWR0aDogMTAwJTtcbiAtLWNvbG9yLWZvY3VzZWQ6d2hpdGU7XG4gZm9udC1mYW1pbHk6J1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cbmlvbi1idXR0b257XG4gIC0tY29sb3I6d2hpdGU7XG4gIC0tY29sb3ItYWN0aXZhdGVkOndoaXRlO1xuIHRleHQtdHJhbnNmb3JtOm5vbmU7XG4gZm9udC1mYW1pbHk6J1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cbi50eHRjbnRye1xuICB0ZXh0LWFsaWduOmNlbnRlcjtcbn1cbi5wdDV7XG4gIHBhZGRpbmctdG9wOjVweDtcbn1cbi5pdGVtc3tcbiAgLS1iYWNrZ3JvdW5kOndoaXRlICFpbXBvcnRhbnQ7XG59XG4ucG9zaXRpb257XG5wb3NpdGlvbjogYWJzb2x1dGU7XG5ib3R0b206IDA7XG5sZWZ0OjA7XG5yaWdodDowO1xufVxuLnB0MzB7XG5wYWRkaW5nLXRvcDozMHB4O1xufVxuLmNscnd7XG5jb2xvcjpibGFjaztcbn1cbi5vcm1pZCB7XG5tYXJnaW4tdG9wOiAxMHB4O1xuY29sb3I6YmxhY2s7XG59IiwiaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6IzJBMkEyQTtcbiAgcGFkZGluZzogNXB4O1xufVxuXG4uZm9udE1vdGVyZXQge1xuICBmb250LWZhbWlseTogXCJNb250c2VycmF0XCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uY2xyIHtcbiAgY29sb3I6ICNFRDE0NUI7XG59XG5cbi5mczEyIHtcbiAgZm9udC1zaXplOiAxMnB0O1xufVxuXG4ubXQzMCB7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG59XG5cbi50eHRjbnRyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uZm9udFNhbnMge1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG4ubXQxMCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5mczE1IHtcbiAgZm9udC1zaXplOiAxNXB0O1xufVxuXG4ubXQ1IHtcbiAgbWFyZ2luLXRvcDogNXB4O1xufVxuXG4uZnMxMSB7XG4gIGZvbnQtc2l6ZTogMTFwdDtcbn1cblxuLmVtYWlsYnRuIHtcbiAgLS1ib3JkZXItY29sb3I6d2hpdGU7XG4gIC0tY29sb3I6d2hpdGU7XG4gIC0tYm9yZGVyLXdpZHRoOjFweDtcbiAgLS1jb2xvci1hY3RpdmF0ZWQ6d2hpdGU7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgd2lkdGg6IDEwMCU7XG4gIC0tY29sb3ItZm9jdXNlZDp3aGl0ZTtcbiAgZm9udC1mYW1pbHk6IFwiU291cmNlIFNhbnMgUHJvXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZDogYmxhY2s7XG59XG5cbi5tdDE1IHtcbiAgbWFyZ2luLXRvcDogMTVweDtcbn1cblxuLm9yLXNlcGVyYXRvciB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkICNjY2M7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuLm9yIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IC0xMHB4O1xuICBsZWZ0OiAxMzVweDtcbn1cblxuLmZhY2Vib29rYnRuIHtcbiAgLS1ib3JkZXItY29sb3I6d2hpdGU7XG4gIC0tY29sb3I6d2hpdGU7XG4gIC0tYm9yZGVyLXdpZHRoOjFweDtcbiAgLS1jb2xvci1hY3RpdmF0ZWQ6d2hpdGU7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgd2lkdGg6IDEwMCU7XG4gIC0tY29sb3ItZm9jdXNlZDp3aGl0ZTtcbiAgZm9udC1mYW1pbHk6IFwiU291cmNlIFNhbnMgUHJvXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZDogIzBCNTk5ODtcbn1cblxuLm1sNSB7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG59XG5cbi5tcjEwIHtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xufVxuXG4uZnM5IHtcbiAgZm9udC1zaXplOiA5cHQ7XG59XG5cbi5lbnRlcm51bWJlciB7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIG1hcmdpbi1yaWdodDogNXB4O1xufVxuXG4uZG9uZWJ0biB7XG4gIC0tYm9yZGVyLWNvbG9yOndoaXRlO1xuICAtLWNvbG9yOndoaXRlO1xuICAtLWJvcmRlci13aWR0aDoxcHg7XG4gIC0tY29sb3ItYWN0aXZhdGVkOndoaXRlO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gIHdpZHRoOiAxMDAlO1xuICAtLWNvbG9yLWZvY3VzZWQ6d2hpdGU7XG4gIGZvbnQtZmFtaWx5OiBcIlNvdXJjZSBTYW5zIFByb1wiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6IGJsYWNrO1xufVxuXG5pb24taW5wdXQub3RwIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogNTFweDtcbiAgaGVpZ2h0OiA1MHB4O1xuICBtYXJnaW46IDRweDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA3cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGdyYXk7XG59XG5cbi5idDAge1xuICBib3JkZXItYm90dG9tOiAwLjVweCBzb2xpZCBncmF5O1xufVxuXG4ubWwxMCB7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4ubXI1IHtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG59XG5cbi5sZWZ0IHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbn1cblxuLnJpZ2h0IHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5cbi5mczgge1xuICBmb250LXNpemU6IDhwdDtcbn1cblxuLmNvbXBhbnlfbG9nbyB7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogY29udGFpbjtcbiAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCU7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgaGVpZ2h0OiAxMDAlO1xuICB6LWluZGV4OiAxO1xuICBvcGFjaXR5OiAxO1xuICBib3gtc2hhZG93OiBpbnNldCAwIDAgNXB4IDJweCAjMjgyYTJkO1xufVxuXG4udGl0bGUge1xuICBmb250LXNpemU6IDMycHQ7XG4gIGZvbnQtZmFtaWx5OiBcIk1vbnRzZXJyYXRcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi50aXQge1xuICBjb2xvcjogI0VEMTQ1Qjtcbn1cblxuLnB0MTAge1xuICBwYWRkaW5nLXRvcDogMTBweDtcbn1cblxuLnBsMTAge1xuICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG59XG5cbi5wcjEwIHtcbiAgcGFkZGluZy1yaWdodDogMTBweDtcbn1cblxuLm10MTM1IHtcbiAgbWFyZ2luLXRvcDogMTM1cHg7XG59XG5cbi5jbHJ3IHtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG4uZm50MjIge1xuICBmb250LXNpemU6IDIycHQ7XG59XG5cbi5tbDgge1xuICBtYXJnaW4tbGVmdDogOHB4O1xufVxuXG4ubXI4IHtcbiAgbWFyZ2luLXJpZ2h0OiA4cHg7XG59XG5cbi5mbnQ5IHtcbiAgZm9udC1zaXplOiA5cHQ7XG59XG5cbi5iZ19pbWFnZSB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM4RTg5ODk7XG4gIHotaW5kZXg6IDE7XG4gIG9wYWNpdHk6IDAuOTtcbiAgaGVpZ2h0OiAzMTVweCAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiA4cHggOHB4IDBweCAwcHg7XG59XG5cbi5pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZDhkM2QzO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG59XG5cbmlvbi1idXR0b24ubG9jIHtcbiAgLS1ib3JkZXItY29sb3I6d2hpdGU7XG4gIC0tY29sb3I6d2hpdGU7XG4gIC0tYm9yZGVyLXdpZHRoOjFweDtcbiAgLS1jb2xvci1hY3RpdmF0ZWQ6d2hpdGU7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgd2lkdGg6IDEwMCU7XG4gIC0tY29sb3ItZm9jdXNlZDp3aGl0ZTtcbiAgZm9udC1mYW1pbHk6IFwiU291cmNlIFNhbnMgUHJvXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIC0tY29sb3I6d2hpdGU7XG4gIC0tY29sb3ItYWN0aXZhdGVkOndoaXRlO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgZm9udC1mYW1pbHk6IFwiU291cmNlIFNhbnMgUHJvXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cblxuLnR4dGNudHIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5wdDUge1xuICBwYWRkaW5nLXRvcDogNXB4O1xufVxuXG4uaXRlbXMge1xuICAtLWJhY2tncm91bmQ6d2hpdGUgIWltcG9ydGFudDtcbn1cblxuLnBvc2l0aW9uIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDA7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xufVxuXG4ucHQzMCB7XG4gIHBhZGRpbmctdG9wOiAzMHB4O1xufVxuXG4uY2xydyB7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuLm9ybWlkIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgY29sb3I6IGJsYWNrO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/signin/signin.page.ts":
/*!***************************************!*\
  !*** ./src/app/signin/signin.page.ts ***!
  \***************************************/
/*! exports provided: SigninPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SigninPage", function() { return SigninPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/ngx/index.js");
/* harmony import */ var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/google-plus/ngx */ "./node_modules/@ionic-native/google-plus/ngx/index.js");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/fire/auth */ "./node_modules/@angular/fire/auth/index.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! firebase/app */ "./node_modules/firebase/app/dist/index.cjs.js");
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(firebase_app__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");












var SigninPage = /** @class */ (function () {
    function SigninPage(navCtrl, translate, userService, router, fb, googlePlus, storage, afAuth, platform) {
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.userService = userService;
        this.router = router;
        this.fb = fb;
        this.googlePlus = googlePlus;
        this.storage = storage;
        this.afAuth = afAuth;
        this.platform = platform;
        this.Signin = true;
        this.Phoneno = false;
        this.Confirmation = false;
        this.email = false;
        this.signup = false;
        this.enterPhoneno = false;
        this.signupformobile = false;
        //public background:any;
        this.totalCount = 3;
        //userData = new User();
        //loginData = new User();
        this.userData = {};
        this.loginData = {};
        this.otpdata = {};
        this.mobileregData = {};
        this.otps = {};
        this.loginmobileData = {};
        this.mobileDetails = {};
        this.firstTimeLogin = "yes";
        this.randombg();
        this.mobileDetails = JSON.parse(localStorage.getItem("mobileDetails"));
        //this.mobileDetailss = JSON.parse(localStorage.getItem("mobileDetails"));
        this.user = this.afAuth.authState;
    }
    SigninPage.prototype.ngOnInit = function () {
    };
    SigninPage.prototype.goToPhonenoPage = function () {
        this.Signin = false;
        //  this.Phoneno = true;
        this.enterPhoneno = true;
    };
    SigninPage.prototype.goToEmailPage = function () {
        this.Signin = false;
        this.email = true;
    };
    SigninPage.prototype.doGoogleLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.googlePlus.login({
                    'scopes': '',
                    'webClientId': _environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].googleWebClientId,
                    'offline': true,
                })
                    .then(function (user) {
                    //save user data on the native storage
                    alert(JSON.stringify(user));
                }, function (err) {
                    console.log(err);
                    alert(err);
                });
                return [2 /*return*/];
            });
        });
    };
    SigninPage.prototype.goToConfirmationPage = function () {
        var _this = this;
        this.userService.sendOtp(this.otpdata).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.otpusers = res.data.user;
                console.log(_this.otpusers);
                localStorage.setItem("mobileDetails", JSON.stringify(res.data.user));
                _this.Signin = false;
                _this.Phoneno = false;
                _this.email = false;
                _this.enterPhoneno = false;
                _this.Confirmation = true;
            }
        });
    };
    SigninPage.prototype.resendcode = function () {
        var _this = this;
        this.userService.sendOtp(this.otpdata).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.otpusers = res.data.user;
                console.log(_this.users);
                localStorage.setItem("mobileDetails", JSON.stringify(res.data.user));
                _this.Signin = false;
                _this.Phoneno = false;
                _this.email = false;
                _this.enterPhoneno = false;
                _this.Confirmation = true;
            }
        });
    };
    SigninPage.prototype.goToSchedulixPage = function () {
        var _this = this;
        this.userService.login(this.loginData).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.navCtrl.navigateForward('/tabs/tab1');
                _this.users = res.data.user;
                console.log(_this.users);
                localStorage.setItem("userDetails", JSON.stringify(_this.users));
                localStorage.setItem("firststTimeLogin", _this.firstTimeLogin);
                _this.Signin = false;
                _this.Phoneno = false;
                _this.email = false;
                _this.Confirmation = false;
            }
        }, function (error) { return console.log('send data'); });
    };
    SigninPage.prototype.goToSignupPage = function () {
        this.Signin = false;
        this.Phoneno = false;
        this.email = false;
        this.Confirmation = false;
        this.signup = true;
    };
    SigninPage.prototype.goToDashboardPage = function () {
        this.Signin = false;
        this.Phoneno = false;
        this.email = false;
        this.Confirmation = false;
        this.navCtrl.navigateForward('/tabs/tab1');
    };
    SigninPage.prototype.randombg = function () {
        var images = ['/shutterstock1.png',
            '/shutterstock2.png', '/shutterstock3.png'];
        this.randomNumber = Math.floor(Math.random() * images.length);
        var bgimage = images[this.randomNumber];
        this.bgImg = 'url("../assets/images' + bgimage + '")';
    };
    SigninPage.prototype.goToMainPage = function () {
        var _this = this;
        this.userService.register(this.userData).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.users = res.data.user;
                console.log(_this.users);
                _this.Phoneno = false;
                _this.email = false;
                _this.Confirmation = false;
                _this.signup = false;
                _this.Signin = false;
                _this.email = false;
                _this.navCtrl.navigateForward('/tabs/tab1');
            }
        });
    };
    /*goToenterPhonenoPage(){
      this.Phoneno = false;
      this.email= false;
      this.Confirmation = false;
      this.signup = false;
      this.Signin = false;
      this.email = false;
      this.enterPhoneno = true;
    }*/
    SigninPage.prototype.registrationCheck = function () {
        var _this = this;
        this.OTP_token = this.otps.otp1 + this.otps.otp2 + this.otps.otp3 + this.otps.otp4 + this.otps.otp5 + this.otps.otp6;
        if (this.mobileDetails && this.OTP_token) {
            this.loginmobileData = {
                "mobile": this.mobileDetails.mobileNum,
                "OTP_token": this.OTP_token
            };
        }
        this.userService.loginCheckMobile(this.loginmobileData).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.loginmobileData = {};
                _this.loginmobile = res.data.user;
                localStorage.setItem("userDetails", JSON.stringify(_this.loginmobile));
                localStorage.setItem("firststTimeLogin", _this.firstTimeLogin);
                _this.navCtrl.navigateForward('/tabs/tab1');
            }
        }, function (err) {
            console.log(err);
            _this.Phoneno = false;
            _this.email = false;
            _this.Confirmation = false;
            _this.signup = false;
            _this.Signin = false;
            _this.email = false;
            _this.enterPhoneno = false;
            _this.signupformobile = true;
        });
    };
    SigninPage.prototype.goToDashboardPages = function () {
        var _this = this;
        this.mobileregData = {
            "mobile": this.mobileDetails.mobileNum,
            "OTP_token": this.OTP_token,
            "first_name": this.mobileregData.first_name,
            "last_name": this.mobileregData.last_name
        };
        this.userService.register(this.mobileregData).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.mobileregData = {};
                _this.users = res.data.user;
                _this.Phoneno = false;
                _this.email = false;
                _this.Confirmation = false;
                _this.signup = false;
                _this.Signin = false;
                _this.email = false;
                _this.enterPhoneno = false;
                _this.signupformobile = false;
                _this.navCtrl.navigateForward('/tabs/tab1');
            }
        });
    };
    SigninPage.prototype.gotophonepage = function () {
        this.Confirmation = false;
        this.enterPhoneno = true;
    };
    SigninPage.prototype.moveToNext = function (nextElement) {
        nextElement.setFocus();
    };
    SigninPage.prototype.loginWithFb = function () {
        var _this = this;
        this.fb.login(['public_profile', 'user_photos', 'email', 'user_birthday'])
            .then(function (res) {
            if (res.status == "connected") {
                var fb_id = res.authResponse.userID;
                var fb_token = res.authResponse.accessToken;
                _this.fb.api("/me?fields=name,gender,birthday,email,picture.width(720).height(720).as(picture_large)", []).then(function (user) {
                    var fbData = { "name": user.name, "email": user.email, "facebook_auth_token": "10555629077399852", "image": user.picture_large.data.url };
                    _this.userService.loginWithFB(fbData).subscribe(function (res) {
                        console.log(res);
                        _this.navCtrl.navigateForward('/tabs/tab1');
                    }, function (err) {
                        alert(JSON.stringify(err));
                    });
                });
            }
            else {
                console.log("An error occurred...");
            }
        })
            .catch(function (e) {
            console.log('Error logging into Facebook', e);
        });
    };
    SigninPage.prototype.loginWithGoogle = function () {
        this.googlePlus.login({
            'scopes': '',
            'webClientId': '614341758035-hg8fpunerbpj874tb8s1vrg7mm8168pg.apps.googleusercontent.com',
            //'webClientId':'614341758035-raau8ssbcr2iqroso7d1cp81mq1rd8tu.apps.googleusercontent.com',
            'offline': true // Optional, but requires the webClientId - if set to true the plugin will also return a serverAuthCode, which can be used to grant offline access to a non-Google server
        })
            .then(function (user) {
            alert(JSON.stringify(user));
        }, function (err) {
            console.log(err);
            alert(JSON.stringify(err));
        });
    };
    SigninPage.prototype.nativeGoogleLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var gplusUser, user, err_1;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, this.googlePlus.login({
                                //'webClientId': '614341758035-hg8fpunerbpj874tb8s1vrg7mm8168pg.apps.googleusercontent.com',
                                'webClientId': '614341758035-raau8ssbcr2iqroso7d1cp81mq1rd8tu.apps.googleusercontent.com',
                                'offline': true,
                                'scopes': ''
                            })];
                    case 1:
                        gplusUser = _a.sent();
                        alert(JSON.stringify(gplusUser));
                        firebase_app__WEBPACK_IMPORTED_MODULE_10__["auth"].GoogleAuthProvider.credential(gplusUser.idToken);
                        this.afAuth.auth.signInWithCredential(firebase_app__WEBPACK_IMPORTED_MODULE_10__["auth"].GoogleAuthProvider.credential(gplusUser.idToken));
                        user = this.afAuth.auth.signInWithCredential(firebase_app__WEBPACK_IMPORTED_MODULE_10__["auth"].GoogleAuthProvider.credential(gplusUser.idToken));
                        console.log('googlellllllllll', this.user);
                        return [3 /*break*/, 3];
                    case 2:
                        err_1 = _a.sent();
                        alert(err_1);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    SigninPage.prototype.webGoogleLogin = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var provider, credential, err_2;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        provider = new firebase_app__WEBPACK_IMPORTED_MODULE_10__["auth"].GoogleAuthProvider();
                        return [4 /*yield*/, this.afAuth.auth.signInWithPopup(provider)];
                    case 1:
                        credential = _a.sent();
                        alert(JSON.stringify(credential));
                        return [3 /*break*/, 3];
                    case 2:
                        err_2 = _a.sent();
                        console.log(err_2);
                        return [3 /*break*/, 3];
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    SigninPage.prototype.googleLogin = function () {
        this.doGoogleLogin();
        // return;
        // if (this.platform.is('cordova')) {
        //   this.loginWithGoogle();
        // } else {
        //   this.webGoogleLogin();
        // }
    };
    SigninPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] },
        { type: _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
        { type: _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_7__["Facebook"] },
        { type: _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_8__["GooglePlus"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"] },
        { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_9__["AngularFireAuth"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] }
    ]; };
    SigninPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-signin',
            template: __webpack_require__(/*! raw-loader!./signin.page.html */ "./node_modules/raw-loader/index.js!./src/app/signin/signin.page.html"),
            styles: [__webpack_require__(/*! ./signin.page.scss */ "./src/app/signin/signin.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"],
            _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_7__["Facebook"],
            _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_8__["GooglePlus"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"],
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_9__["AngularFireAuth"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]])
    ], SigninPage);
    return SigninPage;
}());



/***/ })

}]);
//# sourceMappingURL=signin-signin-module.js.map