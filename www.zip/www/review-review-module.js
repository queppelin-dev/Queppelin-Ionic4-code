(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["review-review-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/review/review.page.html":
/*!*******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/review/review.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"primary\" mode=\"ios\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button></ion-back-button>\n      </ion-buttons>\n      <ion-title>{{ 'review.review' | translate }}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n<div style=\"margin-bottom:10px;\">\n  <div class=\"sort\">\n    <ion-label>{{ 'review.sortdate' | translate }}</ion-label>&nbsp;&nbsp;&nbsp;\n    <ion-icon name=\"ios-arrow-down\"></ion-icon>\n  </div>\n  <div *ngFor=\"let reviewData of personalreviewinformation\">\n    <div class=\"date\">\n      <ion-label class=\"fs10 ml10 mr10\"> {{reviewData.appointment_date}} | {{reviewData.appointment_time}}</ion-label>\n    </div>\n    <div class=\"glr accordian-list box-shadow\" >\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"1\">\n          <img style=\"max-width: 225%;\" src=\"assets/images/layer@3x.png\">\n          </ion-col>\n          <ion-col size=\"9\" class=\"ml10 mr14\">\n          <ion-label>{{reviewData.business_name}}</ion-label><br/>\n          <img src=\"assets/images/location2.svg\"><ion-label class=\"fontSans fs9\">&nbsp;{{reviewData.distance}}, {{reviewData.address}}</ion-label><br>\n            <ion-label>\n              <rating  [(ngModel)]=\"rate\"\n              readonly=\"false\" \n              size=\"default\" \n              (ngModelChange)=\"onRateChange($event, reviewData)\">\n              </rating><span>{{reviewData.rate}}</span> <span>.0</span>\n            </ion-label>\n          </ion-col>\n          <ion-col size=\"1\">\n              <div (click)=\"toggleGroup('i')\" [ngClass]=\"{active: isGroupShown('i')}\">\n                  <ion-icon  [name]=\"isGroupShown('i') ? 'ios-arrow-up' : 'ios-arrow-down'\"></ion-icon>\n              </div>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n      <div *ngIf=\"isGroupShown('i')\">\n      <div>\n      <div *ngFor=\"let items of reviewData.get_customer_reviews\">\n        <div class=\"reply\" >\n          <ion-row>\n            <ion-col size=\"1\">\n            </ion-col>\n            <ion-col size=\"1\" >\n              <img src=\"assets/images/layer1.png\">\n            </ion-col>\n            <ion-col size=\"9\">\n              <ion-label class=\"fs8 fontSans ml6\">\n                <span class=\"clrb\">{{items.comment_by_name}}</span> <span class=\"clrg\">&nbsp;{{items.review_date}} | {{items.review_time}}</span>\n              </ion-label><br>\n              <ion-label class=\"fontSans clrg fs8 ml7\">{{items.comment}}</ion-label>\n            </ion-col>\n          </ion-row>\n          \n        </div>\n          <div class=\"replyback\" *ngIf = \"items.reply_by_name\">\n            <ion-row>\n              <ion-col offset=\"1.5\">\n              <ion-card>\n                <ion-card-content>\n                  <ion-row>\n                    <ion-col size=\"1.5\">\n                  <img style=\"width:60%;\" src=\"assets/images/layer.png\">\n                  </ion-col>\n                  <ion-col size=\"10.5\" class=\"colml\">\n                  <ion-label class=\"fs8\"> <span class=\"clrb\">{{items?.reply_by_name}}</span> <span class=\"clrg\">&nbsp;( Replied: {{items.reply_date}}|{{items.reply_time}} )</span></ion-label><br>\n                  <ion-label>{{items.reply}}</ion-label>\n                    </ion-col>\n                    </ion-row>\n                </ion-card-content>\n              </ion-card>\n              </ion-col>\n            </ion-row>\n          </div>\n        </div>\n      </div>\n      <div class=\"gray\">\n          <ion-row>\n            <ion-col size=\"1\">\n            </ion-col>\n            <ion-col size=\"9\">\n              <ion-input type=\"text\" placeholder=\"| Type to add comment on “Make by GLR”\" class=\"fs8 fontSans\" [(ngModel)]=\"comment\" (input)=\"addComment()\">\n              </ion-input>\n            </ion-col>\n            <ion-col size=\"2\">\n              <img style=\"padding-top:5px;\" src=\"assets/images/edit.svg\" (click)=\"writeReview()\">\n            </ion-col>\n        </ion-row>\n      </div>\n    </div>\n  </div>\n </div>\n</div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/review/review.module.ts":
/*!*****************************************!*\
  !*** ./src/app/review/review.module.ts ***!
  \*****************************************/
/*! exports provided: ReviewPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewPageModule", function() { return ReviewPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var ionic4_rating__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ionic4-rating */ "./node_modules/ionic4-rating/dist/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _review_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./review.page */ "./src/app/review/review.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");









var routes = [
    {
        path: '',
        component: _review_page__WEBPACK_IMPORTED_MODULE_7__["ReviewPage"]
    }
];
var ReviewPageModule = /** @class */ (function () {
    function ReviewPageModule() {
    }
    ReviewPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"],
                ionic4_rating__WEBPACK_IMPORTED_MODULE_5__["IonicRatingModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_review_page__WEBPACK_IMPORTED_MODULE_7__["ReviewPage"]]
        })
    ], ReviewPageModule);
    return ReviewPageModule;
}());



/***/ }),

/***/ "./src/app/review/review.page.scss":
/*!*****************************************!*\
  !*** ./src/app/review/review.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  --background:#2A2A2A;\n  padding: 5px;\n}\n\n.fontMoteret {\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n}\n\n.sort {\n  padding-top: 6pt;\n  color: #999999;\n  background: #E6E6E6;\n  padding-bottom: 6pt;\n  text-align: center;\n}\n\n.fs10 {\n  font-size: 10pt;\n}\n\n.date {\n  padding-top: 6pt;\n  color: black;\n  background: #f1eded;\n  padding-bottom: 6pt;\n}\n\nimg.people {\n  width: 45px;\n}\n\n.fs9 {\n  font-size: 9pt;\n}\n\n.fontSans {\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n\n.gray {\n  background: #636162;\n  color: white;\n}\n\n.fs8 {\n  font-size: 8pt;\n}\n\n.fs7 {\n  font-size: 7pt;\n}\n\n.ml6 {\n  margin-left: -6px;\n}\n\n.clrb {\n  color: black;\n}\n\n.clrg {\n  color: #636162;\n}\n\nion-card-content {\n  background-color: #EDEDED;\n  padding-left: 4px;\n  padding-right: 0px;\n  padding-top: 8px;\n}\n\n.colml {\n  margin-left: -14px;\n  margin-top: -4px;\n}\n\nion-input {\n  --placeholder-color:white;\n  --placeholder-opacity:1;\n}\n\n.accordian-list {\n  height: 100%;\n}\n\nrating ion-icon {\n  color: gray;\n  padding: 0px !important;\n  margin-right: -10px;\n}\n\nrating ion-icon.filled {\n  color: #ffb400;\n}\n\n.sc-ion-buttons-md-s .button-has-icon-only.button-clear {\n  margin-left: -13px !important;\n}\n\n.box-shadow {\n  box-shadow: 2px 1px 3px 0px grey;\n}\n\n.ml10 {\n  margin-left: 10px;\n}\n\n.mr14 {\n  margin-right: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL3Jldmlldy9yZXZpZXcucGFnZS5zY3NzIiwic3JjL2FwcC9yZXZpZXcvcmV2aWV3LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG9CQUFBO0VBQ0EsWUFBQTtBQ0NKOztBRENFO0VBQ0UsZ0RBQUE7RUFDQSxZQUFBO0FDRUo7O0FEQUU7RUFDRSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUNHSjs7QURERTtFQUNJLGVBQUE7QUNJTjs7QURGRTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUNLSjs7QURIRTtFQUNFLFdBQUE7QUNNSjs7QURKQTtFQUNJLGNBQUE7QUNPSjs7QURMQTtFQUNJLHFEQUFBO0FDUUo7O0FETkU7RUFDRSxtQkFBQTtFQUNBLFlBQUE7QUNTSjs7QURQQTtFQUNJLGNBQUE7QUNVSjs7QURSQTtFQUNJLGNBQUE7QUNXSjs7QURUQTtFQUNJLGlCQUFBO0FDWUo7O0FEVkE7RUFDSSxZQUFBO0FDYUo7O0FEWEE7RUFDSSxjQUFBO0FDY0o7O0FEWkE7RUFDSSx5QkFBQTtFQUNBLGlCQUFBO0VBQ0Msa0JBQUE7RUFDQyxnQkFBQTtBQ2VOOztBRGJBO0VBQ0ssa0JBQUE7RUFDRCxnQkFBQTtBQ2dCSjs7QURkQTtFQUNJLHlCQUFBO0VBQ0EsdUJBQUE7QUNpQko7O0FEZkE7RUFFSSxZQUFBO0FDaUJKOztBRGRJO0VBQ0UsV0FBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNpQk47O0FEZk07RUFDRSxjQUFBO0FDaUJSOztBRGJFO0VBQ0ksNkJBQUE7QUNnQk47O0FEZEU7RUFDRSxnQ0FBQTtBQ2lCSjs7QURmRTtFQUNFLGlCQUFBO0FDa0JKOztBRGhCRTtFQUNFLGtCQUFBO0FDbUJKIiwiZmlsZSI6InNyYy9hcHAvcmV2aWV3L3Jldmlldy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhcntcbiAgICAtLWJhY2tncm91bmQ6IzJBMkEyQTtcbiAgICBwYWRkaW5nOjVweDtcbiAgfVxuICAuZm9udE1vdGVyZXR7XG4gICAgZm9udC1mYW1pbHk6ICdNb250c2VycmF0Jywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICAgIGNvbG9yOndoaXRlO1xuICB9XG4gIC5zb3J0e1xuICAgIHBhZGRpbmctdG9wOiA2cHQ7XG4gICAgY29sb3I6ICM5OTk5OTk7XG4gICAgYmFja2dyb3VuZDogI0U2RTZFNjtcbiAgICBwYWRkaW5nLWJvdHRvbTogNnB0O1xuICAgIHRleHQtYWxpZ246Y2VudGVyO1xuICB9XG4gIC5mczEwe1xuICAgICAgZm9udC1zaXplOjEwcHQ7XG4gIH1cbiAgLmRhdGV7XG4gICAgcGFkZGluZy10b3A6IDZwdDtcbiAgICBjb2xvcjogYmxhY2s7XG4gICAgYmFja2dyb3VuZDogI2YxZWRlZDtcbiAgICBwYWRkaW5nLWJvdHRvbTogNnB0O1xuICB9XG4gIGltZy5wZW9wbGUge1xuICAgIHdpZHRoOiA0NXB4O1xufVxuLmZzOXtcbiAgICBmb250LXNpemU6OXB0O1xufVxuLmZvbnRTYW5ze1xuICAgIGZvbnQtZmFtaWx5OidTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIH1cbiAgLmdyYXkge1xuICAgIGJhY2tncm91bmQ6ICM2MzYxNjI7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuLmZzOHtcbiAgICBmb250LXNpemU6OHB0O1xufVxuLmZzN3tcbiAgICBmb250LXNpemU6N3B0O1xufVxuLm1sNntcbiAgICBtYXJnaW4tbGVmdDotNnB4O1xufVxuLmNscmJ7XG4gICAgY29sb3I6YmxhY2s7XG59XG4uY2xyZ3tcbiAgICBjb2xvcjojNjM2MTYyO1xufVxuaW9uLWNhcmQtY29udGVudHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRURFREVEO1xuICAgIHBhZGRpbmctbGVmdDo0cHg7XG4gICAgIHBhZGRpbmctcmlnaHQ6MHB4O1xuICAgICAgcGFkZGluZy10b3A6OHB4O1xufVxuLmNvbG1se1xuICAgICBtYXJnaW4tbGVmdDogLTE0cHg7XG4gICAgbWFyZ2luLXRvcDogLTRweDtcbn1cbmlvbi1pbnB1dHtcbiAgICAtLXBsYWNlaG9sZGVyLWNvbG9yOndoaXRlO1xuICAgIC0tcGxhY2Vob2xkZXItb3BhY2l0eToxO1xufVxuLmFjY29yZGlhbi1saXN0e1xuICAgIC8vYmFja2dyb3VuZDogbGlnaHQ7XG4gICAgaGVpZ2h0OjEwMCU7XG59XG5yYXRpbmcge1xuICAgIGlvbi1pY29uIHtcbiAgICAgIGNvbG9yOiBncmF5O1xuICAgICAgcGFkZGluZzowcHggIWltcG9ydGFudDtcbiAgICAgIG1hcmdpbi1yaWdodDotMTBweDtcbiAgXG4gICAgICAmLmZpbGxlZCB7XG4gICAgICAgIGNvbG9yOiAjZmZiNDAwO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICAuc2MtaW9uLWJ1dHRvbnMtbWQtcyAgLmJ1dHRvbi1oYXMtaWNvbi1vbmx5LmJ1dHRvbi1jbGVhcntcbiAgICAgIG1hcmdpbi1sZWZ0Oi0xM3B4ICFpbXBvcnRhbnQ7XG4gIH1cbiAgLmJveC1zaGFkb3d7XG4gICAgYm94LXNoYWRvdzogMnB4IDFweCAzcHggMHB4IGdyZXk7XG4gIH1cbiAgLm1sMTB7XG4gICAgbWFyZ2luLWxlZnQ6MTBweDtcbiAgfVxuICAubXIxNHtcbiAgICBtYXJnaW4tcmlnaHQ6MTRweDtcbiAgfSIsImlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiMyQTJBMkE7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuLmZvbnRNb3RlcmV0IHtcbiAgZm9udC1mYW1pbHk6IFwiTW9udHNlcnJhdFwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLnNvcnQge1xuICBwYWRkaW5nLXRvcDogNnB0O1xuICBjb2xvcjogIzk5OTk5OTtcbiAgYmFja2dyb3VuZDogI0U2RTZFNjtcbiAgcGFkZGluZy1ib3R0b206IDZwdDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uZnMxMCB7XG4gIGZvbnQtc2l6ZTogMTBwdDtcbn1cblxuLmRhdGUge1xuICBwYWRkaW5nLXRvcDogNnB0O1xuICBjb2xvcjogYmxhY2s7XG4gIGJhY2tncm91bmQ6ICNmMWVkZWQ7XG4gIHBhZGRpbmctYm90dG9tOiA2cHQ7XG59XG5cbmltZy5wZW9wbGUge1xuICB3aWR0aDogNDVweDtcbn1cblxuLmZzOSB7XG4gIGZvbnQtc2l6ZTogOXB0O1xufVxuXG4uZm9udFNhbnMge1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG4uZ3JheSB7XG4gIGJhY2tncm91bmQ6ICM2MzYxNjI7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmZzOCB7XG4gIGZvbnQtc2l6ZTogOHB0O1xufVxuXG4uZnM3IHtcbiAgZm9udC1zaXplOiA3cHQ7XG59XG5cbi5tbDYge1xuICBtYXJnaW4tbGVmdDogLTZweDtcbn1cblxuLmNscmIge1xuICBjb2xvcjogYmxhY2s7XG59XG5cbi5jbHJnIHtcbiAgY29sb3I6ICM2MzYxNjI7XG59XG5cbmlvbi1jYXJkLWNvbnRlbnQge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRURFREVEO1xuICBwYWRkaW5nLWxlZnQ6IDRweDtcbiAgcGFkZGluZy1yaWdodDogMHB4O1xuICBwYWRkaW5nLXRvcDogOHB4O1xufVxuXG4uY29sbWwge1xuICBtYXJnaW4tbGVmdDogLTE0cHg7XG4gIG1hcmdpbi10b3A6IC00cHg7XG59XG5cbmlvbi1pbnB1dCB7XG4gIC0tcGxhY2Vob2xkZXItY29sb3I6d2hpdGU7XG4gIC0tcGxhY2Vob2xkZXItb3BhY2l0eToxO1xufVxuXG4uYWNjb3JkaWFuLWxpc3Qge1xuICBoZWlnaHQ6IDEwMCU7XG59XG5cbnJhdGluZyBpb24taWNvbiB7XG4gIGNvbG9yOiBncmF5O1xuICBwYWRkaW5nOiAwcHggIWltcG9ydGFudDtcbiAgbWFyZ2luLXJpZ2h0OiAtMTBweDtcbn1cbnJhdGluZyBpb24taWNvbi5maWxsZWQge1xuICBjb2xvcjogI2ZmYjQwMDtcbn1cblxuLnNjLWlvbi1idXR0b25zLW1kLXMgLmJ1dHRvbi1oYXMtaWNvbi1vbmx5LmJ1dHRvbi1jbGVhciB7XG4gIG1hcmdpbi1sZWZ0OiAtMTNweCAhaW1wb3J0YW50O1xufVxuXG4uYm94LXNoYWRvdyB7XG4gIGJveC1zaGFkb3c6IDJweCAxcHggM3B4IDBweCBncmV5O1xufVxuXG4ubWwxMCB7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4ubXIxNCB7XG4gIG1hcmdpbi1yaWdodDogMTRweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/review/review.page.ts":
/*!***************************************!*\
  !*** ./src/app/review/review.page.ts ***!
  \***************************************/
/*! exports provided: ReviewPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewPage", function() { return ReviewPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_business_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/business.service */ "./src/app/services/business.service.ts");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/user.service */ "./src/app/services/user.service.ts");






var ReviewPage = /** @class */ (function () {
    function ReviewPage(navCtrl, translate, businessService, userService) {
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.businessService = businessService;
        this.userService = userService;
        this.shownGroup = null;
        this.rate = 0;
        this.reviewData = {};
        this.userDetails = {};
        this.businessreviewData = {};
        this.reviewsList = [];
        this.personalinformationsData = {};
        this.personalreviewinformationreviews = [];
        this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
        this.currentlocation = JSON.parse(localStorage.getItem("latLong"));
        console.log(this.userDetails);
    }
    ReviewPage.prototype.ngOnInit = function () {
        console.log(this.userDetails);
        //  this.reviewListing();
        this.getpersonalReview();
    };
    ReviewPage.prototype.toggleGroup = function (group) {
        if (this.isGroupShown(group)) {
            this.shownGroup = null;
        }
        else {
            this.shownGroup = group;
        }
    };
    ;
    ReviewPage.prototype.isGroupShown = function (group) {
        return this.shownGroup === group;
    };
    ;
    ReviewPage.prototype.onRateChange = function (event, reviewData) {
        console.log(reviewData);
        this.appintmentDitails = reviewData;
        console.log('Your rate:', event);
        this.rating = event;
    };
    ReviewPage.prototype.writeReview = function () {
        var _this = this;
        if (!this.rating) {
            alert('Please select any rating');
        }
        else {
            this.reviewData = {
                "business_id": this.appintmentDitails.business_id, "appointment_id": this.appintmentDitails.id, "user_id": this.userDetails.id,
                "role_id": this.userDetails.role_id, "token": this.userDetails.token.original.token,
                "review_rating": this.rating, "comment": this.comment
            };
            console.log(this.reviewData);
            this.businessService.addReview(this.reviewData).subscribe(function (res) {
                console.log(res);
                _this.comment = '';
                _this.reviewData = {};
                console.log(_this.reviewData);
            });
        }
    };
    // reviewListing() {
    //   this.businessreviewData = {  "business_id":this.appintmentDitails.business_id,"appointment_id":this.appintmentDitails.id,"Review_id":1 };
    //   this.businessService.businessReview(this.businessreviewData).subscribe((res : any)=> {
    //     console.log('reviewList' + res);
    //     this.reviewsList = res.data.user;
    //     this.reviewData = {};
    //   }); 
    // }
    ReviewPage.prototype.addComment = function () {
        this.reviewData.comment = this.comment;
    };
    ReviewPage.prototype.getpersonalReview = function () {
        var _this = this;
        if (this.userDetails) {
            this.personalinformationsData = {
                "user_id": this.userDetails.id,
                "role_id": this.userDetails.role_id,
                "token": this.userDetails.token.original.token
            };
            console.log('pesonal', this.personalinformationsData);
        }
        this.userService.personalReview(this.personalinformationsData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.personalreviewinformation = res.data.user;
                for (var i = 0; i < _this.personalreviewinformation.length; i++) {
                    if (_this.currentlocation) {
                        _this.personalreviewinformation[i].distance = _this.businessService.getDistanceFromLatLonInKm(_this.currentlocation.lat, _this.currentlocation.long, _this.personalreviewinformation[i].latitude, _this.personalreviewinformation[i].longitude);
                    }
                    //  if(this.personalreviewinformation[i].get_customer_reviews.length > 0) {
                    //   this.personalreviewinformationreviews.push(this.personalreviewinformation[i]);
                    //  }
                }
            }
        });
    };
    ReviewPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] },
        { type: _services_business_service__WEBPACK_IMPORTED_MODULE_4__["BusinessService"] },
        { type: _services_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"] }
    ]; };
    ReviewPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-review',
            template: __webpack_require__(/*! raw-loader!./review.page.html */ "./node_modules/raw-loader/index.js!./src/app/review/review.page.html"),
            styles: [__webpack_require__(/*! ./review.page.scss */ "./src/app/review/review.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"],
            _services_business_service__WEBPACK_IMPORTED_MODULE_4__["BusinessService"],
            _services_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"]])
    ], ReviewPage);
    return ReviewPage;
}());



/***/ })

}]);
//# sourceMappingURL=review-review-module.js.map