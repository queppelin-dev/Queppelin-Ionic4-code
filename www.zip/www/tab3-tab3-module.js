(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab3-tab3-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/tab3/tab3.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/tab3/tab3.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-label slot=\"start\" (click)=\"goToTab3Page()\"><img  src=\"assets/images/Back_arrow.svg\"></ion-label>\n    <ion-title style=\"text-align:center;\">\n    <ion-label class=\"fontMoteret\">{{ 'tab3.appointment' | translate }}</ion-label>\n    </ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content [ngClass]=\"{'bg1':themes == 'white' }\">\n  <div style=\"margin-top:20px;\">\n    <div style=\"margin:10px;\">\n      <div *ngIf=\"Appointment\">\n      <div *ngIf=\"showappointment\">\n   <ion-label class=\"fms clrw\">{{ 'tab3.today' | translate }}</ion-label>\n    <div class=\"box blg\" (click)=\"goToEditAppointmentPage()\" *ngFor=\"let item of todayData\">\n       <ion-grid *ngIf=\"item\">\n        <ion-row>\n          <ion-col size=\"3\" style=\"text-align:center;\">\n          <ion-label class=\"fmc\"><span class=\"fs12\">{{item.appointment_date}}</span><br><br><span class=\"fs12\">{{item.appointment_time}}</span></ion-label>\n          </ion-col>\n          <ion-col size=\"1\" style=\"border-right:1px solid gray;\">\n          </ion-col>\n          <ion-col size=\"7\" style=\"text-align:left;\">\n              <ion-label class=\"fmc\"><span class=\"fs9 clrg\">{{ 'tab3.confirmed' | translate }}</span><br><span class=\"fs13\" *ngIf=\"item.name\">{{item.name}}</span><span class=\"fs13\" *ngIf=\"!item.name\">Make By GLR</span><br><span class=\"fs9 clrgr\">{{item.with_service[0]?.name}}</span></ion-label>\n            </ion-col>\n            <ion-col size=\"1\" class=\"col1\">\n                <ion-icon name=\"ios-arrow-forward\"></ion-icon>\n              </ion-col>\n        </ion-row>\n      </ion-grid>\n       </div>\n   \n     <div style=\"margin-top:20px;margin-bottom:10px;\">\n     <ion-label class=\"fms clrw fs10\">{{'tab3.upcoming' | translate }}</ion-label>\n     <div class=\"box blg\" (click)=\"goToEditAppointmentPage()\" *ngFor=\"let item of upcomingData\">\n       <ion-grid *ngIf=\"item\">\n        <ion-row>\n          <ion-col size=\"3\" style=\"text-align:center;\">\n          <ion-label class=\"fmc\"><span class=\"fs12\">{{item.appointment_date}}</span><br><br><span class=\"fs12\">{{item.appointment_time}}</span></ion-label>\n          </ion-col>\n          <ion-col size=\"1\" style=\"border-right:1px solid gray;\">\n          </ion-col>\n          <ion-col size=\"7\" style=\"text-align:left;\">\n              <ion-label class=\"fmc\"><span class=\"fs9 clrg\">{{ 'tab3.confirmed' | translate }}</span><br><span class=\"fs13\" *ngIf=\"item.name\">{{item.name}}</span><span class=\"fs13\" *ngIf=\"!item.name\">Make By GLR</span><br><span class=\"fs9 clrgr\">{{item.with_service[0]?.name}}</span></ion-label>\n            </ion-col>\n            <ion-col size=\"1\" class=\"col1\">\n                <ion-icon name=\"ios-arrow-forward\"></ion-icon>\n              </ion-col>\n        </ion-row>\n      </ion-grid>\n       </div>\n     </div>\n      </div>\n     <div *ngIf=\"shownoappointment\" style=\"color:white;text-align:center;\">\n      <ion-label>{{ 'tab3.Thereisnoappointment' | translate }}</ion-label>\n     </div>\n    \n       <!--<div class=\"box blg\" (click)=\"goToEditAppointmentPage()\">\n          <ion-grid>\n        <ion-row>\n          <ion-col size=\"3\" style=\"text-align:center;\">\n          <ion-label class=\"fmc\"><span class=\"fs12\">Jun</span><br><span class=\"fs23\"> 21</span><br><span class=\"fs12\">11:00 AM</span></ion-label>\n          </ion-col>\n          <ion-col size=\"1\" style=\"border-right:1px solid gray;\">\n          </ion-col>\n          <ion-col size=\"7\" style=\"text-align:left;\">\n              <ion-label class=\"fmc\"><span class=\"fs9 clrg\">{{ 'tab3.confirmed' | translate }}</span><br><span class=\"fs13\">Make By GLR</span><br><span class=\"fs9 clrgr\">Regular Haircut/ No taper with Charles…</span></ion-label>\n            </ion-col>\n            <ion-col size=\"1\" class=\"col1\">\n                <ion-icon name=\"ios-arrow-forward\"></ion-icon>\n              </ion-col>\n        </ion-row>\n      </ion-grid>\n         </div>\n         <div class=\"box blg\" (click)=\"goToEditAppointmentPage()\">\n          <ion-grid>\n        <ion-row>\n          <ion-col size=\"3\" style=\"text-align:center;\">\n          <ion-label class=\"fmc\"><span class=\"fs12\">Jun</span><br><span class=\"fs23\"> 21</span><br><span class=\"fs12\">11:00 AM</span></ion-label>\n          </ion-col>\n          <ion-col size=\"1\" style=\"border-right:1px solid gray;\">\n          </ion-col>\n          <ion-col size=\"7\" style=\"text-align:left;\">\n              <ion-label class=\"fmc\"><span class=\"fs9 clrg\">{{ 'tab3.confirmed' | translate }}</span><br><span class=\"fs13\">Make By GLR</span><br><span class=\"fs9 clrgr\">Regular Haircut/ No taper with Charles…</span></ion-label>\n            </ion-col>\n            <ion-col size=\"1\" class=\"col1\">\n                <ion-icon name=\"ios-arrow-forward\"></ion-icon>\n              </ion-col>\n        </ion-row>\n      </ion-grid>\n           </div>-->\n    </div>\n  </div>\n</div>\n  <div *ngIf=\"editAppointment\" style=\"background: white;height:100%;\">\n  <div class=\"pt10 ml10 mr10 fs10\">\n    <ion-label class=\"clrg\">{{ 'tab3.confirmed' | translate }}</ion-label>\n    <ion-row>\n      <ion-col size=\"9.5\">\n        <ion-label class=\"fs12\">FRI, Jun 21, 2019, 11:00AM</ion-label>\n      </ion-col>\n      <ion-col size=\"2.5\">\n        <ion-label><button class=\"btn1\">{{ 'tab3.call' | translate }}</button></ion-label>\n      </ion-col>\n    </ion-row>  \n    <ion-label><img src=\"assets/images/note_add.svg\">&nbsp;{{ 'tab3.reminder' | translate }}</ion-label>\n  </div>\n    <div class=\"map\" id=\"map_canvas\"></div>\n    <div class=\"mt10\">\n      <ion-row>\n        <ion-col class=\"left\" size=\"9\">\n          <ion-label>Kids Hair with extensions</ion-label>\n        </ion-col>\n        <ion-col class=\"txtr\"  size=\"3\" >\n          <ion-label>10 DBH</ion-label><br>\n        </ion-col>\n      </ion-row>\n      <ion-row class=\"mt12\">\n        <ion-col size=\"8\">\n        </ion-col>\n        <ion-col size=\"4\">\n          <ion-label class=\"fs7\">11:00AM - 11:30 AM</ion-label>\n        </ion-col>\n      </ion-row>\n    </div>\n    <div class=\"btn\">\n      <ion-button class=\"changebtn\" fill=\"clear\" (click)=\"changeAppointments()\" >\n        {{ 'tab3.change' | translate }}\n      </ion-button>\n      <ion-button class=\"cancelbtn\" fill=\"clear\" (click)=\"cancelAppointment()\" >\n        {{ 'tab3.cancel' | translate }}\n      </ion-button>\n    </div>\n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/tab3/tab3.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab3/tab3.module.ts ***!
  \*************************************/
/*! exports provided: Tab3PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab3PageModule", function() { return Tab3PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _tab3_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab3.page */ "./src/app/tab3/tab3.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");








var Tab3PageModule = /** @class */ (function () {
    function Tab3PageModule() {
    }
    Tab3PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab3_page__WEBPACK_IMPORTED_MODULE_6__["Tab3Page"] }])
            ],
            declarations: [_tab3_page__WEBPACK_IMPORTED_MODULE_6__["Tab3Page"]]
        })
    ], Tab3PageModule);
    return Tab3PageModule;
}());



/***/ }),

/***/ "./src/app/tab3/tab3.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab3/tab3.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-toolbar {\n  --background:#2A2A2A;\n  padding: 5px;\n}\n\n.fontMoteret {\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n}\n\nion-content {\n  --background:black;\n}\n\n.fmc {\n  color: white;\n  font-family: \"Cairo\", sans-serif;\n}\n\n.box {\n  border-radius: 8px;\n  background-color: #2A2A2A;\n  color: white;\n  margin-top: 15px;\n}\n\n.blr {\n  border-left: 5px solid #ED145B;\n}\n\n.blg {\n  border-left: 5px solid #16A085;\n}\n\n.fs12 {\n  font-size: 12pt;\n}\n\n.fs23 {\n  font-size: 23pt;\n}\n\n.fs13 {\n  font-size: 13pt;\n}\n\n.fs9 {\n  font-size: 9pt;\n}\n\n.clrw {\n  color: white;\n}\n\n.clrg {\n  color: #16A085;\n}\n\n.clrgr {\n  color: #999999;\n}\n\n.col1 {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n  align-items: center;\n}\n\n.fs10 {\n  font-size: 10pt;\n}\n\n.bg1 {\n  --background:white;\n}\n\n.bg1 ion-list {\n  background-color: white;\n  color: black;\n}\n\n.bg1 .clrw {\n  color: black;\n}\n\n.clrg {\n  color: #16A085;\n}\n\n.mt10 {\n  margin-top: 10px;\n}\n\n.ml10 {\n  margin-left: 10px;\n}\n\n.fs10 {\n  font-size: 10pt;\n}\n\n.btn1 {\n  padding: 8px;\n  background-color: #16A085;\n  color: white;\n}\n\n.fs12 {\n  font-size: 12pt;\n}\n\n.map {\n  background: #e2e2e2;\n  height: 130px;\n  width: 100%;\n}\n\n.mt10 {\n  margin-top: 10px;\n}\n\n.fs7 {\n  font-size: 7pt;\n}\n\n.mt12 {\n  margin-top: -12px;\n}\n\n.changebtn {\n  --border-color:white;\n  --color:white;\n  --border-width:1px;\n  --color-activated:white;\n  text-transform: none;\n  border: 1px solid white;\n  width: 140px;\n  --color-focused:white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  background-color: #707070;\n  margin-right: 10px;\n  margin-left: 10px;\n}\n\n.btn {\n  position: absolute;\n  bottom: 20px;\n  left: 20px;\n}\n\n.cancelbtn {\n  --border-color: #ED145B;\n  --color: #ED145B;\n  --border-width: 1px;\n  --color-activated: white;\n  text-transform: none;\n  border: 1px solid #ED145B;\n  width: 140px;\n  --color-focused: white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n\n.txtr {\n  text-align: right;\n}\n\n.pt10 {\n  padding-top: 10px;\n}\n\n.mr10 {\n  margin-right: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL3RhYjMvdGFiMy5wYWdlLnNjc3MiLCJzcmMvYXBwL3RhYjMvdGFiMy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQkFBQTtFQUNDLFlBQUE7QUNDSDs7QURDRTtFQUNFLGdEQUFBO0VBQ0EsWUFBQTtBQ0VKOztBREFFO0VBQ0Usa0JBQUE7QUNHSjs7QURERTtFQUNFLFlBQUE7RUFDQSxnQ0FBQTtBQ0lKOztBREZFO0VBQ0Usa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ0tKOztBREhFO0VBQ0UsOEJBQUE7QUNNSjs7QURKRTtFQUNFLDhCQUFBO0FDT0o7O0FETEU7RUFDRSxlQUFBO0FDUUo7O0FETkU7RUFDRSxlQUFBO0FDU0o7O0FEUEU7RUFDRSxlQUFBO0FDVUo7O0FEUkU7RUFDRSxjQUFBO0FDV0o7O0FEVEU7RUFDRSxZQUFBO0FDWUo7O0FEVkU7RUFDRSxjQUFBO0FDYUo7O0FEWEU7RUFDRSxjQUFBO0FDY0o7O0FEWkU7RUFDRSxvQkFBQTtFQUFBLGFBQUE7RUFHQSx5QkFBQTtFQUNBLG1CQUFBO0FDZUo7O0FEYkU7RUFDRSxlQUFBO0FDZ0JKOztBRGJFO0VBQ0Usa0JBQUE7QUNnQko7O0FEZEk7RUFDRSx1QkFBQTtFQUNBLFlBQUE7QUNnQk47O0FEYkk7RUFDRSxZQUFBO0FDZU47O0FEWkU7RUFDRSxjQUFBO0FDZUo7O0FEYkE7RUFDSSxnQkFBQTtBQ2dCSjs7QURkQTtFQUNJLGlCQUFBO0FDaUJKOztBRGZBO0VBQ0ksZUFBQTtBQ2tCSjs7QURoQkE7RUFDSSxZQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0FDbUJKOztBRGhCRTtFQUNJLGVBQUE7QUNtQk47O0FEakJFO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsV0FBQTtBQ29CRjs7QURsQkE7RUFDSSxnQkFBQTtBQ3FCSjs7QURuQkE7RUFDSSxjQUFBO0FDc0JKOztBRHBCQTtFQUNJLGlCQUFBO0FDdUJKOztBRHJCQTtFQUNJLG9CQUFBO0VBQ0EsYUFBQTtFQUdELGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxvQkFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0EscURBQUE7RUFDRCx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUNzQkY7O0FEcEJFO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtBQ3VCSjs7QURyQkE7RUFDSSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSx3QkFBQTtFQUNBLG9CQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxxREFBQTtBQ3dCSjs7QUR0QkE7RUFDRSxpQkFBQTtBQ3lCRjs7QUR2QkE7RUFDRSxpQkFBQTtBQzBCRjs7QUR4QkE7RUFDRSxrQkFBQTtBQzJCRiIsImZpbGUiOiJzcmMvYXBwL3RhYjMvdGFiMy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhcntcbiAgLS1iYWNrZ3JvdW5kOiMyQTJBMkE7XG4gICBwYWRkaW5nOjVweDtcbiAgfVxuICAuZm9udE1vdGVyZXR7XG4gICAgZm9udC1mYW1pbHk6ICdNb250c2VycmF0Jywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICAgIGNvbG9yOndoaXRlO1xuICB9XG4gIGlvbi1jb250ZW50e1xuICAgIC0tYmFja2dyb3VuZDpibGFjazsgIFxuICB9XG4gIC5mbWN7XG4gICAgY29sb3I6IHdoaXRlO1xuICAgIGZvbnQtZmFtaWx5OiAnQ2Fpcm8nLCBzYW5zLXNlcmlmO1xuICB9XG4gIC5ib3h7XG4gICAgYm9yZGVyLXJhZGl1czo4cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzJBMkEyQTtcbiAgICBjb2xvcjp3aGl0ZTtcbiAgICBtYXJnaW4tdG9wOjE1cHg7XG4gIH1cbiAgLmJscntcbiAgICBib3JkZXItbGVmdDo1cHggc29saWQgI0VEMTQ1QjtcbiAgfVxuICAuYmxne1xuICAgIGJvcmRlci1sZWZ0OjVweCBzb2xpZCAjMTZBMDg1O1xuICB9XG4gIC5mczEye1xuICAgIGZvbnQtc2l6ZToxMnB0O1xuICB9XG4gIC5mczIze1xuICAgIGZvbnQtc2l6ZToyM3B0O1xuICB9XG4gIC5mczEze1xuICAgIGZvbnQtc2l6ZToxM3B0O1xuICB9XG4gIC5mczl7XG4gICAgZm9udC1zaXplOjlwdDtcbiAgfVxuICAuY2xyd3tcbiAgICBjb2xvcjp3aGl0ZTtcbiAgfVxuICAuY2xyZ3tcbiAgICBjb2xvcjojMTZBMDg1O1xuICB9XG4gIC5jbHJncntcbiAgICBjb2xvcjojOTk5OTk5O1xuICB9XG4gIC5jb2wxe1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgLW1zLWZsZXgtYWxpZ246IGNlbnRlcjtcbiAgICAtd2Via2l0LWFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgLXdlYmtpdC1ib3gtYWxpZ246IGNlbnRlcjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyOyAgICAgIFxuICB9XG4gIC5mczEwe1xuICAgIGZvbnQtc2l6ZToxMHB0O1xuICB9XG5cbiAgLmJnMXtcbiAgICAtLWJhY2tncm91bmQ6d2hpdGU7XG4gIFxuICAgIGlvbi1saXN0IHtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6d2hpdGU7XG4gICAgICBjb2xvcjpibGFjaztcbiAgICB9XG5cbiAgICAuY2xydyB7XG4gICAgICBjb2xvcjpibGFjaztcbiAgICB9XG4gIH1cbiAgLmNscmd7XG4gICAgY29sb3I6IzE2QTA4NTtcbn1cbi5tdDEwe1xuICAgIG1hcmdpbi10b3A6MTBweDtcbn1cbi5tbDEwe1xuICAgIG1hcmdpbi1sZWZ0OjEwcHg7XG59XG4uZnMxMHtcbiAgICBmb250LXNpemU6MTBwdDtcbn1cbi5idG4xIHtcbiAgICBwYWRkaW5nOiA4cHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzE2QTA4NTtcbiAgICBjb2xvcjp3aGl0ZTtcbiAgICAvL21hcmdpbi1sZWZ0OiAxMnB4O1xuICB9XG4gIC5mczEye1xuICAgICAgZm9udC1zaXplOjEycHQ7XG4gIH1cbiAgLm1hcHtcbiAgYmFja2dyb3VuZDogI2UyZTJlMjtcbiAgaGVpZ2h0OiAxMzBweDtcbiAgd2lkdGg6IDEwMCU7XG59XG4ubXQxMHtcbiAgICBtYXJnaW4tdG9wOjEwcHg7XG59XG4uZnM3e1xuICAgIGZvbnQtc2l6ZTo3cHQ7XG59XG4ubXQxMntcbiAgICBtYXJnaW4tdG9wOi0xMnB4O1xufVxuLmNoYW5nZWJ0bntcbiAgICAtLWJvcmRlci1jb2xvcjp3aGl0ZTtcbiAgICAtLWNvbG9yOndoaXRlO1xuICAgLy8gZm9udC1mYW1pbHk6TW9udHNlcnJhdDtcbiAgIC8vIGZvbnQtc2l6ZTogMTZwdDtcbiAgIC0tYm9yZGVyLXdpZHRoOjFweDtcbiAgIC0tY29sb3ItYWN0aXZhdGVkOndoaXRlO1xuICAgdGV4dC10cmFuc2Zvcm06bm9uZTtcbiAgIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICAgd2lkdGg6IDE0MHB4O1xuICAgLS1jb2xvci1mb2N1c2VkOndoaXRlO1xuICAgZm9udC1mYW1pbHk6J1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzcwNzA3MDtcbiAgbWFyZ2luLXJpZ2h0OjEwcHg7XG4gIG1hcmdpbi1sZWZ0OjEwcHg7XG4gIH1cbiAgLmJ0biB7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvdHRvbTogMjBweDtcbiAgICBsZWZ0OjIwcHg7XG59XG4uY2FuY2VsYnRue1xuICAgIC0tYm9yZGVyLWNvbG9yOiAjRUQxNDVCO1xuICAgIC0tY29sb3I6ICNFRDE0NUI7XG4gICAgLS1ib3JkZXItd2lkdGg6IDFweDtcbiAgICAtLWNvbG9yLWFjdGl2YXRlZDogd2hpdGU7XG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI0VEMTQ1QjtcbiAgICB3aWR0aDogMTQwcHg7XG4gICAgLS1jb2xvci1mb2N1c2VkOiB3aGl0ZTtcbiAgICBmb250LWZhbWlseTogJ1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cbi50eHRye1xuICB0ZXh0LWFsaWduOnJpZ2h0O1xufVxuLnB0MTB7XG4gIHBhZGRpbmctdG9wOjEwcHg7XG59XG4ubXIxMHtcbiAgbWFyZ2luLXJpZ2h0OjEwcHg7XG59IiwiaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6IzJBMkEyQTtcbiAgcGFkZGluZzogNXB4O1xufVxuXG4uZm9udE1vdGVyZXQge1xuICBmb250LWZhbWlseTogXCJNb250c2VycmF0XCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDpibGFjaztcbn1cblxuLmZtYyB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZm9udC1mYW1pbHk6IFwiQ2Fpcm9cIiwgc2Fucy1zZXJpZjtcbn1cblxuLmJveCB7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzJBMkEyQTtcbiAgY29sb3I6IHdoaXRlO1xuICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuXG4uYmxyIHtcbiAgYm9yZGVyLWxlZnQ6IDVweCBzb2xpZCAjRUQxNDVCO1xufVxuXG4uYmxnIHtcbiAgYm9yZGVyLWxlZnQ6IDVweCBzb2xpZCAjMTZBMDg1O1xufVxuXG4uZnMxMiB7XG4gIGZvbnQtc2l6ZTogMTJwdDtcbn1cblxuLmZzMjMge1xuICBmb250LXNpemU6IDIzcHQ7XG59XG5cbi5mczEzIHtcbiAgZm9udC1zaXplOiAxM3B0O1xufVxuXG4uZnM5IHtcbiAgZm9udC1zaXplOiA5cHQ7XG59XG5cbi5jbHJ3IHtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uY2xyZyB7XG4gIGNvbG9yOiAjMTZBMDg1O1xufVxuXG4uY2xyZ3Ige1xuICBjb2xvcjogIzk5OTk5OTtcbn1cblxuLmNvbDEge1xuICBkaXNwbGF5OiBmbGV4O1xuICAtbXMtZmxleC1hbGlnbjogY2VudGVyO1xuICAtd2Via2l0LWFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIC13ZWJraXQtYm94LWFsaWduOiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5mczEwIHtcbiAgZm9udC1zaXplOiAxMHB0O1xufVxuXG4uYmcxIHtcbiAgLS1iYWNrZ3JvdW5kOndoaXRlO1xufVxuLmJnMSBpb24tbGlzdCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBjb2xvcjogYmxhY2s7XG59XG4uYmcxIC5jbHJ3IHtcbiAgY29sb3I6IGJsYWNrO1xufVxuXG4uY2xyZyB7XG4gIGNvbG9yOiAjMTZBMDg1O1xufVxuXG4ubXQxMCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5tbDEwIHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5cbi5mczEwIHtcbiAgZm9udC1zaXplOiAxMHB0O1xufVxuXG4uYnRuMSB7XG4gIHBhZGRpbmc6IDhweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE2QTA4NTtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uZnMxMiB7XG4gIGZvbnQtc2l6ZTogMTJwdDtcbn1cblxuLm1hcCB7XG4gIGJhY2tncm91bmQ6ICNlMmUyZTI7XG4gIGhlaWdodDogMTMwcHg7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ubXQxMCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5mczcge1xuICBmb250LXNpemU6IDdwdDtcbn1cblxuLm10MTIge1xuICBtYXJnaW4tdG9wOiAtMTJweDtcbn1cblxuLmNoYW5nZWJ0biB7XG4gIC0tYm9yZGVyLWNvbG9yOndoaXRlO1xuICAtLWNvbG9yOndoaXRlO1xuICAtLWJvcmRlci13aWR0aDoxcHg7XG4gIC0tY29sb3ItYWN0aXZhdGVkOndoaXRlO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gIHdpZHRoOiAxNDBweDtcbiAgLS1jb2xvci1mb2N1c2VkOndoaXRlO1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNzA3MDcwO1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4uYnRuIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDIwcHg7XG4gIGxlZnQ6IDIwcHg7XG59XG5cbi5jYW5jZWxidG4ge1xuICAtLWJvcmRlci1jb2xvcjogI0VEMTQ1QjtcbiAgLS1jb2xvcjogI0VEMTQ1QjtcbiAgLS1ib3JkZXItd2lkdGg6IDFweDtcbiAgLS1jb2xvci1hY3RpdmF0ZWQ6IHdoaXRlO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgYm9yZGVyOiAxcHggc29saWQgI0VEMTQ1QjtcbiAgd2lkdGg6IDE0MHB4O1xuICAtLWNvbG9yLWZvY3VzZWQ6IHdoaXRlO1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG4udHh0ciB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuXG4ucHQxMCB7XG4gIHBhZGRpbmctdG9wOiAxMHB4O1xufVxuXG4ubXIxMCB7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/tab3/tab3.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab3/tab3.page.ts ***!
  \***********************************/
/*! exports provided: Tab3Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab3Page", function() { return Tab3Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modal_appointmentmodal_appointmentmodal_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../modal/appointmentmodal/appointmentmodal.page */ "./src/app/modal/appointmentmodal/appointmentmodal.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_business_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/business.service */ "./src/app/services/business.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");








var Tab3Page = /** @class */ (function () {
    function Tab3Page(navCtrl, modalCtrl, translate, businessService, route) {
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.translate = translate;
        this.businessService = businessService;
        this.route = route;
        this.today = new Date();
        this.themes = 'black';
        this.Appointment = true;
        this.editAppointment = false;
        this.userDetails = {};
        this.appointmentData = {};
        this.appointmentDatas = {};
        this.shownoappointment = false;
        this.showappointment = false;
        this.todayData = [];
        this.upcomingData = [];
        this.with_service = [];
        this.businessDetails = [];
        this.businessData = [];
        this.appintmentData = {};
        this.themes = localStorage.getItem("themes");
        this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
        console.log('user', this.userDetails);
        this.businessData = JSON.parse(localStorage.getItem("businessData"));
        console.log('data', this.businessData);
        this.appintmentData = JSON.parse(localStorage.getItem("appintmentData"));
        console.log('appoint', this.appintmentData);
    }
    Tab3Page.prototype.ngOnInit = function () {
        this.getAppointmentList();
        var date = new Date();
        this.todaydate = date.getUTCFullYear() + '-' + (date.getUTCMonth() + 1) + '-' + date.getUTCDate();
    };
    Tab3Page.prototype.goToEditAppointmentPage = function () {
        //this.navCtrl.navigateForward('editappointment');
        this.Appointment = false;
        this.editAppointment = true;
    };
    Tab3Page.prototype.goToAppointmentPage = function () {
        this.editAppointment = false;
        this.Appointment = true;
    };
    Tab3Page.prototype.cancelAppointment = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _modal_appointmentmodal_appointmentmodal_page__WEBPACK_IMPORTED_MODULE_3__["AppointmentmodalPage"],
                            cssClass: 'my-custom-modal-css'
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.onDidDismiss().then(function (data) {
                            console.log(data);
                            _this.goToAppointmentPage();
                        });
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    Tab3Page.prototype.goToTab3Page = function () {
        this.editAppointment = false;
        this.Appointment = true;
    };
    Tab3Page.prototype.changeAppointments = function () {
        this.navCtrl.navigateForward('/bookappointment');
    };
    Tab3Page.prototype.getAppointmentList = function () {
        var _this = this;
        if (this.userDetails) {
            this.appointmentDatas = {
                "user_id": this.userDetails.id,
                "role_id": this.userDetails.role_id, "token": this.userDetails.token.original.token
            };
            console.log('apdata', this.appointmentDatas);
            this.businessService.appointmentList(this.appointmentDatas).subscribe(function (res) {
                console.log(res);
                if (res.status == 'success') {
                    _this.appointmentlist = res.data.user;
                    console.log('list', _this.appointmentlist);
                    localStorage.setItem("appointmentlist", JSON.stringify(_this.appointmentlist));
                    _this.showappointment = true;
                    _this.shownoappointment = false;
                    for (var i = 0; i < _this.appointmentlist.length; i++) {
                        var item = new Date(_this.appointmentlist[i].appointment_date).getTime();
                        var today = new Date(_this.todaydate).getTime();
                        if (item == today) {
                            _this.todayData.push(_this.appointmentlist[i]);
                        }
                        if (item != today) {
                            _this.upcomingData.push(_this.appointmentlist[i]);
                        }
                    }
                    console.log(_this.todayData);
                    console.log(_this.upcomingData);
                }
                else if (res.status == 'fail') {
                    _this.showappointment = false;
                    _this.shownoappointment = true;
                }
            });
        }
    };
    Tab3Page.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateService"] },
        { type: _services_business_service__WEBPACK_IMPORTED_MODULE_5__["BusinessService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] }
    ]; };
    Tab3Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tab3',
            template: __webpack_require__(/*! raw-loader!./tab3.page.html */ "./node_modules/raw-loader/index.js!./src/app/tab3/tab3.page.html"),
            styles: [__webpack_require__(/*! ./tab3.page.scss */ "./src/app/tab3/tab3.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateService"],
            _services_business_service__WEBPACK_IMPORTED_MODULE_5__["BusinessService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]])
    ], Tab3Page);
    return Tab3Page;
}());



/***/ })

}]);
//# sourceMappingURL=tab3-tab3-module.js.map