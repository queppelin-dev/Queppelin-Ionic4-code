(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["payments-payments-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/payments/payments.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/payments/payments.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header *ngIf=\"showHeader\">\n    <ion-toolbar color=\"primary\" mode=\"ios\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button></ion-back-button>\n      </ion-buttons>\n      <ion-title>{{ 'payment.onlinepayment' | translate }}</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div>\n    <div class=\"online\" *ngIf=\"onlinepage\">\n    <img src=\"assets/images/payment.svg\"><br>\n    <div style=\"margin-top:15px;\">\n    <ion-label class=\"clrg\">{{ 'payment.onlinepayment' | translate }}</ion-label>\n    </div>\n    <div class=\"mt5\">\n    <ion-label class=\"fontSans fs10\">{{ 'payment.payservice' | translate }}</ion-label>\n    </div>\n    <div class=\"mt5\">\n    <ion-button class=\"btn\" fill=\"clear\" (click)=\"gotoPaymentPage()\">\n      {{ 'payment.addpayment' | translate }}\n      </ion-button>\n  </div>\n  </div>\n  <div class=\"payment\" *ngIf=\"paymentPage\">\n      <div class=\"sort bb2\">\n          <ion-label>{{ 'payment.addpayment' | translate }}</ion-label>\n        </div>\n        <div class=\"form\">\n            <ion-item>\n              <ion-input type=\"text\" placeholder=\"{{ 'payment.username' | translate }}\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-input type=\"text\" placeholder=\"{{ 'payment.Card number' | translate }}\"></ion-input>\n            </ion-item>\n          </div>\n            <div style=\"margin:6px;\">\n             <ion-row>\n               <ion-col>\n                  <ion-item>\n                      <ion-input type=\"text\" placeholder=\"{{ 'payment.exp' | translate }}\"></ion-input>\n                    </ion-item>\n               </ion-col>\n               <ion-col>\n                  <ion-item>\n                      <ion-input type=\"text\" placeholder=\"{{ 'payment.cvv' | translate }}\"></ion-input>\n                    </ion-item>\n               </ion-col>\n             </ion-row>     \n        </div>\n        <div class=\"textcntr\">\n        <ion-button class=\"btn\" fill=\"clear\" (click)=\"gotoCardSuccessPage()\">\n          {{ 'payment.addcard' | translate }}  \n          </ion-button>\n        </div>\n        <div class=\"mt10\">\n            <div class=\"sort bt2 bb2\">\n                <ion-label>{{ 'payment.savedcard' | translate }}  </ion-label>\n            </div>\n        </div>\n        <div class=\"m10\">\n        <ion-list>\n            <ion-item>\n              <img src=\"assets/images/smartphone.svg\">&nbsp;&nbsp;\n             <ion-label><span class=\"clrphone\">{{ 'payment.visa' | translate }}</span><br>\n              <span class=\"fs9 clrphone\">{{ 'payment.creditcard' | translate }}, 3243</span></ion-label>\n              <button class=\"delbtn\" fill=\"clear\" slot=\"end\">{{ 'payment.deletebtn' | translate }}</button>\n            </ion-item>\n            <ion-item>\n                <img src=\"assets/images/smartphone.svg\">&nbsp;&nbsp;\n               <ion-label><span class=\"clrphone\">{{ 'payment.mastercard' | translate }}</span><br>\n                <span class=\"fs9 clrphone\">{{ 'payment.creditcard' | translate }}, 3243</span></ion-label>\n                <button class=\"delbtn\" fill=\"clear\" slot=\"end\">{{ 'payment.deletebtn' | translate }}</button>\n              </ion-item>\n              <ion-item>\n                  <img src=\"assets/images/smartphone.svg\">&nbsp;&nbsp;\n                 <ion-label><span class=\"clrphone\">{{ 'payment.mastercard' | translate }}</span><br>\n                  <span class=\"fs9 clrphone\">{{ 'payment.creditcard' | translate }}, 3243</span></ion-label>\n                  <button class=\"delbtn\" fill=\"clear\" slot=\"end\">{{ 'payment.deletebtn' | translate }}</button>\n                </ion-item>\n            </ion-list>\n            </div>\n          </div>\n          <div class=\"cardsuccess\" *ngIf=\"cardsuccess\">\n           <div style=\"text-align:center;margin-top:110px;\">\n           <img src=\"assets/images/cardsuccess.svg\">\n           \n           <div class=\"mt10\">\n           <ion-label class=\"clrgrn\">{{ 'payment.cardaddedsuccess' | translate }}</ion-label>\n           </div>\n           <div class=\"mt5\">\n              <ion-label class=\"clrgrn fontSans fs9\">{{ 'payment.providedcard' | translate }}.</ion-label>\n           </div>\n           <div class=\"mt10\">\n              <ion-button class=\"btn\" fill=\"clear\" (click)=\"goTOpaymentPage()\">\n                {{ 'payment.backcarddetails' | translate }}\n              </ion-button>\n           </div>\n           </div>\n          </div>\n          <div class=\"cardfail\" *ngIf=\"cardfail\">\n              <div class=\"textcntr mt110\">\n              <img src=\"assets/images/cardfail.svg\">\n              \n              <div class=\"mt10\">\n              <ion-label class=\"clrred\">{{ 'payment.cardaddedfailed' | translate }}</ion-label>\n              </div>\n              <div class=\"mt5\">\n                 <ion-label class=\"clrred fontSans fs9\">{{ 'payment.providedcard' | translate }}</ion-label>\n              </div>\n              <div class=\"mt10\">\n                 <ion-button class=\"btn\" fill=\"clear\" (click)=\"goTOpaymentPage()\">\n                  {{ 'payment.backcarddetails' | translate }} \n                 </ion-button>\n              </div>\n              </div>\n            </div>\n        </div>\n      </ion-content>\n"

/***/ }),

/***/ "./src/app/payments/payments.module.ts":
/*!*********************************************!*\
  !*** ./src/app/payments/payments.module.ts ***!
  \*********************************************/
/*! exports provided: PaymentsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentsPageModule", function() { return PaymentsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _payments_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./payments.page */ "./src/app/payments/payments.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");








var routes = [
    {
        path: '',
        component: _payments_page__WEBPACK_IMPORTED_MODULE_6__["PaymentsPage"]
    }
];
var PaymentsPageModule = /** @class */ (function () {
    function PaymentsPageModule() {
    }
    PaymentsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_payments_page__WEBPACK_IMPORTED_MODULE_6__["PaymentsPage"]]
        })
    ], PaymentsPageModule);
    return PaymentsPageModule;
}());



/***/ }),

/***/ "./src/app/payments/payments.page.scss":
/*!*********************************************!*\
  !*** ./src/app/payments/payments.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".online {\n  text-align: center;\n  margin-top: 125px;\n}\n\n.fontSans {\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n\n.fontMoteret {\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n}\n\n.clrg {\n  color: #2A2A2A;\n}\n\n.fs10 {\n  font-size: 10pt;\n}\n\n.btn {\n  --border-color:white;\n  --color:white;\n  --border-width:1px;\n  --color-activated:white;\n  text-transform: none;\n  border: 1px solid white;\n  width: 265px;\n  --color-focused:white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  background: black;\n}\n\n.mt5 {\n  margin-top: 5px;\n}\n\n.sort {\n  padding-top: 6pt;\n  color: black;\n  background: #E6E6E6;\n  padding-bottom: 6pt;\n  padding-left: 12px;\n  padding-right: 12px;\n}\n\n.form {\n  margin: 12px;\n}\n\nion-item {\n  --padding-start:0px !important;\n}\n\n.bt2 {\n  border-bottom: 2px solid #cabdbd;\n}\n\n.bb2 {\n  border-top: 2px solid #cabdbd;\n}\n\n.m10 {\n  margin: 10px;\n}\n\n.delbtn {\n  --border-color:#ED145B;\n  color: #ED145B;\n  --border-width:1px;\n  --color-activated:white;\n  text-transform: none;\n  border: 1px solid #ED145B;\n  width: 55px;\n  --color-focused:white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  background: white;\n  padding: 5px;\n}\n\n.fs9 {\n  font-size: 9pt;\n}\n\n.clrphone {\n  color: #636162;\n}\n\n.clrgrn {\n  color: #16A085;\n}\n\n.mt10 {\n  margin-top: 10px;\n}\n\n.mt5 {\n  margin-top: 5px;\n}\n\n.clrred {\n  color: #ED145B;\n}\n\n.textcntr {\n  text-align: center;\n}\n\n.mt110 {\n  margin-top: 110px;\n}\n\n.mt10 {\n  margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL3BheW1lbnRzL3BheW1lbnRzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGF5bWVudHMvcGF5bWVudHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQ0NBOztBRENBO0VBQ0kscURBQUE7QUNFSjs7QURBRTtFQUNFLGdEQUFBO0VBQ0EsWUFBQTtBQ0dKOztBRERFO0VBQ0EsY0FBQTtBQ0lGOztBREZFO0VBQ0ksZUFBQTtBQ0tOOztBREhFO0VBQ0Usb0JBQUE7RUFDQSxhQUFBO0VBQ0Qsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLG9CQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxxREFBQTtFQUNELGlCQUFBO0FDTUY7O0FESkU7RUFDSSxlQUFBO0FDT047O0FETEU7RUFDRSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBRUYsa0JBQUE7RUFDQSxtQkFBQTtBQ09GOztBRExFO0VBQ0ksWUFBQTtBQ1FOOztBRE5FO0VBQ0ksOEJBQUE7QUNTTjs7QURQRTtFQUNJLGdDQUFBO0FDVU47O0FEUkE7RUFDSSw2QkFBQTtBQ1dKOztBRFRBO0VBQ0ksWUFBQTtBQ1lKOztBRFZBO0VBQ0ksc0JBQUE7RUFDQSxjQUFBO0VBQ0Qsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLG9CQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxxREFBQTtFQUNELGlCQUFBO0VBQ0EsWUFBQTtBQ2FGOztBRFhBO0VBQ0ksY0FBQTtBQ2NKOztBRFpBO0VBQ0ksY0FBQTtBQ2VKOztBRGJBO0VBQ0ksY0FBQTtBQ2dCSjs7QURkQTtFQUNJLGdCQUFBO0FDaUJKOztBRGZBO0VBQ0ksZUFBQTtBQ2tCSjs7QURoQkE7RUFDSSxjQUFBO0FDbUJKOztBRGpCQTtFQUNJLGtCQUFBO0FDb0JKOztBRGxCQTtFQUNJLGlCQUFBO0FDcUJKOztBRG5CQTtFQUNJLGdCQUFBO0FDc0JKIiwiZmlsZSI6InNyYy9hcHAvcGF5bWVudHMvcGF5bWVudHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm9ubGluZXtcbnRleHQtYWxpZ246Y2VudGVyO1xubWFyZ2luLXRvcDoxMjVweDtcbn1cbi5mb250U2Fuc3tcbiAgICBmb250LWZhbWlseTonU291cmNlIFNhbnMgUHJvJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICB9XG4gIC5mb250TW90ZXJldHtcbiAgICBmb250LWZhbWlseTogJ01vbnRzZXJyYXQnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gICAgY29sb3I6d2hpdGU7XG4gIH1cbiAgLmNscmd7XG4gIGNvbG9yOiMyQTJBMkE7XG4gIH1cbiAgLmZzMTB7XG4gICAgICBmb250LXNpemU6MTBwdDtcbiAgfVxuICAuYnRue1xuICAgIC0tYm9yZGVyLWNvbG9yOndoaXRlO1xuICAgIC0tY29sb3I6d2hpdGU7XG4gICAtLWJvcmRlci13aWR0aDoxcHg7XG4gICAtLWNvbG9yLWFjdGl2YXRlZDp3aGl0ZTtcbiAgIHRleHQtdHJhbnNmb3JtOm5vbmU7XG4gICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgIHdpZHRoOiAyNjVweDtcbiAgIC0tY29sb3ItZm9jdXNlZDp3aGl0ZTtcbiAgIGZvbnQtZmFtaWx5OidTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6YmxhY2s7XG4gIH1cbiAgLm10NXtcbiAgICAgIG1hcmdpbi10b3A6NXB4O1xuICB9XG4gIC5zb3J0e1xuICAgIHBhZGRpbmctdG9wOiA2cHQ7XG4gICAgY29sb3I6IGJsYWNrO1xuICAgIGJhY2tncm91bmQ6ICNFNkU2RTY7XG4gICAgcGFkZGluZy1ib3R0b206IDZwdDtcbiAgLy8gIHRleHQtYWxpZ246Y2VudGVyO1xuICBwYWRkaW5nLWxlZnQ6MTJweDtcbiAgcGFkZGluZy1yaWdodDoxMnB4O1xuICB9XG4gIC5mb3Jte1xuICAgICAgbWFyZ2luOjEycHg7XG4gIH1cbiAgaW9uLWl0ZW17XG4gICAgICAtLXBhZGRpbmctc3RhcnQ6MHB4ICFpbXBvcnRhbnQ7XG4gIH1cbiAgLmJ0MntcbiAgICAgIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjY2FiZGJkO1xufVxuLmJiMntcbiAgICBib3JkZXItdG9wOjJweCBzb2xpZCAjY2FiZGJkO1xufVxuLm0xMHtcbiAgICBtYXJnaW46MTBweDtcbn1cbi5kZWxidG57XG4gICAgLS1ib3JkZXItY29sb3I6I0VEMTQ1QjtcbiAgICBjb2xvcjojRUQxNDVCO1xuICAgLS1ib3JkZXItd2lkdGg6MXB4O1xuICAgLS1jb2xvci1hY3RpdmF0ZWQ6d2hpdGU7XG4gICB0ZXh0LXRyYW5zZm9ybTpub25lO1xuICAgYm9yZGVyOiAxcHggc29saWQgI0VEMTQ1QjtcbiAgIHdpZHRoOiA1NXB4O1xuICAgLS1jb2xvci1mb2N1c2VkOndoaXRlO1xuICAgZm9udC1mYW1pbHk6J1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZDp3aGl0ZTtcbiAgcGFkZGluZzo1cHg7XG59XG4uZnM5e1xuICAgIGZvbnQtc2l6ZTo5cHQ7XG59XG4uY2xycGhvbmV7XG4gICAgY29sb3I6IzYzNjE2Mjtcbn1cbi5jbHJncm57XG4gICAgY29sb3I6IzE2QTA4NTtcbn1cbi5tdDEwe1xuICAgIG1hcmdpbi10b3A6MTBweDtcbn1cbi5tdDV7XG4gICAgbWFyZ2luLXRvcDo1cHg7XG59XG4uY2xycmVke1xuICAgIGNvbG9yOiNFRDE0NUI7XG59XG4udGV4dGNudHJ7XG4gICAgdGV4dC1hbGlnbjpjZW50ZXI7XG59XG4ubXQxMTB7XG4gICAgbWFyZ2luLXRvcDoxMTBweDtcbn1cbi5tdDEwe1xuICAgIG1hcmdpbi10b3A6MTBweDtcbn0iLCIub25saW5lIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tdG9wOiAxMjVweDtcbn1cblxuLmZvbnRTYW5zIHtcbiAgZm9udC1mYW1pbHk6IFwiU291cmNlIFNhbnMgUHJvXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cblxuLmZvbnRNb3RlcmV0IHtcbiAgZm9udC1mYW1pbHk6IFwiTW9udHNlcnJhdFwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmNscmcge1xuICBjb2xvcjogIzJBMkEyQTtcbn1cblxuLmZzMTAge1xuICBmb250LXNpemU6IDEwcHQ7XG59XG5cbi5idG4ge1xuICAtLWJvcmRlci1jb2xvcjp3aGl0ZTtcbiAgLS1jb2xvcjp3aGl0ZTtcbiAgLS1ib3JkZXItd2lkdGg6MXB4O1xuICAtLWNvbG9yLWFjdGl2YXRlZDp3aGl0ZTtcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICB3aWR0aDogMjY1cHg7XG4gIC0tY29sb3ItZm9jdXNlZDp3aGl0ZTtcbiAgZm9udC1mYW1pbHk6IFwiU291cmNlIFNhbnMgUHJvXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZDogYmxhY2s7XG59XG5cbi5tdDUge1xuICBtYXJnaW4tdG9wOiA1cHg7XG59XG5cbi5zb3J0IHtcbiAgcGFkZGluZy10b3A6IDZwdDtcbiAgY29sb3I6IGJsYWNrO1xuICBiYWNrZ3JvdW5kOiAjRTZFNkU2O1xuICBwYWRkaW5nLWJvdHRvbTogNnB0O1xuICBwYWRkaW5nLWxlZnQ6IDEycHg7XG4gIHBhZGRpbmctcmlnaHQ6IDEycHg7XG59XG5cbi5mb3JtIHtcbiAgbWFyZ2luOiAxMnB4O1xufVxuXG5pb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDowcHggIWltcG9ydGFudDtcbn1cblxuLmJ0MiB7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjY2FiZGJkO1xufVxuXG4uYmIyIHtcbiAgYm9yZGVyLXRvcDogMnB4IHNvbGlkICNjYWJkYmQ7XG59XG5cbi5tMTAge1xuICBtYXJnaW46IDEwcHg7XG59XG5cbi5kZWxidG4ge1xuICAtLWJvcmRlci1jb2xvcjojRUQxNDVCO1xuICBjb2xvcjogI0VEMTQ1QjtcbiAgLS1ib3JkZXItd2lkdGg6MXB4O1xuICAtLWNvbG9yLWFjdGl2YXRlZDp3aGl0ZTtcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNFRDE0NUI7XG4gIHdpZHRoOiA1NXB4O1xuICAtLWNvbG9yLWZvY3VzZWQ6d2hpdGU7XG4gIGZvbnQtZmFtaWx5OiBcIlNvdXJjZSBTYW5zIFByb1wiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBwYWRkaW5nOiA1cHg7XG59XG5cbi5mczkge1xuICBmb250LXNpemU6IDlwdDtcbn1cblxuLmNscnBob25lIHtcbiAgY29sb3I6ICM2MzYxNjI7XG59XG5cbi5jbHJncm4ge1xuICBjb2xvcjogIzE2QTA4NTtcbn1cblxuLm10MTAge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4ubXQ1IHtcbiAgbWFyZ2luLXRvcDogNXB4O1xufVxuXG4uY2xycmVkIHtcbiAgY29sb3I6ICNFRDE0NUI7XG59XG5cbi50ZXh0Y250ciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLm10MTEwIHtcbiAgbWFyZ2luLXRvcDogMTEwcHg7XG59XG5cbi5tdDEwIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/payments/payments.page.ts":
/*!*******************************************!*\
  !*** ./src/app/payments/payments.page.ts ***!
  \*******************************************/
/*! exports provided: PaymentsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentsPage", function() { return PaymentsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");



var PaymentsPage = /** @class */ (function () {
    function PaymentsPage(translate) {
        this.translate = translate;
        this.onlinepage = true;
        this.showHeader = true;
        this.paymentPage = false;
        this.cardsuccess = false;
        this.cardfail = false;
    }
    PaymentsPage.prototype.ngOnInit = function () {
    };
    PaymentsPage.prototype.gotoPaymentPage = function () {
        this.onlinepage = false;
        this.paymentPage = true;
    };
    PaymentsPage.prototype.gotoCardSuccessPage = function () {
        this.onlinepage = false;
        this.showHeader = false;
        this.paymentPage = false;
        this.cardsuccess = true;
        // this.cardfail = true;
    };
    PaymentsPage.prototype.goTOpaymentPage = function () {
        this.onlinepage = false;
        this.showHeader = true;
        this.paymentPage = true;
        this.cardsuccess = false;
    };
    PaymentsPage.ctorParameters = function () { return [
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] }
    ]; };
    PaymentsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-payments',
            template: __webpack_require__(/*! raw-loader!./payments.page.html */ "./node_modules/raw-loader/index.js!./src/app/payments/payments.page.html"),
            styles: [__webpack_require__(/*! ./payments.page.scss */ "./src/app/payments/payments.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"]])
    ], PaymentsPage);
    return PaymentsPage;
}());



/***/ })

}]);
//# sourceMappingURL=payments-payments-module.js.map