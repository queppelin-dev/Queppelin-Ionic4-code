(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["settings-settings-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/settings/settings.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/settings/settings.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\" mode=\"ios\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ 'settings.setting' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <div class=\"title\">\n    <h5 class=\"title-style\">{{ 'settings.notification' | translate }}</h5>\n  </div>\n  <ion-item>\n    <h6 class=\"text-style\">{{ 'settings.account' | translate }}</h6>\n    <ion-toggle [(ngModel)]=\"personalinformations.account_details\" (ionChange)=\"changeToggle(personalinformations)\" slot=\"end\" mode=\"ios\"></ion-toggle>\n  </ion-item>\n  <div class=\"title\">\n    <h5 class=\"title-style\">{{ 'settings.appointmentstatus' | translate }}</h5>\n  </div>\n  <ion-list>\n    <ion-item>\n      <h6 class=\"text-style\">{{ 'settings.appnotification' | translate }}</h6>\n      <ion-toggle [(ngModel)]=\"personalinformations.app_notifiation\" (ionChange)=\"changeToggle(personalinformations)\" slot=\"end\" mode=\"ios\"></ion-toggle>\n    </ion-item>\n    <ion-item>\n      <h6 class=\"text-style\">{{ 'settings.email' | translate }}</h6>\n      <ion-toggle [(ngModel)]=\"personalinformations.email\" (ionChange)=\"changeToggle(personalinformations)\"  slot=\"end\" mode=\"ios\"></ion-toggle>\n    </ion-item>\n\n    <ion-item>\n      <h6 class=\"text-style\">{{ 'settings.sms' | translate }}</h6>\n      <ion-toggle [(ngModel)]=\"personalinformations.sms\" (ionChange)=\"changeToggle(personalinformations)\"  slot=\"end\" mode=\"ios\"></ion-toggle>\n    </ion-item>\n    <!-- <ion-item detail> \n      <h6 class=\"text-style\">{{ 'settings.review' | translate }}</h6>\n    </ion-item> -->\n  </ion-list>\n\n  <div class=\"title\" style=\"margin-top: -8px;\">\n    <h5 class=\"title-style\">{{ 'settings.setting' | translate }}</h5>\n  </div>\n  <ion-list>\n    <ion-item detail>\n      <h6 class=\"text-style\">{{ 'settings.changepassword' | translate }}</h6>\n    </ion-item>\n    <ion-item detail (click)=\"openLanguagePopover($event)\">\n      <h6 class=\"text-style\">{{ 'settings.automaticenglish' | translate }}</h6>\n    </ion-item>\n    <ion-item detail>\n    <h6 class=\"text-style\">{{ 'settings.themes' | translate }}</h6>\n    </ion-item>\n  </ion-list>\n  \n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/settings/settings.module.ts":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.module.ts ***!
  \*********************************************/
/*! exports provided: SettingsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPageModule", function() { return SettingsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./settings.page */ "./src/app/settings/settings.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");








var routes = [
    {
        path: '',
        component: _settings_page__WEBPACK_IMPORTED_MODULE_6__["SettingsPage"]
    }
];
var SettingsPageModule = /** @class */ (function () {
    function SettingsPageModule() {
    }
    SettingsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_settings_page__WEBPACK_IMPORTED_MODULE_6__["SettingsPage"]]
        })
    ], SettingsPageModule);
    return SettingsPageModule;
}());



/***/ }),

/***/ "./src/app/settings/settings.page.scss":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background:#f4f4f4;\n}\n\n.list-md {\n  background: none;\n}\n\nion-item {\n  --background:#f4f4f4 !important;\n}\n\n.title {\n  height: 50px;\n  background: #E6E6E6;\n  color: #2a2a2a !important;\n}\n\n.title-style {\n  font-size: 16px;\n  color: #636162;\n  padding-left: 16px;\n  padding-top: 15px;\n  padding-right: 16px;\n}\n\nh1, h2, h3, h4, h5, h6 {\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n\nion-toggle {\n  --background: #ED145B;\n  --background-checked: #16A085;\n  --handle-background: #FFFFFF;\n  --handle-background-checked:#FFFFFF;\n}\n\n.toggle-icon {\n  height: 25px;\n}\n\n.item-inner {\n  border: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL3NldHRpbmdzL3NldHRpbmdzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvc2V0dGluZ3Mvc2V0dGluZ3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksb0JBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0FDQ0o7O0FERUE7RUFDSSwrQkFBQTtBQ0NKOztBREVBO0VBQ0ksWUFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURFQTtFQUNJLHFCQUFBO0VBQ0EsNkJBQUE7RUFDQSw0QkFBQTtFQUNBLG1DQUFBO0FDQ0o7O0FERUE7RUFDSSxZQUFBO0FDQ0o7O0FERUE7RUFDSSxZQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9zZXR0aW5ncy9zZXR0aW5ncy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcbiAgICAtLWJhY2tncm91bmQ6I2Y0ZjRmNDtcbn1cblxuLmxpc3QtbWQge1xuICAgIGJhY2tncm91bmQ6bm9uZTtcbn1cblxuaW9uLWl0ZW0ge1xuICAgIC0tYmFja2dyb3VuZDojZjRmNGY0ICFpbXBvcnRhbnQ7XG59XG5cbi50aXRsZSB7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIGJhY2tncm91bmQ6ICNFNkU2RTY7XG4gICAgY29sb3I6IzJhMmEyYSAhaW1wb3J0YW50O1xufVxuXG4udGl0bGUtc3R5bGUge1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBjb2xvcjogIzYzNjE2MjtcbiAgICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gICAgcGFkZGluZy10b3A6IDE1cHg7XG4gICAgcGFkZGluZy1yaWdodDoxNnB4O1xufVxuXG5oMSwgaDIsIGgzLCBoNCwgaDUsIGg2IHtcbiAgICBtYXJnaW4tdG9wOiAwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG5pb24tdG9nZ2xlIHtcbiAgICAtLWJhY2tncm91bmQ6ICNFRDE0NUI7XG4gICAgLS1iYWNrZ3JvdW5kLWNoZWNrZWQ6ICMxNkEwODU7XG4gICAgLS1oYW5kbGUtYmFja2dyb3VuZDogI0ZGRkZGRjtcbiAgICAtLWhhbmRsZS1iYWNrZ3JvdW5kLWNoZWNrZWQ6I0ZGRkZGRjsgXG59XG5cbi50b2dnbGUtaWNvbiB7XG4gICAgaGVpZ2h0OjI1cHg7XG59XG5cbi5pdGVtLWlubmVyIHtcbiAgICBib3JkZXI6IG5vbmU7XG5cbn0iLCJpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDojZjRmNGY0O1xufVxuXG4ubGlzdC1tZCB7XG4gIGJhY2tncm91bmQ6IG5vbmU7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiNmNGY0ZjQgIWltcG9ydGFudDtcbn1cblxuLnRpdGxlIHtcbiAgaGVpZ2h0OiA1MHB4O1xuICBiYWNrZ3JvdW5kOiAjRTZFNkU2O1xuICBjb2xvcjogIzJhMmEyYSAhaW1wb3J0YW50O1xufVxuXG4udGl0bGUtc3R5bGUge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGNvbG9yOiAjNjM2MTYyO1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIHBhZGRpbmctdG9wOiAxNXB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxNnB4O1xufVxuXG5oMSwgaDIsIGgzLCBoNCwgaDUsIGg2IHtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbmlvbi10b2dnbGUge1xuICAtLWJhY2tncm91bmQ6ICNFRDE0NUI7XG4gIC0tYmFja2dyb3VuZC1jaGVja2VkOiAjMTZBMDg1O1xuICAtLWhhbmRsZS1iYWNrZ3JvdW5kOiAjRkZGRkZGO1xuICAtLWhhbmRsZS1iYWNrZ3JvdW5kLWNoZWNrZWQ6I0ZGRkZGRjtcbn1cblxuLnRvZ2dsZS1pY29uIHtcbiAgaGVpZ2h0OiAyNXB4O1xufVxuXG4uaXRlbS1pbm5lciB7XG4gIGJvcmRlcjogbm9uZTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/settings/settings.page.ts":
/*!*******************************************!*\
  !*** ./src/app/settings/settings.page.ts ***!
  \*******************************************/
/*! exports provided: SettingsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPage", function() { return SettingsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var _language_popover_language_popover_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../language-popover/language-popover.page */ "./src/app/language-popover/language-popover.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _language_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./../language.service */ "./src/app/language.service.ts");







var SettingsPage = /** @class */ (function () {
    function SettingsPage(translate, userService, popoverCtrl, alertCtrl, languageService) {
        this.translate = translate;
        this.userService = userService;
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.languageService = languageService;
        this.personalinformationsData = {};
        this.personalinformations = {};
        this.userDetails = {};
        this.checked = true;
        this.abc = {};
        this.languages = [];
        this.selected = '';
        this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
        console.log(this.userDetails);
    }
    SettingsPage.prototype.ngOnInit = function () {
        this.getPersonalInformation();
        // this.languages = this.languageService.getLanguages();
        // this.selected = this.languageService.selected;
    };
    SettingsPage.prototype.ionViewDidEnter = function () {
        // this.language = localStorage.getItem("language");
        //  this.languages = this.languageService.getLanguages();
        //  this.selected = this.languageService.selected;
        //   if(this.language == 'ar') {
        //     document.documentElement.dir = 'rtl';
        //   } 
        //   else if(this.language == 'en'){
        //     document.documentElement.dir = 'ltr';
        //   }
    };
    SettingsPage.prototype.getPersonalInformation = function () {
        var _this = this;
        if (this.userDetails) {
            this.personalinformationsData = {
                "user_id": this.userDetails.id,
                "role_id": this.userDetails.role_id,
                "token": this.userDetails.token.original.token
            };
            console.log(this.personalinformationsData);
        }
        this.userService.personalInformation(this.personalinformationsData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.personalinformations = res.data.user.notification_setting;
            }
        });
    };
    SettingsPage.prototype.changeToggle = function (personalinformations) {
        console.log(personalinformations);
    };
    SettingsPage.prototype.openLanguagePopover = function (ev) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var popover;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.popoverCtrl.create({
                            component: _language_popover_language_popover_page__WEBPACK_IMPORTED_MODULE_4__["LanguagePopoverPage"],
                            event: ev
                        })];
                    case 1:
                        popover = _a.sent();
                        return [4 /*yield*/, popover.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    SettingsPage.ctorParameters = function () { return [
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] },
        { type: _services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
        { type: _language_service__WEBPACK_IMPORTED_MODULE_6__["LanguageService"] }
    ]; };
    SettingsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-settings',
            template: __webpack_require__(/*! raw-loader!./settings.page.html */ "./node_modules/raw-loader/index.js!./src/app/settings/settings.page.html"),
            styles: [__webpack_require__(/*! ./settings.page.scss */ "./src/app/settings/settings.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"],
            _services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"],
            _language_service__WEBPACK_IMPORTED_MODULE_6__["LanguageService"]])
    ], SettingsPage);
    return SettingsPage;
}());



/***/ })

}]);
//# sourceMappingURL=settings-settings-module.js.map