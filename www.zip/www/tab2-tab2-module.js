(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab2-tab2-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/tab2/tab2.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/tab2/tab2.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header style=\"height:232px;background-color:#2A2A2A; \">\n  <ion-toolbar>\n    <ion-label slot=\"start\"><span class=\"tit\">{{ 'tab2.salon' | translate }}</span><span class=\"tit clr\">&nbsp;&nbsp;{{ 'tab2.beauty' | translate }}</span><br/>\n      <span class=\"explore\">{{ 'tab2.exploresub' | translate }}</span></ion-label>\n      <ion-label class=\"notification\"  slot=\"end\"><img style=\"max-width:105%;padding:4px;\" slot=\"end\" src=\"assets/images/notification.svg\">\n        <ion-badge>2</ion-badge>\n       </ion-label>\n  </ion-toolbar>\n  <div>\n      <ion-searchbar class=\"fontSans\" placeholder=\"{{ 'tab2.lookingfor' | translate }}\"></ion-searchbar>\n  </div>\n  <ion-row>\n    <ion-col size=\"5.7\" style=\"margin-left:5px;\">\n      <!--<ion-item>\n        <ion-label>Select Place</ion-label>\n          <ion-select [(ngModel)]=\"isType\" (ionChange)=\"nearbyPlace()\">\n          <ion-option value=\"\">Select</ion-option>\n              <ion-option value=\"hospital\">Hospital</ion-option>\n              <ion-option value=\"restaurant\">Restaurant</ion-option>\n              <ion-option value=\"bank\">Bank</ion-option>\n              <ion-option value=\"airport\">Airport</ion-option>\n              <ion-option value=\"library\">Library</ion-option>\n              <ion-option value=\"gym\">Gym</ion-option>\n            <ion-option value=\"atm\">Atm</ion-option>\n            <ion-option value=\"shopping_mall\">Shopping Mall</ion-option>\n            <ion-option value=\"police\">Police Station</ion-option>\n            <ion-option value=\"zoo\">Zoo</ion-option>\n          </ion-select>\n        </ion-item>\n        \n        <ion-item>\n        <ion-label>Select Distance</ion-label>\n          <ion-select [(ngModel)]=\"isKM\" (ionChange)=\"nearbyPlace()\">\n          <ion-option value=\"500\">Select</ion-option>\n              <ion-option value=\"2000\">2 KM</ion-option>\n              <ion-option value=\"4000\">4 KM</ion-option>\n              <ion-option value=\"6000\">6 KM</ion-option>\n              <ion-option value=\"8000\">8 KM</ion-option>\n          </ion-select>\n        </ion-item>\n        \n        <div #map id=\"map\"></div>-->\n        <ion-input class=\"fontSans\" type=\"text\" placeholder=\"{{ 'tab2.near' | translate }}\"></ion-input>\n    </ion-col>\n    <ion-col size=\"5.7\" style=\"margin-right:5px;\">\n      <ion-input class=\"fontSans\" (ionchange)=\"datepicker()\" type=\"text\" placeholder=\"{{ 'tab2.when' | translate }}\"></ion-input>\n    </ion-col>\n  </ion-row>\n  <!-- <ion-segment scrollable [(ngModel)]=\"salon\">\n    <ion-segment-button value=\"All\">\n      {{ 'tab2.all' | translate }}\n    </ion-segment-button>\n    <ion-segment-button value=\"Babershop\">\n      {{ 'tab2.babershop' | translate }}\n    </ion-segment-button>\n    <ion-segment-button value=\"HairSalon\">\n      {{ 'tab2.hairsalon' | translate }}\n    </ion-segment-button>\n    <ion-segment-button value=\"Massage\">\n      {{ 'tab2.massage' | translate }}\n    </ion-segment-button>\n    <ion-segment-button value=\"DaySpa\">\n      {{ 'tab2.dayspa' | translate }}\n    </ion-segment-button>\n    <ion-segment-button value=\"Beauty\">\n      {{ 'tab2.Beauty' | translate }}\n    </ion-segment-button> \n  </ion-segment> -->\n</ion-header>  \n  \n<ion-content [ngClass]=\"{'bg1':themes == 'white' }\">\n  <ion-list>\n      <div class=\"contents\" *ngFor=\"let item of conditionalBusinessList\" (click)=\"goToDetailsPage(item)\">\n        <div class=\"cardcontent\">\n          <img class=\"card\" *ngIf=\"!item.image\" src=\"assets/images/Card products backgroud.svg\">\n          <img class=\"card\" *ngIf=\"item.image\" src=\"{{item.image}}\">\n          <div class=\"content\">\n            <ion-grid  style=\"padding: 0px;\">\n              <ion-row>\n                <ion-col size=\"2\" style=\"padding-left: 0px; padding-right: 0px;\">\n                <img src=\"assets/images/logo.svg\">\n                </ion-col>\n                <ion-col size=\"6\" style=\"padding-left: 0px; padding-right: 0px;\">\n                  <div style=\"text-align:left;\">\n                    <ion-label class=\"fontMoteret clrw\">{{item.name}}</ion-label><br>\n                    <img src=\"assets/images/location1.svg\"><ion-label class=\"fontSans clrw fs8\">&nbsp;&nbsp;{{item?.distance}}, {{item.address}}</ion-label>\n                  </div>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding-left: 0px; padding-right: 0px;\">\n                  <div class=\"ratings\">\n                    <div class=\"empty-stars\"></div>\n                    <div class=\"full-stars\" [ngClass]=\"{'full-stars1':positions}\" [ngStyle]=\"{'width':item.ratingPercent}\"></div>\n                  </div>\n                  <div>\n                  <ion-label style=\"font-size:10px;color:white;\">{{item.review}} {{ 'tab2.review' | translate }}</ion-label>\n                </div> \n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </div>\n      </div>\n    </ion-list>\n\n  <!-- <div [ngSwitch]=\"salon\">\n    <ion-list *ngSwitchCase=\"'All'\">\n      <div class=\"contents\" *ngFor=\"let item of businessData\" (click)=\"goToDetailsPage(item)\">\n        <div class=\"cardcontent\">\n          <img class=\"card\" *ngIf=\"!item.image\" src=\"assets/images/Card products backgroud.svg\">\n          <img class=\"card\" *ngIf=\"item.image\" src=\"{{item.image}}\">\n          <div class=\"content\">\n            <ion-grid  style=\"padding: 0px;\">\n              <ion-row>\n                <ion-col size=\"2\" style=\"padding-left: 0px; padding-right: 0px;\">\n                <img src=\"assets/images/logo.svg\">\n                </ion-col>\n                <ion-col size=\"6\" style=\"padding-left: 0px; padding-right: 0px;\">\n                  <div style=\"text-align:left;\">\n                    <ion-label class=\"fontMoteret clrw\">{{item.name}}</ion-label><br>\n                    <img src=\"assets/images/location1.svg\"><ion-label class=\"fontSans clrw fs8\">&nbsp;&nbsp;{{item?.distance}}, {{item.address}}</ion-label>\n                  </div>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding-left: 0px; padding-right: 0px;\">\n                  <div class=\"ratings\">\n                    <div class=\"empty-stars\"></div>\n                    <div class=\"full-stars\" [ngClass]=\"{'full-stars1':positions}\" [ngStyle]=\"{'width':item.ratingPercent}\"></div>\n                  </div>\n                  <div>\n                  <ion-label style=\"font-size:10px;color:white;\">{{item.review}} {{ 'tab2.review' | translate }}</ion-label>\n                </div> \n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </div>\n      </div>\n    </ion-list>\n\n    <ion-list *ngSwitchCase=\"'Babershop'\">\n    \n    </ion-list>\n\n    <ion-list  *ngSwitchCase=\"'HairSalon'\">\n      <div class=\"contents\" *ngFor=\"let item of businessData\" (click)=\"goToDetailsPage(item)\">\n        <div class=\"cardcontent\">\n          <img class=\"card\" *ngIf=\"!item.image\" src=\"assets/images/Card products backgroud.svg\">\n          <img class=\"card\" *ngIf=\"item.image\" src=\"{{item.image}}\">\n          <div class=\"content\">\n            <ion-grid  style=\"padding: 0px;\">\n              <ion-row>\n                <ion-col size=\"2\" style=\"padding-left: 0px; padding-right: 0px;\">\n                <img src=\"assets/images/logo.svg\">\n                </ion-col>\n                <ion-col size=\"6\" style=\"padding-left: 0px; padding-right: 0px;\">\n                  <div style=\"text-align:left;\">\n                    <ion-label class=\"fontMoteret clrw\">{{item.name}}</ion-label><br>\n                    <img src=\"assets/images/location1.svg\"><ion-label class=\"fontSans clrw fs8\">&nbsp;&nbsp;{{item?.distance}}, {{item.address}}</ion-label>\n                  </div>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding-left: 0px; padding-right: 0px;\">\n                  <div class=\"ratings\">\n                    <div class=\"empty-stars\"></div>\n                    <div class=\"full-stars\" [ngClass]=\"{'full-stars1':position}\" [ngStyle]=\"{'width':item.ratingPercent}\"></div>\n                  </div>\n                  <div>\n                  <ion-label style=\"font-size:10px;color:white;\">{{item.review}} {{ 'tab2.review' | translate }}</ion-label>\n                </div> \n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </div>\n      </div>\n\n    </ion-list>\n\n    <ion-list *ngSwitchCase=\"'Massage'\">\n      <div class=\"contents\" *ngFor=\"let item of conditionbusinesslissalon\" (click)=\"goToDetailsPage(item)\">\n        <div class=\"cardcontent\">\n          <img class=\"card\" *ngIf=\"!item.image\" src=\"assets/images/Card products backgroud.svg\">\n          <img class=\"card\" *ngIf=\"item.image\" src=\"{{item.image}}\">\n          <div class=\"content\">\n            <ion-grid  style=\"padding: 0px;\">\n              <ion-row>\n                <ion-col size=\"2\" style=\"padding-left: 0px; padding-right: 0px;\">\n                <img src=\"assets/images/logo.svg\">\n                </ion-col>\n                <ion-col size=\"6\" style=\"padding-left: 0px; padding-right: 0px;\">\n                  <div style=\"text-align:left;\">\n                    <ion-label class=\"fontMoteret clrw\">{{item.name}}</ion-label><br>\n                    <img src=\"assets/images/location1.svg\"><ion-label class=\"fontSans clrw fs8\">&nbsp;&nbsp;{{item.address}}</ion-label>\n                  </div>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding-left: 0px; padding-right: 0px;\">\n                  <div class=\"ratings\">\n                    <div class=\"empty-stars\"></div>\n                    <div class=\"full-stars\" [ngClass]=\"{'full-stars1':position}\" [ngStyle]=\"{'width':item.ratingPercent}\"></div>\n                  </div>\n                  <div>\n                  <ion-label style=\"font-size:10px;color:white;\">{{item.review}} {{ 'tab2.review' | translate }}</ion-label>\n                </div> \n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </div>\n      </div>\n    </ion-list> -->\n\n    <!-- <ion-list no-lines class=\"spa\" *ngSwitchCase=\"'DaySpa'\">\n      <div>\n        <ion-label><img src=\"assets/images/search.svg\"></ion-label><br/>\n        <ion-label class=\"fontSans\">{{ 'tab2.noresult' | translate }}</ion-label>\n      </div>\n      <div style=\"margin-top:20px;\">\n        <ion-label class=\"fontSans fs10\">{{ 'tab2.notanything' | translate }}</ion-label> \n      </div>\n    </ion-list>\n\n    <ion-list *ngSwitchCase=\"'Beauty'\">\n     \n    </ion-list>\n  </div> -->\n</ion-content>"

/***/ }),

/***/ "./src/app/tab2/tab2.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.module.ts ***!
  \*************************************/
/*! exports provided: Tab2PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab2PageModule", function() { return Tab2PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _tab2_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab2.page */ "./src/app/tab2/tab2.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");








var Tab2PageModule = /** @class */ (function () {
    function Tab2PageModule() {
    }
    Tab2PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab2_page__WEBPACK_IMPORTED_MODULE_6__["Tab2Page"] }])
            ],
            declarations: [_tab2_page__WEBPACK_IMPORTED_MODULE_6__["Tab2Page"]]
        })
    ], Tab2PageModule);
    return Tab2PageModule;
}());



/***/ }),

/***/ "./src/app/tab2/tab2.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab2/tab2.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.explore {\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  font-size: 9pt;\n  color: white;\n}\n.clr {\n  color: #ED145B !important;\n}\nion-toolbar {\n  --background:#2A2A2A;\n  padding: 4px;\n}\n.tit {\n  font-size: 12pt;\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n  font-weight: bold;\n}\n.notification {\n  margin-right: 5px;\n  border: 1px solid white;\n  border-radius: 50%;\n  height: 30px;\n  width: 30px;\n  text-align: center;\n}\nion-content {\n  --background:black;\n}\nion-searchbar {\n  --color:none;\n  --placeholder-color:white;\n  --placeholder-opacity:0.5;\n  --background:#171515;\n}\n.fontSans {\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  color: white;\n}\nion-input {\n  --color: white;\n  --placeholder-color: white;\n  --background: #171515;\n  --padding-start: 15px;\n  border-radius: 8px;\n  --placeholder-font-style:10px;\n  --placeholder-color:white;\n}\nion-item {\n  --background:black;\n}\n.fs10 {\n  font-size: 10pt;\n}\n.content {\n  background: rgba(42, 42, 42, 0.6);\n  width: 100%;\n  position: absolute;\n  bottom: 10px;\n}\n.fs8 {\n  font-size: 8pt;\n}\n.fontMoteret {\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n}\nion-segment-button {\n  border: none !important;\n  color: white;\n  --background-checked: none;\n  --background-hover:none;\n  text-transform: none;\n  --padding-start:0px !important;\n  min-width: 0px !important;\n  --color-checked:#ED145B !important;\n  margin-left: 5px;\n  margin-right: 5px;\n}\n.ios ion-segment-button {\n  padding: 5px;\n}\n/*ion-badge{\n  --background: #ED145B;\n  --padding: 3px;\n  --padding-start: 3px;\n  --padding-end: 2px;\n  --padding-top: 1px;\n  --padding-bottom: 1px;\n  position:absolute;\n  top:14px;\n  right:23px;\n  border-radius: 50%;\n}\n.md ion-badge{\n  --background: #ED145B;\n  --padding: 3px;\n  --padding-start: 3px;\n  --padding-end: 2px;\n  --padding-top: 1px;\n  --padding-bottom: 1px;\n  position:absolute;\n  top:21px;\n  right: 18px;\n}*/\n.notification {\n  margin-right: 5px;\n  border: 1px solid white;\n  border-radius: 50%;\n  height: 30px;\n  width: 30px;\n  text-align: center;\n  position: relative;\n}\nion-badge {\n  --background: #ED145B;\n  --padding: 3px;\n  --padding-start: 3px;\n  --padding-end: 2px;\n  --padding-top: 1px;\n  --padding-bottom: 1px;\n  position: absolute;\n  top: 7px;\n  right: 13px;\n  border-radius: 50%;\n}\n.card {\n  display: block;\n  width: 100%;\n}\n.contents {\n  margin: 5px;\n}\nion-list {\n  padding-top: 20px;\n  color: white;\n  background-color: black;\n}\nion-header.ios.header-ios.hydrated {\n  height: 200px !important;\n}\n.spa {\n  padding-top: 50px;\n  text-align: center;\n  color: white;\n  background-color: black;\n}\n.bg1 {\n  --background:white;\n}\n.bg1 ion-list {\n  background-color: white;\n  color: black;\n}\n.bg1 .spa {\n  background-color: white;\n  color: black;\n}\n.content {\n  background: rgba(42, 42, 42, 0.6);\n  width: 100%;\n  position: absolute;\n  bottom: 17px;\n}\n.cardcontent {\n  position: relative;\n  margin-top: 20px;\n  text-align: center;\n  margin-left: 5px;\n  margin-right: 5px;\n}\n/* new star rating */\n.ratings {\n  position: relative;\n  vertical-align: middle;\n  display: inline-block;\n  color: #b1b1b1;\n  overflow: hidden;\n}\n.full-stars {\n  position: absolute;\n  left: 0;\n  top: 0;\n  white-space: nowrap;\n  overflow: hidden;\n  color: #fde16d;\n}\n.empty-stars:before, .full-stars:before {\n  content: \"★★★★★\";\n  font-size: 14pt;\n}\n.empty-stars:before {\n  -webkit-text-stroke: 1px #848484;\n}\n.full-stars:before {\n  -webkit-text-stroke: 1px orange;\n}\n/* Webkit-text-stroke is not supported on firefox or IE */\n/* Firefox */\n@-moz-document url-prefix() {\n  .full-stars {\n    color: #ECBE24;\n  }\n}\n.full-stars1 {\n  position: absolute;\n  right: 0;\n  top: 0;\n  white-space: nowrap;\n  overflow: hidden;\n  color: #fde16d;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiMi90YWIyLnBhZ2Uuc2NzcyIsIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL3RhYjIvdGFiMi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FDQ2Q7RUFDRSxxREFBQTtFQUNBLGNBQUE7RUFDQSxZQUFBO0FEQ0o7QUNDRTtFQUNFLHlCQUFBO0FERUo7QUNBRTtFQUNFLG9CQUFBO0VBQ0EsWUFBQTtBREdKO0FDQUU7RUFDRSxlQUFBO0VBQ0EsZ0RBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QURHSjtBQ0RFO0VBQ0UsaUJBQUE7RUFDQSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBRElKO0FDREU7RUFDRSxrQkFBQTtBRElKO0FDRkU7RUFDRSxZQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLG9CQUFBO0FES0o7QUNIRTtFQUNFLHFEQUFBO0VBQ0EsWUFBQTtBRE1KO0FDSkU7RUFDRSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSw2QkFBQTtFQUNBLHlCQUFBO0FET0o7QUNMRTtFQUNFLGtCQUFBO0FEUUo7QUNORTtFQUNFLGVBQUE7QURTSjtBQ1BFO0VBQ0UsaUNBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FEVUo7QUNSQTtFQUNFLGNBQUE7QURXRjtBQ1RBO0VBQ0UsZ0RBQUE7RUFDQSxZQUFBO0FEWUY7QUNWQTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0VBQ0EsdUJBQUE7RUFDQSxvQkFBQTtFQUNBLDhCQUFBO0VBQ0EseUJBQUE7RUFDQSxrQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QURhRjtBQ1hBO0VBQ0EsWUFBQTtBRGNBO0FDWkE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFBQTtBQXVCQTtFQUNFLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBRGVGO0FDYkE7RUFDRSxxQkFBQTtFQUNBLGNBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBRGdCRjtBQ2RBO0VBQ0UsY0FBQTtFQUNBLFdBQUE7QURpQkY7QUNmQTtFQUNFLFdBQUE7QURrQkY7QUNoQkE7RUFDQSxpQkFBQTtFQUVDLFlBQUE7RUFDQSx1QkFBQTtBRGtCRDtBQ2hCQTtFQUNFLHdCQUFBO0FEbUJGO0FDaEJBO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtFQUFtQixZQUFBO0VBQ25CLHVCQUFBO0FEb0JGO0FDakJBO0VBQ0Usa0JBQUE7QURvQkY7QUNsQkU7RUFDRSx1QkFBQTtFQUNBLFlBQUE7QURvQko7QUNaRTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtBRGNKO0FDVkE7RUFDSSxpQ0FBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7QURhSjtBQ1hFO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBRGNGO0FDVkEsb0JBQUE7QUFDQTtFQUNFLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBRGFGO0FDWEE7RUFDRSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxNQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QURjRjtBQ1pBO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0FEZUY7QUNiQTtFQUNFLGdDQUFBO0FEZ0JGO0FDZEE7RUFDRSwrQkFBQTtBRGlCRjtBQ2ZBLHlEQUFBO0FBRUEsWUFBQTtBQUNBO0VBQ0U7SUFDSSxjQUFBO0VEaUJKO0FBQ0Y7QUNmQTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBRGlCRiIsImZpbGUiOiJzcmMvYXBwL3RhYjIvdGFiMi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAY2hhcnNldCBcIlVURi04XCI7XG4uZXhwbG9yZSB7XG4gIGZvbnQtZmFtaWx5OiBcIlNvdXJjZSBTYW5zIFByb1wiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogOXB0O1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5jbHIge1xuICBjb2xvcjogI0VEMTQ1QiAhaW1wb3J0YW50O1xufVxuXG5pb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDojMkEyQTJBO1xuICBwYWRkaW5nOiA0cHg7XG59XG5cbi50aXQge1xuICBmb250LXNpemU6IDEycHQ7XG4gIGZvbnQtZmFtaWx5OiBcIk1vbnRzZXJyYXRcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4ubm90aWZpY2F0aW9uIHtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGhlaWdodDogMzBweDtcbiAgd2lkdGg6IDMwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6YmxhY2s7XG59XG5cbmlvbi1zZWFyY2hiYXIge1xuICAtLWNvbG9yOm5vbmU7XG4gIC0tcGxhY2Vob2xkZXItY29sb3I6d2hpdGU7XG4gIC0tcGxhY2Vob2xkZXItb3BhY2l0eTowLjU7XG4gIC0tYmFja2dyb3VuZDojMTcxNTE1O1xufVxuXG4uZm9udFNhbnMge1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBjb2xvcjogd2hpdGU7XG59XG5cbmlvbi1pbnB1dCB7XG4gIC0tY29sb3I6IHdoaXRlO1xuICAtLXBsYWNlaG9sZGVyLWNvbG9yOiB3aGl0ZTtcbiAgLS1iYWNrZ3JvdW5kOiAjMTcxNTE1O1xuICAtLXBhZGRpbmctc3RhcnQ6IDE1cHg7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgLS1wbGFjZWhvbGRlci1mb250LXN0eWxlOjEwcHg7XG4gIC0tcGxhY2Vob2xkZXItY29sb3I6d2hpdGU7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOmJsYWNrO1xufVxuXG4uZnMxMCB7XG4gIGZvbnQtc2l6ZTogMTBwdDtcbn1cblxuLmNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDQyLCA0MiwgNDIsIDAuNik7XG4gIHdpZHRoOiAxMDAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMTBweDtcbn1cblxuLmZzOCB7XG4gIGZvbnQtc2l6ZTogOHB0O1xufVxuXG4uZm9udE1vdGVyZXQge1xuICBmb250LWZhbWlseTogXCJNb250c2VycmF0XCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG5pb24tc2VnbWVudC1idXR0b24ge1xuICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgY29sb3I6IHdoaXRlO1xuICAtLWJhY2tncm91bmQtY2hlY2tlZDogbm9uZTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOm5vbmU7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICAtLXBhZGRpbmctc3RhcnQ6MHB4ICFpbXBvcnRhbnQ7XG4gIG1pbi13aWR0aDogMHB4ICFpbXBvcnRhbnQ7XG4gIC0tY29sb3ItY2hlY2tlZDojRUQxNDVCICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIG1hcmdpbi1yaWdodDogNXB4O1xufVxuXG4uaW9zIGlvbi1zZWdtZW50LWJ1dHRvbiB7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuLyppb24tYmFkZ2V7XG4gIC0tYmFja2dyb3VuZDogI0VEMTQ1QjtcbiAgLS1wYWRkaW5nOiAzcHg7XG4gIC0tcGFkZGluZy1zdGFydDogM3B4O1xuICAtLXBhZGRpbmctZW5kOiAycHg7XG4gIC0tcGFkZGluZy10b3A6IDFweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMXB4O1xuICBwb3NpdGlvbjphYnNvbHV0ZTtcbiAgdG9wOjE0cHg7XG4gIHJpZ2h0OjIzcHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cbi5tZCBpb24tYmFkZ2V7XG4gIC0tYmFja2dyb3VuZDogI0VEMTQ1QjtcbiAgLS1wYWRkaW5nOiAzcHg7XG4gIC0tcGFkZGluZy1zdGFydDogM3B4O1xuICAtLXBhZGRpbmctZW5kOiAycHg7XG4gIC0tcGFkZGluZy10b3A6IDFweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMXB4O1xuICBwb3NpdGlvbjphYnNvbHV0ZTtcbiAgdG9wOjIxcHg7XG4gIHJpZ2h0OiAxOHB4O1xufSovXG4ubm90aWZpY2F0aW9uIHtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGhlaWdodDogMzBweDtcbiAgd2lkdGg6IDMwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG5pb24tYmFkZ2Uge1xuICAtLWJhY2tncm91bmQ6ICNFRDE0NUI7XG4gIC0tcGFkZGluZzogM3B4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDNweDtcbiAgLS1wYWRkaW5nLWVuZDogMnB4O1xuICAtLXBhZGRpbmctdG9wOiAxcHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDFweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDdweDtcbiAgcmlnaHQ6IDEzcHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuLmNhcmQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5jb250ZW50cyB7XG4gIG1hcmdpbjogNXB4O1xufVxuXG5pb24tbGlzdCB7XG4gIHBhZGRpbmctdG9wOiAyMHB4O1xuICBjb2xvcjogd2hpdGU7XG4gIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xufVxuXG5pb24taGVhZGVyLmlvcy5oZWFkZXItaW9zLmh5ZHJhdGVkIHtcbiAgaGVpZ2h0OiAyMDBweCAhaW1wb3J0YW50O1xufVxuXG4uc3BhIHtcbiAgcGFkZGluZy10b3A6IDUwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6IHdoaXRlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbn1cblxuLmJnMSB7XG4gIC0tYmFja2dyb3VuZDp3aGl0ZTtcbn1cbi5iZzEgaW9uLWxpc3Qge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgY29sb3I6IGJsYWNrO1xufVxuLmJnMSAuc3BhIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuLmNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDQyLCA0MiwgNDIsIDAuNik7XG4gIHdpZHRoOiAxMDAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMTdweDtcbn1cblxuLmNhcmRjb250ZW50IHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBtYXJnaW4tdG9wOiAyMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIG1hcmdpbi1yaWdodDogNXB4O1xufVxuXG4vKiBuZXcgc3RhciByYXRpbmcgKi9cbi5yYXRpbmdzIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGNvbG9yOiAjYjFiMWIxO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4uZnVsbC1zdGFycyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgdG9wOiAwO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBjb2xvcjogI2ZkZTE2ZDtcbn1cblxuLmVtcHR5LXN0YXJzOmJlZm9yZSwgLmZ1bGwtc3RhcnM6YmVmb3JlIHtcbiAgY29udGVudDogXCLimIXimIXimIXimIXimIVcIjtcbiAgZm9udC1zaXplOiAxNHB0O1xufVxuXG4uZW1wdHktc3RhcnM6YmVmb3JlIHtcbiAgLXdlYmtpdC10ZXh0LXN0cm9rZTogMXB4ICM4NDg0ODQ7XG59XG5cbi5mdWxsLXN0YXJzOmJlZm9yZSB7XG4gIC13ZWJraXQtdGV4dC1zdHJva2U6IDFweCBvcmFuZ2U7XG59XG5cbi8qIFdlYmtpdC10ZXh0LXN0cm9rZSBpcyBub3Qgc3VwcG9ydGVkIG9uIGZpcmVmb3ggb3IgSUUgKi9cbi8qIEZpcmVmb3ggKi9cbkAtbW96LWRvY3VtZW50IHVybC1wcmVmaXgoKSB7XG4gIC5mdWxsLXN0YXJzIHtcbiAgICBjb2xvcjogI0VDQkUyNDtcbiAgfVxufVxuLmZ1bGwtc3RhcnMxIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMDtcbiAgdG9wOiAwO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBjb2xvcjogI2ZkZTE2ZDtcbn0iLCJcbiAgLmV4cGxvcmV7XG4gICAgZm9udC1mYW1pbHk6J1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgICBmb250LXNpemU6OXB0O1xuICAgIGNvbG9yOndoaXRlO1xuICB9XG4gIC5jbHJ7XG4gICAgY29sb3I6I0VEMTQ1QiAhaW1wb3J0YW50O1xuICB9XG4gIGlvbi10b29sYmFye1xuICAgIC0tYmFja2dyb3VuZDojMkEyQTJBO1xuICAgIHBhZGRpbmc6NHB4O1xuICAgIC8vaGVpZ2h0OjE3NXB4O1xuICB9XG4gIC50aXR7XG4gICAgZm9udC1zaXplOjEycHQ7XG4gICAgZm9udC1mYW1pbHk6ICdNb250c2VycmF0Jywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICAgIGNvbG9yOndoaXRlO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xuICAgIH1cbiAgLm5vdGlmaWNhdGlvbiB7XG4gICAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gICAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIGhlaWdodDogMzBweDtcbiAgICB3aWR0aDogMzBweDtcbiAgICB0ZXh0LWFsaWduOmNlbnRlcjtcbiAgfVxuXG4gIGlvbi1jb250ZW50e1xuICAgIC0tYmFja2dyb3VuZDpibGFjazsgIFxuICB9XG4gIGlvbi1zZWFyY2hiYXJ7XG4gICAgLS1jb2xvcjpub25lO1xuICAgIC0tcGxhY2Vob2xkZXItY29sb3IgOndoaXRlO1xuICAgIC0tcGxhY2Vob2xkZXItb3BhY2l0eSA6MC41O1xuICAgIC0tYmFja2dyb3VuZDojMTcxNTE1O1xuICB9XG4gIC5mb250U2Fuc3tcbiAgICBmb250LWZhbWlseTonU291cmNlIFNhbnMgUHJvJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICAgIGNvbG9yOndoaXRlO1xuICB9XG4gIGlvbi1pbnB1dHtcbiAgICAtLWNvbG9yOiB3aGl0ZTtcbiAgICAtLXBsYWNlaG9sZGVyLWNvbG9yOiB3aGl0ZTtcbiAgICAtLWJhY2tncm91bmQ6ICMxNzE1MTU7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAxNXB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICAtLXBsYWNlaG9sZGVyLWZvbnQtc3R5bGU6MTBweDtcbiAgICAtLXBsYWNlaG9sZGVyLWNvbG9yOndoaXRlO1xuICB9XG4gIGlvbi1pdGVte1xuICAgIC0tYmFja2dyb3VuZDpibGFjaztcbiAgfVxuICAuZnMxMHtcbiAgICBmb250LXNpemU6MTBwdDtcbiAgfVxuICAuY29udGVudHtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDQyLDQyLDQyLDAuNik7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvdHRvbTogMTBweDtcbn1cbi5mczh7XG4gIGZvbnQtc2l6ZTo4cHQ7XG59XG4uZm9udE1vdGVyZXR7XG4gIGZvbnQtZmFtaWx5OiAnTW9udHNlcnJhdCcsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgY29sb3I6d2hpdGU7XG59XG5pb24tc2VnbWVudC1idXR0b257XG4gIGJvcmRlcjogbm9uZSAhaW1wb3J0YW50O1xuICBjb2xvcjogd2hpdGU7XG4gIC0tYmFja2dyb3VuZC1jaGVja2VkOiBub25lO1xuICAtLWJhY2tncm91bmQtaG92ZXI6bm9uZTtcbiAgdGV4dC10cmFuc2Zvcm06bm9uZTtcbiAgLS1wYWRkaW5nLXN0YXJ0OjBweCAhaW1wb3J0YW50O1xuICBtaW4td2lkdGg6MHB4ICFpbXBvcnRhbnQ7XG4gIC0tY29sb3ItY2hlY2tlZDojRUQxNDVCICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1sZWZ0OjVweDtcbiAgbWFyZ2luLXJpZ2h0OjVweDtcbn1cbi5pb3MgaW9uLXNlZ21lbnQtYnV0dG9ue1xucGFkZGluZzo1cHg7XG59XG4vKmlvbi1iYWRnZXtcbiAgLS1iYWNrZ3JvdW5kOiAjRUQxNDVCO1xuICAtLXBhZGRpbmc6IDNweDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAzcHg7XG4gIC0tcGFkZGluZy1lbmQ6IDJweDtcbiAgLS1wYWRkaW5nLXRvcDogMXB4O1xuICAtLXBhZGRpbmctYm90dG9tOiAxcHg7XG4gIHBvc2l0aW9uOmFic29sdXRlO1xuICB0b3A6MTRweDtcbiAgcmlnaHQ6MjNweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuLm1kIGlvbi1iYWRnZXtcbiAgLS1iYWNrZ3JvdW5kOiAjRUQxNDVCO1xuICAtLXBhZGRpbmc6IDNweDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAzcHg7XG4gIC0tcGFkZGluZy1lbmQ6IDJweDtcbiAgLS1wYWRkaW5nLXRvcDogMXB4O1xuICAtLXBhZGRpbmctYm90dG9tOiAxcHg7XG4gIHBvc2l0aW9uOmFic29sdXRlO1xuICB0b3A6MjFweDtcbiAgcmlnaHQ6IDE4cHg7XG59Ki9cbi5ub3RpZmljYXRpb24ge1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgaGVpZ2h0OiAzMHB4O1xuICB3aWR0aDogMzBweDtcbiAgdGV4dC1hbGlnbjpjZW50ZXI7XG4gIHBvc2l0aW9uOnJlbGF0aXZlO1xufVxuaW9uLWJhZGdle1xuICAtLWJhY2tncm91bmQ6ICNFRDE0NUI7XG4gIC0tcGFkZGluZzogM3B4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDNweDtcbiAgLS1wYWRkaW5nLWVuZDogMnB4O1xuICAtLXBhZGRpbmctdG9wOiAxcHg7XG4gIC0tcGFkZGluZy1ib3R0b206IDFweDtcbiAgcG9zaXRpb246YWJzb2x1dGU7XG4gIHRvcDogN3B4O1xuICByaWdodDogMTNweDtcbiAgYm9yZGVyLXJhZGl1czo1MCU7XG59XG4uY2FyZHtcbiAgZGlzcGxheTpibG9jaztcbiAgd2lkdGg6MTAwJTtcbn1cbi5jb250ZW50c3tcbiAgbWFyZ2luOjVweDtcbn1cbmlvbi1saXN0e1xucGFkZGluZy10b3A6IDIwcHg7XG4gLy90ZXh0LWFsaWduOiBjZW50ZXI7XG4gY29sb3I6IHdoaXRlO1xuIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xufVxuaW9uLWhlYWRlci5pb3MuaGVhZGVyLWlvcy5oeWRyYXRlZCB7XG4gIGhlaWdodDogMjAwcHggIWltcG9ydGFudDtcbn1cblxuLnNwYSB7XG4gIHBhZGRpbmctdG9wOiA1MHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7Y29sb3I6IHdoaXRlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbn1cblxuLmJnMXtcbiAgLS1iYWNrZ3JvdW5kOndoaXRlO1xuXG4gIGlvbi1saXN0IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOndoaXRlO1xuICAgIGNvbG9yOmJsYWNrO1xuICB9XG5cbiAgLmZvbnRTYW5zIHtcbiAgICAvL2JhY2tncm91bmQtY29sb3I6d2hpdGU7XG4gICAvLyBjb2xvcjpibGFjaztcbiAgfVxuXG4gIC5zcGEge1xuICAgIGJhY2tncm91bmQtY29sb3I6d2hpdGU7XG4gICAgY29sb3I6YmxhY2s7XG4gIH1cblxufVxuLmNvbnRlbnR7XG4gICAgYmFja2dyb3VuZDogcmdiYSg0Miw0Miw0MiwwLjYpO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICBib3R0b206IDE3cHg7XG4gIH1cbiAgLmNhcmRjb250ZW50e1xuICBwb3NpdGlvbjpyZWxhdGl2ZTtcbiAgbWFyZ2luLXRvcDoyMHB4O1xuICB0ZXh0LWFsaWduOmNlbnRlcjtcbiAgbWFyZ2luLWxlZnQ6IDVweDtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG4gLy8gbWFyZ2luLWxlZnQ6M3B4O1xuIC8vIG1hcmdpbi1yaWdodDozcHg7XG59XG4vKiBuZXcgc3RhciByYXRpbmcgKi9cbi5yYXRpbmdzIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGNvbG9yOiAjYjFiMWIxO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLmZ1bGwtc3RhcnMge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGxlZnQ6IDA7XG4gIHRvcDogMDtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgY29sb3I6ICNmZGUxNmQ7XG59XG4uZW1wdHktc3RhcnM6YmVmb3JlLCAuZnVsbC1zdGFyczpiZWZvcmUge1xuICBjb250ZW50OlwiXFwyNjA1XFwyNjA1XFwyNjA1XFwyNjA1XFwyNjA1XCI7XG4gIGZvbnQtc2l6ZTogMTRwdDtcbn1cbi5lbXB0eS1zdGFyczpiZWZvcmUge1xuICAtd2Via2l0LXRleHQtc3Ryb2tlOiAxcHggIzg0ODQ4NDtcbn1cbi5mdWxsLXN0YXJzOmJlZm9yZSB7XG4gIC13ZWJraXQtdGV4dC1zdHJva2U6IDFweCBvcmFuZ2U7XG59XG4vKiBXZWJraXQtdGV4dC1zdHJva2UgaXMgbm90IHN1cHBvcnRlZCBvbiBmaXJlZm94IG9yIElFICovXG5cbi8qIEZpcmVmb3ggKi9cbkAtbW96LWRvY3VtZW50IHVybC1wcmVmaXgoKSB7XG4gIC5mdWxsLXN0YXJzIHtcbiAgICAgIGNvbG9yOiAjRUNCRTI0O1xuICB9XG59XG4uZnVsbC1zdGFyczF7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6MDtcbiAgdG9wOiAwO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBjb2xvcjogI2ZkZTE2ZDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/tab2/tab2.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab2/tab2.page.ts ***!
  \***********************************/
/*! exports provided: Tab2Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab2Page", function() { return Tab2Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ "./node_modules/@ionic-native/geolocation/ngx/index.js");
/* harmony import */ var _ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/date-picker/ngx */ "./node_modules/@ionic-native/date-picker/ngx/index.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_business_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/business.service */ "./src/app/services/business.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");








var Tab2Page = /** @class */ (function () {
    function Tab2Page(datePicker, navCtrl, translate, businessservice, geolocation, router) {
        this.datePicker = datePicker;
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.businessservice = businessservice;
        this.geolocation = geolocation;
        this.router = router;
        this.salon = "All";
        this.categoryData = {};
        // userData = new User();
        // categoryData = new ServiceList();
        // categoryData = new ServiceList();
        this.themes = 'black';
        this.businessData = [];
        this.conditionalBusinessList = [];
        this.sortConditionalBusinessList = [];
        this.positions = false;
        this.conditionbusinesslisteducation = {};
        this.conditionbusinesslissalon = {};
        this.conditionalBusinessData = {};
        this.language = localStorage.getItem("language");
        this.themes = localStorage.getItem("themes");
        this.conditionbusinesslisteducation = JSON.parse(localStorage.getItem("conditionbusinesslisteducation"));
        this.conditionbusinesslissalon = JSON.parse(localStorage.getItem("conditionbusinesslisteducation"));
        this.categoryData = JSON.parse(localStorage.getItem("categoryData"));
        if (this.language == 'ar') {
            document.documentElement.dir = 'rtl';
            this.positions = true;
        }
        this.currentlocation = JSON.parse(localStorage.getItem("latLong"));
        this.categoryId = localStorage.getItem("categoryID");
        this.getCurrentlocation();
        this.getServicelist();
        this.getBusinessList();
        //this.getConditionalBusinessList();
        // this.router.queryParams.subscribe(params => {
        //   if (params && params.categoryId) {
        //     alert(1)
        //     this.categoryId = params.categoryId;
        //     alert(this.categoryId)
        //     console.log('businessDetails',this.categoryId);
        //   }
        // });
    }
    Tab2Page.prototype.ionViewDidEnter = function () {
        //alert(1)
        this.categoryId = localStorage.getItem("categoryID");
        this.getConditionalBusinessList();
    };
    Tab2Page.prototype.datepicker = function () {
        this.datePicker.show({
            date: new Date(),
            mode: 'date',
            androidTheme: this.datePicker.ANDROID_THEMES.THEME_HOLO_DARK
        }).then(function (date) { return console.log('Got date: ', date); }, function (err) { return console.log('Error occurred while getting date: ', err); });
    };
    Tab2Page.prototype.goToDetailsPage = function (item) {
        //this.navCtrl.navigateForward('/details-page');
        var navigationExtras = {
            queryParams: {
                businessDetails: JSON.stringify(item)
            }
        };
        this.router.navigate(['details-page'], navigationExtras);
    };
    /* goToNotificationsPage() {
       this.navCtrl.navigateForward('/notifications');
     } */
    Tab2Page.prototype.getServicelist = function () {
        var _this = this;
        this.categoryData.categoryid = 1;
        this.businessservice.category(this.categoryData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.serviceList = res.data.user;
            }
        });
    };
    Tab2Page.prototype.getBusinessList = function () {
        var _this = this;
        this.businessservice.businessList().subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.businessList = res.data.user;
                for (var i = 0; i < _this.businessList.length; i++) {
                    if (_this.businessList[i].name != null) {
                        if (_this.currentlocation) {
                            _this.businessList[i].distance = _this.businessservice.getDistanceFromLatLonInKm(_this.currentlocation.lat, _this.currentlocation.long, _this.businessList[i].latitude, _this.businessList[i].longitude);
                        }
                        _this.businessData.push(_this.businessList[i]);
                        var maxRating = 5;
                        var apiRating = _this.businessList[i].review_count;
                        _this.businessList[i].ratingPercent = Math.floor((apiRating / maxRating) * 100) + '%';
                        //alert( this.businessList[i].ratingPercent);
                    }
                }
            }
        });
    };
    Tab2Page.prototype.getConditionalBusinessList = function () {
        var _this = this;
        this.conditionalBusinessData = { "categoryid": this.categoryId, "Latitude": this.currentlocation.lat, "Longitude": this.currentlocation.long };
        this.businessservice.conditionalBusinessList(this.conditionalBusinessData).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.conditionalBusinessList = res.data.user;
                for (var i = 0; i < _this.conditionalBusinessList.length; i++) {
                    if (_this.conditionalBusinessList[i].name != null) {
                        _this.sortConditionalBusinessList.push(_this.conditionalBusinessList[i]);
                        var maxRating = 5;
                        var apiRating = _this.conditionalBusinessList[i].review_count;
                        _this.conditionalBusinessList[i].ratingPercent = Math.floor((apiRating / maxRating) * 100) + '%';
                        //alert( this.businessList[i].ratingPercent);
                    }
                }
            }
        });
    };
    Tab2Page.prototype.getCurrentlocation = function () {
        var _this = this;
        this.geolocation.getCurrentPosition().then(function (resp) {
            _this.currentlocation = { "lat": resp.coords.latitude, "long": resp.coords.longitude };
            localStorage.setItem("latLong", JSON.stringify({ "lat": resp.coords.latitude, "long": resp.coords.longitude }));
        }).catch(function (error) {
            console.log('Error getting location', error);
        });
    };
    Tab2Page.ctorParameters = function () { return [
        { type: _ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_4__["DatePicker"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateService"] },
        { type: _services_business_service__WEBPACK_IMPORTED_MODULE_6__["BusinessService"] },
        { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_3__["Geolocation"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], Tab2Page.prototype, "ngSwitchCase", void 0);
    Tab2Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tab2',
            template: __webpack_require__(/*! raw-loader!./tab2.page.html */ "./node_modules/raw-loader/index.js!./src/app/tab2/tab2.page.html"),
            styles: [__webpack_require__(/*! ./tab2.page.scss */ "./src/app/tab2/tab2.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_4__["DatePicker"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateService"],
            _services_business_service__WEBPACK_IMPORTED_MODULE_6__["BusinessService"],
            _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_3__["Geolocation"],
            _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]])
    ], Tab2Page);
    return Tab2Page;
}());



/***/ })

}]);
//# sourceMappingURL=tab2-tab2-module.js.map