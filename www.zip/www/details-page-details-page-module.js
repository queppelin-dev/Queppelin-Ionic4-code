(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["details-page-details-page-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/details-page/details-page.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/details-page/details-page.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-header class=\"header\">\n  <ion-toolbar color=\"primary\" mode=\"ios\" class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-label class=\"\"  slot=\"end\"><img style=\"max-width:105%;padding:4px;\" slot=\"end\" src=\"assets/images/favorite-heart-button.svg\">\n      </ion-label>\n    <!-- <ion-title>Address</ion-title> -->\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <!--<div class=\"product\" *ngIf=\"showSlider\">\n  <div class=\"content\" *ngIf=\"showSlider\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size=\"2\">\n        <img src=\"assets/images/logo.svg\">\n        </ion-col>\n        <ion-col size=\"6\">\n          <div style=\"text-align:left;\">\n            <ion-label class=\"fontMoteret\">Make By GLR</ion-label><br>\n            <img src=\"assets/images/location1.svg\"><ion-label class=\"fontSans fs8\">&nbsp;&nbsp;8KM, Dark Horse RD,</ion-label>\n          </div>\n        </ion-col>\n        <ion-col size=\"4\">\n        <ion-label> <img src=\"assets/images/Starflat.svg\">\n            <img src=\"assets/images/Starflat.svg\">\n            <img src=\"assets/images/Starflat.svg\">\n            <img src=\"assets/images/Starlinear.svg\">\n            <img src=\"assets/images/Starlinear.svg\">\n          </ion-label> \n          <div>\n          <ion-label style=\"font-size:10px;color:white;\">122 Reviews</ion-label>\n        </div> \n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n</div>-->\n<div class=\"product\" *ngIf=\"showSlider\">\n  <div class=\"content\" *ngIf=\"showSlider\">\n      <!--<ion-grid>\n        <ion-row>\n          <ion-col size=\"2\">\n          <img src=\"assets/images/logo.svg\">\n          </ion-col>\n          <ion-col size=\"6.5\">\n            <div>\n              <ion-label class=\"fontMoteret\">Make By GLR</ion-label><br>\n              <img src=\"assets/images/location1.svg\"><ion-label class=\"fontSans fs8\">&nbsp;&nbsp;8KM, Dark Horse RD,</ion-label>\n            </div>\n          </ion-col>\n          <ion-col size=\"3.5\">\n          <ion-label> <img src=\"assets/images/Starflat.svg\">\n              <img src=\"assets/images/Starflat.svg\">\n              <img src=\"assets/images/Starflat.svg\">\n              <img src=\"assets/images/Starlinear.svg\">\n              <img src=\"assets/images/Starlinear.svg\">\n            </ion-label> \n            <div>\n            <ion-label style=\"font-size:10px;color:white;\">122 Reviews</ion-label>\n          </div> \n          </ion-col>\n        </ion-row>\n      </ion-grid>-->\n      <div class=\"contents\">\n          <div class=\"cardcontent\">\n            <!--<img class=\"card\" *ngIf=\"!businessDetails.image\" src=\"assets/images/Card products backgroud.svg\">\n            <img class=\"card\" *ngIf=\"businessDetails.image\" src=\"{{businessDetails.image}}\">-->\n            <div class=\"content\">\n              <ion-grid  style=\"padding: 0px;\">\n                <ion-row>\n                  <ion-col size=\"2\">\n                  <img class= \"image\" *ngIf=\"!businessDetails.business_logo\" src=\"assets/images/logo.svg\">\n                  <img class= \"image\" *ngIf=\"businessDetails.business_logo\" src=\"{{businessDetails.business_logo}}\">\n                  </ion-col>\n                  <ion-col size=\"6\" style=\"padding-left: 0px; padding-right: 0px;\">\n                    <div style=\"text-align:left;\">\n                      <ion-label class=\"fontMoteret clrw\">{{businessDetails.name}}</ion-label><br>\n                      <img src=\"assets/images/location1.svg\"><ion-label class=\"fontSans clrw fs8\">&nbsp;&nbsp;{{busineesDistance}}, {{businessDetails.address}}</ion-label>\n                    </div>\n                  </ion-col>\n                  <ion-col size=\"4\" style=\"padding-left: 0px; padding-right: 0px;\">\n               \n                   <div class=\"ratings\">\n                    <div class=\"empty-stars\"></div>\n                    <div class=\"full-stars\" [ngClass]=\"{'full-stars1':position}\" [ngStyle]=\"{'width':businessDetails.ratingPercent}\"></div>\n                  </div>\n                    <div>\n                    <ion-label style=\"font-size:10px;color:white;\">{{businessDetails.review}} {{ 'tab1.review' | translate }}</ion-label>\n                  </div> \n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n            </div>\n          </div>\n        </div>\n    </div>\n</div>\n\n  \n\n  <ion-segment scrollable [(ngModel)]=\"segmentText\" style=\"background-color:#2A2A2A\">\n    <ion-segment-button value=\"Services\">\n      {{ 'details-page.services' | translate }}\n    </ion-segment-button>\n    <ion-segment-button value=\"Details\">\n      {{ 'details-page.details' | translate }}\n    </ion-segment-button>\n    <ion-segment-button value=\"Reviews\">\n      {{ 'details-page.reviews' | translate }}\n    </ion-segment-button>\n  </ion-segment>\n\n  <div [ngSwitch]=\"segmentText\">\n    <div [style.display]=\"segmentText == 'Details' ? 'block' : 'none'\" style=\"width:100%;height:200px\">\n      <div #mapElements class=\"map\" id=\"mydiv1\" style=\"height:100%;width:100%;\"></div>\n    </div>\n    <ion-list *ngSwitchCase=\"'Services'\" >\n      <ion-item *ngFor=\"let item of serviceList\" [color]=\"$index%2 != 0 ? 'light' : ''\">\n        <h6 class=\"text-style\">{{item.name}}</h6>\n        <div class=\"row\" slot=\"end\">\n          <div class=\"col\">\n            <h6 class=\"text-style\" style=\"font-size: 14px;\">{{item.price}}{{item.currency}}</h6>\n            <p class=\"text-style1\">{{item.duration}}<span *ngIf=\"item.time_measurement\">{{item.time_measurement}}</span><span *ngIf=\"!item.time_measurement\">min</span></p>\n          </div>\n        </div>\n        <button slot=\"end\" class=\"btn\" (click)=\"goToBookAppointmentPage(item)\"> {{ 'details-page.bookbtn' | translate }}</button>\n      </ion-item>\n    </ion-list>\n\n    <ion-list *ngSwitchCase=\"'Details'\">\n      <div>\n      <div class=\"star\">\n        <ion-label>\n          <div class=\"ratings\">\n              <div class=\"empty-stars\"></div>\n              <div class=\"full-stars\" [ngStyle]=\"{'width':businessDetails.ratingPercent}\"></div>\n          </div>\n          <span style=\"padding-left: 5px;\">{{businessinfo.review_count}}</span><span class=\"txt1\"> {{ 'details-page.basedon' | translate }} {{businessinfo.review}} {{ 'details-page.clientreview' | translate }}</span>\n        </ion-label> \n      </div>\n      <hr>\n      <div class=\"txt\">\n        <h6>{{businessinfo.business_description}}</h6>\n      </div>\n      <div class=\"title\">\n        <h5 style=\"padding:10px;\">{{ 'details-page.personal' | translate }}</h5>\n      </div>\n      <ion-item>\n        <img src=\"assets/images/smartphone.svg\">\n        <div class=\"row\">\n          <div class=\"col\">\n            <h6 class=\"smltxt\">{{ 'details-page.contact' | translate }}</h6>\n          </div>\n          <div class=\"col\">\n            <h6 class=\"medtxt pl8 pr8\">{{businessinfo.business_phone}}</h6>\n          </div>\n        </div>\n        <button slot=\"end\" class=\"btn1\">{{ 'details-page.call' | translate }}</button>\n      </ion-item>\n      <div *ngFor=\"let item of businessinfo.business_timing\">\n          <ion-item lines=\"none\">\n              <img src=\"assets/images/time.svg\">\n              <h6 class=\"medtxt2 pl8 pr8\">{{ item.day }}</h6>\n              <h6 class=\"medtxt1 pl8 pr8\" slot=\"end\">{{ item.start_time }} - {{ item.end_time }}</h6>\n            </ion-item>\n      <!--<ion-item lines=\"none\">\n        <img src=\"assets/images/time.svg\">\n        <h6 class=\"medtxt2 pl8 pr8\">{{ 'details-page.montothu' | translate }}</h6>\n        <h6 class=\"medtxt1 pl8 pr8\" slot=\"end\">9:00AM - 6:30PM</h6>\n      </ion-item>\n      <ion-item lines=\"none\">\n        <img src=\"assets/images/time.svg\">\n        <h6 class=\"medtxt2 pl8 pr8\">{{ 'details-page.friday' | translate }}</h6>\n        <h6 class=\"medtxt1 pl8 pr8\" slot=\"end\">7:00AM - 7:30PM</h6>\n      </ion-item>\n      <ion-item>\n        <img src=\"assets/images/time.svg\">\n        <h6 class=\"medtxt2 pl8 pr8\">{{ 'details-page.sattosun' | translate }}</h6>\n        <h6 class=\"medtxt1\" slot=\"end\">9:00AM - 6:30PM</h6>\n      </ion-item>-->\n    </div>\n      <div>\n        <h6 class=\"medtxt1 pl8 pr8\">{{ 'details-page.sunappointment' | translate }}</h6>\n        <h6 class=\"medtxt1 pl8 pr8 mb0\">*{{ 'details-page.scheduleday' | translate }}</h6>\n      </div>\n    </div>\n    </ion-list>\n\n    <ion-list *ngSwitchCase=\"'Reviews'\" style=\"padding-top:0px;\">\n      <ion-grid style=\"border-bottom: 1px dashed #CCCCCC;\">\n        <ion-row>\n          <ion-col size=\"6\" style=\"text-align: center; border-right: 1px dashed #CCCCCC;\" >\n           <!--<h6 class=\"rating-txt\">{{businessReviewCount[0].review_rating}}</h6>\n            <div class=\"ratings\">\n                <div class=\"empty-stars\"></div>\n                <div class=\"full-stars\" [ngStyle]=\"{'width':ratingPercent}\"></div>\n            </div>\n            <h6 style=\"font-size: 12px; margin-top: 4px;\"> {{ 'details-page.basedon' | translate }} {{businessReviewCount[0].review_count}} {{ 'details-page.clientreview' | translate }}</h6>-->\n            <div class=\"star\">\n                <ion-label>\n                  <div class=\"ratings\">\n                      <div class=\"empty-stars\"></div>\n                      <div class=\"full-stars\" [ngStyle]=\"{'width':businessDetails.ratingPercent}\"></div>\n                  </div><br>\n                  <span style=\"padding-left: 5px;\">{{businessinfo.review_count}}</span><span class=\"txt1\"> {{ 'details-page.basedon' | translate }} {{businessinfo.review}} {{ 'details-page.clientreview' | translate }}</span>\n                </ion-label> \n              </div>\n          </ion-col>\n          <ion-col size=\"6\">\n            <ion-row style=\"height: 16px;\" *ngFor=\"let item of businessReviewCount\">\n              <ion-col size=\"1\" style=\"font-size: 11px\">{{item.review_rating}}</ion-col>\n              <ion-col size=\"1\" style=\"font-size: 11px\">\n                <ion-icon name=\"star\" style=\"color:#CCCCCC;\"></ion-icon>\n              </ion-col>\n              <ion-col class=\"progress-setting\">\n                <ion-progress-bar value=\"{{item.progressrating}}\" class=\"progress-bar\"></ion-progress-bar>\n              </ion-col>\n              <ion-col size=\"3\" style=\"font-size: 11px\">{{item.review_count}}</ion-col>\n            </ion-row>\n          </ion-col>\n        \n        \n            <!--<ion-row style=\"height: 16px;\">\n              <ion-col size=\"1\" style=\"font-size: 11px\">4</ion-col>\n              <ion-col size=\"1\" style=\"font-size: 11px\">\n                <ion-icon name=\"star\" style=\"color:#CCCCCC;\"></ion-icon>\n              </ion-col>\n              <ion-col class=\"progress-setting\">\n                <ion-progress-bar value=\"0.1\" class=\"progress-bar\"></ion-progress-bar>\n              </ion-col>\n              <ion-col size=\"3\" style=\"font-size: 11px\">3</ion-col>\n            </ion-row>\n            <ion-row style=\"height: 16px;\">\n              <ion-col size=\"1\" style=\"font-size: 11px\">3</ion-col>\n              <ion-col size=\"1\" style=\"font-size: 11px\">\n                <ion-icon name=\"star\" style=\"color:#CCCCCC;\"></ion-icon>\n              </ion-col>\n              <ion-col class=\"progress-setting\">\n                <ion-progress-bar value=\"0.1\" class=\"progress-bar\"></ion-progress-bar>\n              </ion-col>\n              <ion-col size=\"3\" style=\"font-size: 11px\">1</ion-col>\n            </ion-row>\n            <ion-row style=\"height: 16px;\">\n              <ion-col size=\"1\" style=\"font-size: 11px\">2</ion-col>\n              <ion-col size=\"1\" style=\"font-size: 11px\">\n                <ion-icon name=\"star\" style=\"color:#CCCCCC;\"></ion-icon>\n              </ion-col>\n              <ion-col class=\"progress-setting\">\n                <ion-progress-bar value=\"0.2\" class=\"progress-bar\"></ion-progress-bar>\n              </ion-col>\n              <ion-col size=\"3\" style=\"font-size: 11px\">1</ion-col>\n            </ion-row>\n            <ion-row style=\"height: 16px;\">\n                <ion-col size=\"1\" style=\"font-size: 11px\">1</ion-col>\n                <ion-col size=\"1\" style=\"font-size: 11px\">\n                  <ion-icon name=\"star\" style=\"color:#CCCCCC;\"></ion-icon>\n                </ion-col>\n                <ion-col class=\"progress-setting\">\n                  <ion-progress-bar value=\"0.3\" class=\"progress-bar\"></ion-progress-bar>\n                </ion-col>\n                <ion-col size=\"3\" style=\"font-size: 11px\">10</ion-col>\n              </ion-row>-->\n        </ion-row>      \n      </ion-grid>\n      <ion-row style=\"border-bottom: 1px dashed #CCCCCC;\" *ngFor=\"let items of businessreview\">\n        <ion-col size=\"2\">\n          <ion-avatar>\n              <img  *ngIf=\"items.user_comment_logo\" src=\"{{items.user_comment_logo}}\">\n            <img  *ngIf=\"!items.user_comment_logo\" src=\"assets/userImage/avatar.png\">\n          </ion-avatar>\n        </ion-col>\n        <ion-col>\n            <div class=\"ratings\">\n                <div class=\"empty-stars\"></div>\n                <div class=\"full-stars\" [ngStyle]=\"{'width':items.ratingPercent}\"></div>\n            </div>\n         <!-- <div *ngFor=\"let items of businessreview\">-->\n          <h6 style=\"font-size:12px;\">{{items.user_comment_name}} <span style=\"font-size:12px; color:#999999;\">({{items.review_date}})</span></h6>\n          <p style=\"font-size:12px; color:#636162;\">{{items.comment}}</p>\n          <div class=\"reply-bg\">\n            <h6 style=\"font-size:12px; margin-top: 0px;\" *ngIf=\"items.user_reply_name\">{{items.user_reply_name}}<span style=\"font-size:12px; color:#999999;\">({{items.reply_date}})</span></h6>\n            <h6 style=\"font-size:12px; margin-top: 0px;\" *ngIf=\"!items.user_reply_name\">Make By GLR<span style=\"font-size:12px; color:#999999;\">({{items.reply_date}})</span></h6>\n            <p style=\"font-size:12px; color:#636162; margin-bottom: 0px;\">Appreciate you thank you.</p>\n          </div>\n         <!--</div>-->\n        </ion-col>\n      </ion-row>\n    </ion-list>\n  </div>\n\n</ion-content>"

/***/ }),

/***/ "./src/app/details-page/details-page.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/details-page/details-page.module.ts ***!
  \*****************************************************/
/*! exports provided: DetailsPagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailsPagePageModule", function() { return DetailsPagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _details_page_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./details-page.page */ "./src/app/details-page/details-page.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");








var routes = [
    {
        path: '',
        component: _details_page_page__WEBPACK_IMPORTED_MODULE_6__["DetailsPagePage"]
    }
];
var DetailsPagePageModule = /** @class */ (function () {
    function DetailsPagePageModule() {
    }
    DetailsPagePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_details_page_page__WEBPACK_IMPORTED_MODULE_6__["DetailsPagePage"]]
        })
    ], DetailsPagePageModule);
    return DetailsPagePageModule;
}());



/***/ }),

/***/ "./src/app/details-page/details-page.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/details-page/details-page.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\nion-segment-button {\n  border: none !important;\n  color: white;\n  --background-checked: none;\n  --background-hover:none;\n  text-transform: none;\n  --padding-start:0px !important;\n  min-width: 0px !important;\n  --color-checked:#ED145B !important;\n  margin-left: 5px;\n}\n.ios ion-segment-button {\n  padding: 5px;\n}\n.product {\n  width: 100%;\n  height: 30%;\n  background-color: #BA2B59;\n  position: relative;\n}\nion-content {\n  --background:white;\n}\n.list-md {\n  background: none;\n}\nion-item {\n  --background:#f4f4f4 !important;\n}\nion-item .bg3 {\n  --background:red !important;\n}\nion-item .bg-p {\n  --background: #EDEDED !important;\n}\n.bg3 {\n  --background:#FFFFFF !important;\n}\n.text-style {\n  color: #2A2A2A;\n  font-size: 16px;\n  padding-left: 16px;\n  margin: 0px;\n  padding: 0px;\n}\n.text-style1 {\n  color: #636162;\n  font-size: 12px;\n  padding-left: 16px;\n  margin: 0px;\n  padding: 0px;\n  text-align: right;\n}\n.btn {\n  padding-top: 5px;\n  padding-bottom: 5px;\n  background-color: #B92B59;\n  color: white;\n  width: 70px;\n  font-weight: 600;\n  height: 30px;\n  margin-left: 12px;\n}\n.btn1 {\n  padding-top: 5px;\n  padding-bottom: 5px;\n  background-color: #16A085;\n  color: white;\n  width: 50px;\n  font-weight: 500;\n  height: 30px;\n  margin-left: 12px;\n}\n.content {\n  background: rgba(42, 42, 42, 0.6);\n  height: 60px;\n  width: 100%;\n  position: absolute;\n  bottom: 0px;\n}\n.fs8 {\n  font-size: 8pt;\n}\n.fontMoteret {\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n}\n.fontSans {\n  color: white;\n}\n.header {\n  --background: #BA2B59 !important;\n}\n#map_canvas {\n  height: 150px;\n  padding-left: 8px;\n  padding-right: 8px;\n  background-color: lightgray;\n}\n.map {\n  height: 25%;\n}\n.txt {\n  color: #2A2A2A;\n  padding: 10px;\n  padding-top: 0px;\n  padding-bottom: 0px;\n  margin-bottom: 0px;\n}\n.star {\n  padding: 10px;\n  padding-bottom: 0px;\n}\nhr {\n  border-top: 1px dashed lightgray;\n}\n.title {\n  height: 40px;\n  background: #E6E6E6;\n  color: #2a2a2a !important;\n}\n.txt1 {\n  font-size: 12px;\n  padding-left: 10px;\n}\n.smltxt {\n  font-size: 12px;\n  color: gray;\n  padding-left: 8px;\n  margin-top: 8px;\n  margin-bottom: 0px;\n}\n.medtxt {\n  font-size: 15px;\n  margin-top: 0px;\n}\n.medtxt2 {\n  font-size: 15px;\n}\n.medtxt1 {\n  font-size: 13px;\n}\n.rating-txt {\n  margin-top: 0px;\n  font-size: 16px;\n  font-weight: 600;\n  text-align: center;\n  margin-bottom: 0px;\n}\n.total-count {\n  font-size: 12px !important;\n}\n.progress-bar {\n  height: 1px;\n  color: #16A085 !important;\n  margin-top: 5px;\n}\nion-progress-bar {\n  --progress-background: #16A085;\n  --buffer-background:#f4f4f4;\n}\n.progress-setting {\n  margin-top: 5px;\n  padding-top: 0px;\n  padding-bottom: 0px;\n  padding-right: 0px;\n}\nion-avatar {\n  width: 40px;\n  height: 40px;\n}\n.reply-bg {\n  background: #EDEDED;\n  padding: 4px;\n  border-radius: 10px;\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n.pl8 {\n  padding-left: 8px;\n}\n.pr8 {\n  padding-right: 8px;\n}\n.mt0 {\n  margin-top: 0px;\n}\n.ratings {\n  position: relative;\n  vertical-align: middle;\n  display: inline-block;\n  color: #b1b1b1;\n  overflow: hidden;\n}\n.full-stars {\n  position: absolute;\n  left: 0;\n  top: 0;\n  white-space: nowrap;\n  overflow: hidden;\n  color: #ffd700;\n}\n.empty-stars:before, .full-stars:before {\n  content: \"★★★★★\";\n  font-size: 14pt;\n}\n.empty-stars:before {\n  -webkit-text-stroke: 1px #848484;\n}\n.full-stars:before {\n  -webkit-text-stroke: 1px #ffd700;\n}\n/* new star rating */\n.ratings {\n  position: relative;\n  vertical-align: middle;\n  display: inline-block;\n  color: #b1b1b1;\n  overflow: hidden;\n}\n.full-stars {\n  position: absolute;\n  left: 0;\n  top: 0;\n  white-space: nowrap;\n  overflow: hidden;\n  color: #fde16d;\n}\n.empty-stars:before, .full-stars:before {\n  content: \"★★★★★\";\n  font-size: 14pt;\n}\n.empty-stars:before {\n  -webkit-text-stroke: 1px #848484;\n}\n.full-stars:before {\n  -webkit-text-stroke: 1px orange;\n}\n/* Webkit-text-stroke is not supported on firefox or IE */\n/* Firefox */\n@-moz-document url-prefix() {\n  .full-stars {\n    color: #ECBE24;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGV0YWlscy1wYWdlL2RldGFpbHMtcGFnZS5wYWdlLnNjc3MiLCIvaG9tZS9kaWxlZXAvcHJvamVjdHMvaW9uaWMvc2NoZWR1bGl4LW1vYmlsZS1hcHAvc3JjL2FwcC9kZXRhaWxzLXBhZ2UvZGV0YWlscy1wYWdlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnQkFBZ0I7QUNBaEI7RUFDRSx1QkFBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtFQUNBLHVCQUFBO0VBQ0Esb0JBQUE7RUFDQSw4QkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0NBQUE7RUFDQSxnQkFBQTtBREVGO0FDQUE7RUFDQSxZQUFBO0FER0E7QUNBQTtFQUNFLFdBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBREdGO0FDQUE7RUFDRSxrQkFBQTtBREdGO0FDQUE7RUFDRSxnQkFBQTtBREdGO0FDQUE7RUFDRSwrQkFBQTtBREdGO0FDRkU7RUFDSSwyQkFBQTtBRElOO0FDREU7RUFDRSxnQ0FBQTtBREdKO0FDQ0E7RUFDRSwrQkFBQTtBREVGO0FDQ0E7RUFDRSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QURFRjtBQ0FBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7QURHRjtBQ0FBO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBREdGO0FDQUE7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FER0Y7QUNBQTtFQUNFLGlDQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUVELFdBQUE7QURFRDtBQ0FBO0VBQ0UsY0FBQTtBREdGO0FDREE7RUFDRSxnREFBQTtFQUNBLFlBQUE7QURJRjtBQ0ZBO0VBRUUsWUFBQTtBRElGO0FDREE7RUFDRSxnQ0FBQTtBRElGO0FDREE7RUFDRSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLDJCQUFBO0FESUY7QUNGQTtFQUNFLFdBQUE7QURLRjtBQ0hBO0VBQ0UsY0FBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QURNRjtBQ0ZBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FES0Y7QUNGQTtFQUNFLGdDQUFBO0FES0Y7QUNIQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FETUE7QUNKQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBRE9BO0FDSkE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0FET0E7QUNMQTtFQUNBLGVBQUE7RUFFQSxlQUFBO0FET0E7QUNMQTtFQUNBLGVBQUE7QURRQTtBQ0pBO0VBQ0EsZUFBQTtBRE9BO0FDSkE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBRE9BO0FDSkE7RUFDQSwwQkFBQTtBRE9BO0FDSkE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxlQUFBO0FET0E7QUNKQTtFQUNBLDhCQUFBO0VBQ0EsMkJBQUE7QURPQTtBQ0pBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBRE9BO0FDSkE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBRE9BO0FDSkE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBRE9BO0FDTEE7RUFDQSxpQkFBQTtBRFFBO0FDTkE7RUFDQSxrQkFBQTtBRFNBO0FDUEE7RUFDQSxlQUFBO0FEVUE7QUNQQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBRFVBO0FDUkE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxNQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QURXQTtBQ1JBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FEV0E7QUNUQTtFQUNBLGdDQUFBO0FEWUE7QUNWQTtFQUNBLGdDQUFBO0FEYUE7QUNWQSxvQkFBQTtBQUNBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLHFCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FEYUE7QUNYQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLE1BQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBRGNBO0FDWkE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QURlQTtBQ2JBO0VBQ0EsZ0NBQUE7QURnQkE7QUNkQTtFQUNBLCtCQUFBO0FEaUJBO0FDZkEseURBQUE7QUFFQSxZQUFBO0FBQ0E7RUFDQTtJQUNJLGNBQUE7RURpQkY7QUFDRiIsImZpbGUiOiJzcmMvYXBwL2RldGFpbHMtcGFnZS9kZXRhaWxzLXBhZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGNoYXJzZXQgXCJVVEYtOFwiO1xuaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgYm9yZGVyOiBub25lICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgLS1iYWNrZ3JvdW5kLWNoZWNrZWQ6IG5vbmU7XG4gIC0tYmFja2dyb3VuZC1ob3Zlcjpub25lO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgLS1wYWRkaW5nLXN0YXJ0OjBweCAhaW1wb3J0YW50O1xuICBtaW4td2lkdGg6IDBweCAhaW1wb3J0YW50O1xuICAtLWNvbG9yLWNoZWNrZWQ6I0VEMTQ1QiAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogNXB4O1xufVxuXG4uaW9zIGlvbi1zZWdtZW50LWJ1dHRvbiB7XG4gIHBhZGRpbmc6IDVweDtcbn1cblxuLnByb2R1Y3Qge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAzMCU7XG4gIGJhY2tncm91bmQtY29sb3I6ICNCQTJCNTk7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWJhY2tncm91bmQ6d2hpdGU7XG59XG5cbi5saXN0LW1kIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6I2Y0ZjRmNCAhaW1wb3J0YW50O1xufVxuaW9uLWl0ZW0gLmJnMyB7XG4gIC0tYmFja2dyb3VuZDpyZWQgIWltcG9ydGFudDtcbn1cbmlvbi1pdGVtIC5iZy1wIHtcbiAgLS1iYWNrZ3JvdW5kOiAjRURFREVEICFpbXBvcnRhbnQ7XG59XG5cbi5iZzMge1xuICAtLWJhY2tncm91bmQ6I0ZGRkZGRiAhaW1wb3J0YW50O1xufVxuXG4udGV4dC1zdHlsZSB7XG4gIGNvbG9yOiAjMkEyQTJBO1xuICBmb250LXNpemU6IDE2cHg7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgbWFyZ2luOiAwcHg7XG4gIHBhZGRpbmc6IDBweDtcbn1cblxuLnRleHQtc3R5bGUxIHtcbiAgY29sb3I6ICM2MzYxNjI7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICBtYXJnaW46IDBweDtcbiAgcGFkZGluZzogMHB4O1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuLmJ0biB7XG4gIHBhZGRpbmctdG9wOiA1cHg7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICNCOTJCNTk7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgd2lkdGg6IDcwcHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGhlaWdodDogMzBweDtcbiAgbWFyZ2luLWxlZnQ6IDEycHg7XG59XG5cbi5idG4xIHtcbiAgcGFkZGluZy10b3A6IDVweDtcbiAgcGFkZGluZy1ib3R0b206IDVweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE2QTA4NTtcbiAgY29sb3I6IHdoaXRlO1xuICB3aWR0aDogNTBweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgaGVpZ2h0OiAzMHB4O1xuICBtYXJnaW4tbGVmdDogMTJweDtcbn1cblxuLmNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDQyLCA0MiwgNDIsIDAuNik7XG4gIGhlaWdodDogNjBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAwcHg7XG59XG5cbi5mczgge1xuICBmb250LXNpemU6IDhwdDtcbn1cblxuLmZvbnRNb3RlcmV0IHtcbiAgZm9udC1mYW1pbHk6IFwiTW9udHNlcnJhdFwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmZvbnRTYW5zIHtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uaGVhZGVyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjQkEyQjU5ICFpbXBvcnRhbnQ7XG59XG5cbiNtYXBfY2FudmFzIHtcbiAgaGVpZ2h0OiAxNTBweDtcbiAgcGFkZGluZy1sZWZ0OiA4cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDhweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmF5O1xufVxuXG4ubWFwIHtcbiAgaGVpZ2h0OiAyNSU7XG59XG5cbi50eHQge1xuICBjb2xvcjogIzJBMkEyQTtcbiAgcGFkZGluZzogMTBweDtcbiAgcGFkZGluZy10b3A6IDBweDtcbiAgcGFkZGluZy1ib3R0b206IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG4uc3RhciB7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAwcHg7XG59XG5cbmhyIHtcbiAgYm9yZGVyLXRvcDogMXB4IGRhc2hlZCBsaWdodGdyYXk7XG59XG5cbi50aXRsZSB7XG4gIGhlaWdodDogNDBweDtcbiAgYmFja2dyb3VuZDogI0U2RTZFNjtcbiAgY29sb3I6ICMyYTJhMmEgIWltcG9ydGFudDtcbn1cblxuLnR4dDEge1xuICBmb250LXNpemU6IDEycHg7XG4gIHBhZGRpbmctbGVmdDogMTBweDtcbn1cblxuLnNtbHR4dCB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY29sb3I6IGdyYXk7XG4gIHBhZGRpbmctbGVmdDogOHB4O1xuICBtYXJnaW4tdG9wOiA4cHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuLm1lZHR4dCB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgbWFyZ2luLXRvcDogMHB4O1xufVxuXG4ubWVkdHh0MiB7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cblxuLm1lZHR4dDEge1xuICBmb250LXNpemU6IDEzcHg7XG59XG5cbi5yYXRpbmctdHh0IHtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG4udG90YWwtY291bnQge1xuICBmb250LXNpemU6IDEycHggIWltcG9ydGFudDtcbn1cblxuLnByb2dyZXNzLWJhciB7XG4gIGhlaWdodDogMXB4O1xuICBjb2xvcjogIzE2QTA4NSAhaW1wb3J0YW50O1xuICBtYXJnaW4tdG9wOiA1cHg7XG59XG5cbmlvbi1wcm9ncmVzcy1iYXIge1xuICAtLXByb2dyZXNzLWJhY2tncm91bmQ6ICMxNkEwODU7XG4gIC0tYnVmZmVyLWJhY2tncm91bmQ6I2Y0ZjRmNDtcbn1cblxuLnByb2dyZXNzLXNldHRpbmcge1xuICBtYXJnaW4tdG9wOiA1cHg7XG4gIHBhZGRpbmctdG9wOiAwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDBweDtcbn1cblxuaW9uLWF2YXRhciB7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG59XG5cbi5yZXBseS1iZyB7XG4gIGJhY2tncm91bmQ6ICNFREVERUQ7XG4gIHBhZGRpbmc6IDRweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbi5wbDgge1xuICBwYWRkaW5nLWxlZnQ6IDhweDtcbn1cblxuLnByOCB7XG4gIHBhZGRpbmctcmlnaHQ6IDhweDtcbn1cblxuLm10MCB7XG4gIG1hcmdpbi10b3A6IDBweDtcbn1cblxuLnJhdGluZ3Mge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgY29sb3I6ICNiMWIxYjE7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi5mdWxsLXN0YXJzIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICB0b3A6IDA7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGNvbG9yOiAjZmZkNzAwO1xufVxuXG4uZW1wdHktc3RhcnM6YmVmb3JlLCAuZnVsbC1zdGFyczpiZWZvcmUge1xuICBjb250ZW50OiBcIuKYheKYheKYheKYheKYhVwiO1xuICBmb250LXNpemU6IDE0cHQ7XG59XG5cbi5lbXB0eS1zdGFyczpiZWZvcmUge1xuICAtd2Via2l0LXRleHQtc3Ryb2tlOiAxcHggIzg0ODQ4NDtcbn1cblxuLmZ1bGwtc3RhcnM6YmVmb3JlIHtcbiAgLXdlYmtpdC10ZXh0LXN0cm9rZTogMXB4ICNmZmQ3MDA7XG59XG5cbi8qIG5ldyBzdGFyIHJhdGluZyAqL1xuLnJhdGluZ3Mge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgY29sb3I6ICNiMWIxYjE7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi5mdWxsLXN0YXJzIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICB0b3A6IDA7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGNvbG9yOiAjZmRlMTZkO1xufVxuXG4uZW1wdHktc3RhcnM6YmVmb3JlLCAuZnVsbC1zdGFyczpiZWZvcmUge1xuICBjb250ZW50OiBcIuKYheKYheKYheKYheKYhVwiO1xuICBmb250LXNpemU6IDE0cHQ7XG59XG5cbi5lbXB0eS1zdGFyczpiZWZvcmUge1xuICAtd2Via2l0LXRleHQtc3Ryb2tlOiAxcHggIzg0ODQ4NDtcbn1cblxuLmZ1bGwtc3RhcnM6YmVmb3JlIHtcbiAgLXdlYmtpdC10ZXh0LXN0cm9rZTogMXB4IG9yYW5nZTtcbn1cblxuLyogV2Via2l0LXRleHQtc3Ryb2tlIGlzIG5vdCBzdXBwb3J0ZWQgb24gZmlyZWZveCBvciBJRSAqL1xuLyogRmlyZWZveCAqL1xuQC1tb3otZG9jdW1lbnQgdXJsLXByZWZpeCgpIHtcbiAgLmZ1bGwtc3RhcnMge1xuICAgIGNvbG9yOiAjRUNCRTI0O1xuICB9XG59IiwiaW9uLXNlZ21lbnQtYnV0dG9ue1xuICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcbiAgY29sb3I6IHdoaXRlO1xuICAtLWJhY2tncm91bmQtY2hlY2tlZDogbm9uZTtcbiAgLS1iYWNrZ3JvdW5kLWhvdmVyOm5vbmU7XG4gIHRleHQtdHJhbnNmb3JtOm5vbmU7XG4gIC0tcGFkZGluZy1zdGFydDowcHggIWltcG9ydGFudDtcbiAgbWluLXdpZHRoOjBweCAhaW1wb3J0YW50O1xuICAtLWNvbG9yLWNoZWNrZWQ6I0VEMTQ1QiAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDo1cHg7XG59XG4uaW9zIGlvbi1zZWdtZW50LWJ1dHRvbntcbnBhZGRpbmc6NXB4O1xufVxuXG4ucHJvZHVjdCB7XG4gIHdpZHRoOjEwMCU7XG4gIGhlaWdodDogMzAlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiNCQTJCNTk7XG4gIHBvc2l0aW9uOnJlbGF0aXZlO1xufVxuXG5pb24tY29udGVudHtcbiAgLS1iYWNrZ3JvdW5kOndoaXRlO1xufVxuXG4ubGlzdC1tZCB7XG4gIGJhY2tncm91bmQ6bm9uZTtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6I2Y0ZjRmNCAhaW1wb3J0YW50O1xuICAuYmczIHtcbiAgICAgIC0tYmFja2dyb3VuZDpyZWQgIWltcG9ydGFudDtcbiAgfVxuXG4gIC5iZy1wIHtcbiAgICAtLWJhY2tncm91bmQ6ICNFREVERUQgIWltcG9ydGFudDtcbiAgfVxufVxuXG4uYmczIHtcbiAgLS1iYWNrZ3JvdW5kOiNGRkZGRkYgIWltcG9ydGFudDtcbn1cblxuLnRleHQtc3R5bGUge1xuICBjb2xvcjogIzJBMkEyQTtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIG1hcmdpbjogMHB4O1xuICBwYWRkaW5nOiAwcHg7XG59XG4udGV4dC1zdHlsZTEge1xuICBjb2xvcjogIzYzNjE2MjtcbiAgZm9udC1zaXplOiAxMnB4O1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIG1hcmdpbjogMHB4O1xuICBwYWRkaW5nOiAwcHg7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuXG4uYnRuIHtcbiAgcGFkZGluZy10b3A6IDVweDtcbiAgcGFkZGluZy1ib3R0b206IDVweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0I5MkI1OTtcbiAgY29sb3I6d2hpdGU7XG4gIHdpZHRoOiA3MHB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBoZWlnaHQ6IDMwcHg7XG4gIG1hcmdpbi1sZWZ0OiAxMnB4O1xufVxuXG4uYnRuMSB7XG4gIHBhZGRpbmctdG9wOiA1cHg7XG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XG4gIGJhY2tncm91bmQtY29sb3I6ICMxNkEwODU7XG4gIGNvbG9yOndoaXRlO1xuICB3aWR0aDogNTBweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgaGVpZ2h0OiAzMHB4O1xuICBtYXJnaW4tbGVmdDogMTJweDtcbn1cblxuLmNvbnRlbnR7XG4gIGJhY2tncm91bmQ6IHJnYmEoNDIsNDIsNDIsMC42KTtcbiAgaGVpZ2h0OiA2MHB4O1xuICB3aWR0aDogMTAwJTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuIC8vIHRvcDogODdweDtcbiBib3R0b206MHB4O1xufVxuLmZzOHtcbiAgZm9udC1zaXplOjhwdDtcbn1cbi5mb250TW90ZXJldHtcbiAgZm9udC1mYW1pbHk6ICdNb250c2VycmF0Jywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBjb2xvcjp3aGl0ZTtcbn1cbi5mb250U2FucyB7XG4gIC8vYmFja2dyb3VuZC1jb2xvcjp3aGl0ZTtcbiAgY29sb3I6d2hpdGU7XG59XG5cbi5oZWFkZXIge1xuICAtLWJhY2tncm91bmQ6ICNCQTJCNTkgIWltcG9ydGFudDtcbn1cblxuI21hcF9jYW52YXMge1xuICBoZWlnaHQ6IDE1MHB4O1xuICBwYWRkaW5nLWxlZnQ6IDhweDtcbiAgcGFkZGluZy1yaWdodDogOHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBsaWdodGdyYXk7XG59XG4ubWFwIHtcbiAgaGVpZ2h0OiAyNSU7XG59XG4udHh0IHtcbiAgY29sb3I6IzJBMkEyQTtcbiAgcGFkZGluZzoxMHB4O1xuICBwYWRkaW5nLXRvcDogMHB4O1xuICBwYWRkaW5nLWJvdHRvbTogMHB4O1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG5cbn1cblxuLnN0YXJ7XG4gIHBhZGRpbmc6MTBweDtcbiAgcGFkZGluZy1ib3R0b206IDBweDtcbn1cblxuaHIge1xuICBib3JkZXItdG9wOjFweCBkYXNoZWQgbGlnaHRncmF5O1xufVxuLnRpdGxlIHtcbmhlaWdodDogNDBweDtcbmJhY2tncm91bmQ6ICNFNkU2RTY7XG5jb2xvcjojMmEyYTJhICFpbXBvcnRhbnQ7XG59XG4udHh0MSB7XG5mb250LXNpemU6IDEycHg7XG5wYWRkaW5nLWxlZnQ6IDEwcHg7XG59XG5cbi5zbWx0eHQge1xuZm9udC1zaXplOiAxMnB4O1xuY29sb3I6IGdyYXk7XG5wYWRkaW5nLWxlZnQ6IDhweDtcbm1hcmdpbi10b3A6IDhweDtcbm1hcmdpbi1ib3R0b206IDBweDtcbn1cbi5tZWR0eHQge1xuZm9udC1zaXplOiAxNXB4O1xuLy9wYWRkaW5nLWxlZnQ6IDhweDtcbm1hcmdpbi10b3A6IDBweDtcbn1cbi5tZWR0eHQyIHtcbmZvbnQtc2l6ZTogMTVweDtcbi8vIHBhZGRpbmctbGVmdDogOHB4O1xufVxuXG4ubWVkdHh0MSB7XG5mb250LXNpemU6IDEzcHg7XG59XG5cbi5yYXRpbmctdHh0IHtcbm1hcmdpbi10b3A6IDBweDtcbmZvbnQtc2l6ZTogMTZweDtcbmZvbnQtd2VpZ2h0OiA2MDA7XG50ZXh0LWFsaWduOiBjZW50ZXI7XG5tYXJnaW4tYm90dG9tOiAwcHg7XG59XG5cbi50b3RhbC1jb3VudCB7XG5mb250LXNpemU6IDEycHggIWltcG9ydGFudDtcbn1cblxuLnByb2dyZXNzLWJhciB7XG5oZWlnaHQ6IDFweDtcbmNvbG9yOiAjMTZBMDg1ICFpbXBvcnRhbnQ7XG5tYXJnaW4tdG9wOiA1cHg7XG59XG5cbmlvbi1wcm9ncmVzcy1iYXIge1xuLS1wcm9ncmVzcy1iYWNrZ3JvdW5kOiAjMTZBMDg1O1xuLS1idWZmZXItYmFja2dyb3VuZDojZjRmNGY0O1xufVxuXG4ucHJvZ3Jlc3Mtc2V0dGluZyB7XG5tYXJnaW4tdG9wOiA1cHg7XG5wYWRkaW5nLXRvcDogMHB4O1xucGFkZGluZy1ib3R0b206IDBweDtcbnBhZGRpbmctcmlnaHQ6IDBweDtcbn1cblxuaW9uLWF2YXRhcntcbndpZHRoOiA0MHB4O1xuaGVpZ2h0OiA0MHB4O1xufVxuXG4ucmVwbHktYmcge1xuYmFja2dyb3VuZDogI0VERURFRDtcbnBhZGRpbmc6IDRweDtcbmJvcmRlci1yYWRpdXM6IDEwcHg7XG5tYXJnaW4tdG9wOjBweDtcbm1hcmdpbi1ib3R0b206MHB4O1xufVxuLnBsOHtcbnBhZGRpbmctbGVmdDo4cHg7XG59XG4ucHI4e1xucGFkZGluZy1yaWdodDo4cHg7XG59XG4ubXQwe1xubWFyZ2luLXRvcDowcHg7XG59XG5cbi5yYXRpbmdzIHtcbnBvc2l0aW9uOiByZWxhdGl2ZTtcbnZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG5kaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG5jb2xvcjogI2IxYjFiMTtcbm92ZXJmbG93OiBoaWRkZW47XG59XG4uZnVsbC1zdGFycyB7XG5wb3NpdGlvbjogYWJzb2x1dGU7XG5sZWZ0OiAwO1xudG9wOiAwO1xud2hpdGUtc3BhY2U6IG5vd3JhcDtcbm92ZXJmbG93OiBoaWRkZW47XG5jb2xvcjogI2ZmZDcwMDtcbi8vd2lkdGg6O1xufVxuLmVtcHR5LXN0YXJzOmJlZm9yZSwgLmZ1bGwtc3RhcnM6YmVmb3JlIHtcbmNvbnRlbnQ6XCJcXDI2MDVcXDI2MDVcXDI2MDVcXDI2MDVcXDI2MDVcIjtcbmZvbnQtc2l6ZTogMTRwdDtcbn1cbi5lbXB0eS1zdGFyczpiZWZvcmUge1xuLXdlYmtpdC10ZXh0LXN0cm9rZTogMXB4ICM4NDg0ODQ7XG59XG4uZnVsbC1zdGFyczpiZWZvcmUge1xuLXdlYmtpdC10ZXh0LXN0cm9rZTogMXB4ICNmZmQ3MDA7XG59XG5cbi8qIG5ldyBzdGFyIHJhdGluZyAqL1xuLnJhdGluZ3Mge1xucG9zaXRpb246IHJlbGF0aXZlO1xudmVydGljYWwtYWxpZ246IG1pZGRsZTtcbmRpc3BsYXk6IGlubGluZS1ibG9jaztcbmNvbG9yOiAjYjFiMWIxO1xub3ZlcmZsb3c6IGhpZGRlbjtcbn1cbi5mdWxsLXN0YXJzIHtcbnBvc2l0aW9uOiBhYnNvbHV0ZTtcbmxlZnQ6IDA7XG50b3A6IDA7XG53aGl0ZS1zcGFjZTogbm93cmFwO1xub3ZlcmZsb3c6IGhpZGRlbjtcbmNvbG9yOiAjZmRlMTZkO1xufVxuLmVtcHR5LXN0YXJzOmJlZm9yZSwgLmZ1bGwtc3RhcnM6YmVmb3JlIHtcbmNvbnRlbnQ6XCJcXDI2MDVcXDI2MDVcXDI2MDVcXDI2MDVcXDI2MDVcIjtcbmZvbnQtc2l6ZTogMTRwdDtcbn1cbi5lbXB0eS1zdGFyczpiZWZvcmUge1xuLXdlYmtpdC10ZXh0LXN0cm9rZTogMXB4ICM4NDg0ODQ7XG59XG4uZnVsbC1zdGFyczpiZWZvcmUge1xuLXdlYmtpdC10ZXh0LXN0cm9rZTogMXB4IG9yYW5nZTtcbn1cbi8qIFdlYmtpdC10ZXh0LXN0cm9rZSBpcyBub3Qgc3VwcG9ydGVkIG9uIGZpcmVmb3ggb3IgSUUgKi9cblxuLyogRmlyZWZveCAqL1xuQC1tb3otZG9jdW1lbnQgdXJsLXByZWZpeCgpIHtcbi5mdWxsLXN0YXJzIHtcbiAgICBjb2xvcjogI0VDQkUyNDtcbn1cbn1cblxuIl19 */"

/***/ }),

/***/ "./src/app/details-page/details-page.page.ts":
/*!***************************************************!*\
  !*** ./src/app/details-page/details-page.page.ts ***!
  \***************************************************/
/*! exports provided: DetailsPagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailsPagePage", function() { return DetailsPagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_business_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/business.service */ "./src/app/services/business.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");







var DetailsPagePage = /** @class */ (function () {
    function DetailsPagePage(platform, navCtrl, translate, businessService, route, router) {
        var _this = this;
        this.platform = platform;
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.businessService = businessService;
        this.route = route;
        this.router = router;
        this.segmentText = "Services";
        this.showSlider = true;
        //user:{};
        this.businessinfoData = {};
        this.serviceData = {};
        this.businessreviewData = {};
        this.businessReviewCount = [];
        this.addService = [];
        this.businessDetails = {};
        this.reviewcountData = {};
        this.reviewcountfound = true;
        this.reviewcountnotfound = false;
        this.businessLatLong = {};
        this.route.queryParams.subscribe(function (params) {
            if (params && params.businessDetails) {
                _this.businessDetails = JSON.parse(params.businessDetails);
                console.log('businessDetails', _this.businessDetails);
            }
        });
        this.businessLatLong = JSON.parse(localStorage.getItem("latLong"));
    }
    DetailsPagePage.prototype.ngOnInit = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                this.getBusinessInfo();
                this.getServiceList();
                this.getBusinessReview();
                this.getBusinessReviewCount();
                return [2 /*return*/];
            });
        });
    };
    DetailsPagePage.prototype.ngDoCheck = function () {
        if (this.segmentText == 'Services') {
            this.showSlider = true;
        }
        else {
            this.showSlider = false;
        }
    };
    DetailsPagePage.prototype.ngAfterContentInit = function () {
    };
    DetailsPagePage.prototype.goToBookAppointmentPage = function (item) {
        console.log('data', item);
        if (this.addService.includes(item)) {
            console.log('already added');
        }
        else {
            this.addService.push(item);
        }
        var navigationExtras = {
            queryParams: {
                serviceDetails: JSON.stringify(this.addService)
            }
        };
        // this.navCtrl.navigateForward('/bookappointment');
        this.router.navigate(['bookappointment'], navigationExtras);
    };
    DetailsPagePage.prototype.getServiceList = function () {
        var _this = this;
        this.serviceData = {
            "business_id": this.businessDetails.business_id
        };
        this.businessService.serviceList(this.serviceData).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.serviceList = res.data.user;
                console.log(_this.serviceList);
            }
        });
    };
    DetailsPagePage.prototype.getBusinessReview = function () {
        var _this = this;
        this.businessreviewData = {
            "business_id": this.businessDetails.business_id
        };
        this.businessService.businessReview(this.businessreviewData).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.businessreview = res.data.user;
                console.log(_this.businessreview);
                for (var i = 0; i < _this.businessreview.length; i++) {
                    var maxRating = 5;
                    var apiRating = _this.businessreview[i].review_rating;
                    _this.businessreview[i].ratingPercent = Math.floor((apiRating / maxRating) * 100) + '%';
                    // alert( this.businessList[i].ratingPercent)
                }
            }
            if (res.status == "fail") {
                alert("No Record available");
            }
        });
    };
    DetailsPagePage.prototype.getBusinessInfo = function () {
        var _this = this;
        // let dist = this.businessService.distance(28.5048, 77.0970, 28.4759, 77.0406);
        this.businessinfoData = {
            "business_id": this.businessDetails.business_id
        };
        console.log('bid', this.businessinfoData);
        this.businessService.businessInfo(this.businessinfoData).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.businessinfo = res.data.user;
                _this.lat = _this.businessinfo.latitude;
                _this.long = _this.businessinfo.longitude;
                var lat = +_this.lat;
                var long = +_this.long;
                // init map......
                _this.map = new google.maps.Map(_this.mapElements.nativeElement, {
                    center: { lat: lat, lng: long },
                    zoom: 16
                });
                _this.busineesDistance = _this.businessService.getDistanceFromLatLonInKm(_this.businessLatLong.lat, _this.businessLatLong.long, lat, long);
                _this.busineesDistance = _this.busineesDistance.toFixed(0);
                alert(_this.busineesDistance);
                console.log(_this.businessinfo);
                var maxRating = 5;
                var apiRating = _this.businessinfo.review_count;
                _this.ratingPercent = Math.floor((apiRating / maxRating) * 100) + '%';
            }
        });
    };
    DetailsPagePage.prototype.getBusinessReviewCount = function () {
        var _this = this;
        this.business_id = this.businessDetails.business_id;
        console.log('reviewdata', this.reviewcountData);
        this.businessService.reviewCount(this.business_id).subscribe(function (res) {
            console.log('res', res);
            if (res.status == "success") {
                _this.businessReviewCount = res.data.user;
                console.log(_this.businessReviewCount);
                for (var i = 0; i < _this.businessReviewCount.length; i++) {
                    var maxProgress = 10;
                    var apiprogress = _this.businessReviewCount[i].review_count;
                    _this.businessReviewCount[i].progressrating = (apiprogress / maxProgress);
                }
            }
        });
    };
    DetailsPagePage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] },
        { type: _services_business_service__WEBPACK_IMPORTED_MODULE_4__["BusinessService"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('mapElements', { read: true, static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DetailsPagePage.prototype, "mapElements", void 0);
    DetailsPagePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-details-page',
            template: __webpack_require__(/*! raw-loader!./details-page.page.html */ "./node_modules/raw-loader/index.js!./src/app/details-page/details-page.page.html"),
            styles: [__webpack_require__(/*! ./details-page.page.scss */ "./src/app/details-page/details-page.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"],
            _services_business_service__WEBPACK_IMPORTED_MODULE_4__["BusinessService"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])
    ], DetailsPagePage);
    return DetailsPagePage;
}());



/***/ })

}]);
//# sourceMappingURL=details-page-details-page-module.js.map