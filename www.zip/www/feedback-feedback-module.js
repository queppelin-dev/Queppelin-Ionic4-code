(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["feedback-feedback-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/feedback/feedback.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/feedback/feedback.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"primary\" mode=\"ios\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button></ion-back-button>\n      </ion-buttons>\n      <ion-title>{{ 'feedback.feedback' | translate }}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n  <div *ngIf=\"feedbackandsupport\">\n<ion-list>\n  <ion-item>\n    {{ 'feedback.likefeedback' | translate }}\n    <button class=\"likebtn\" fill=\"clear\" slot=\"end\">{{ 'feedback.likebtn' | translate }}</button>\n  </ion-item>\n  <ion-item (click)=\"sendfeedback()\">\n    {{ 'feedback.sendfeedback' | translate }}\n    <ion-icon class= \"icon-color\" name=\"ios-arrow-forward\" slot=\"end\"></ion-icon>\n  </ion-item>\n  <ion-item (click)=\"presentModal()\">\n    {{ 'feedback.ratefeedback' | translate }}\n    <ion-icon class= \"icon-color\" name=\"ios-arrow-forward\" slot=\"end\"></ion-icon>\n  </ion-item>\n</ion-list>\n  </div>\n<div *ngIf=\"feedback\">\n  <ion-list style=\"margin-left:5px;margin-right:5px;\">\n    <ion-item>\n        <ion-label>Type</ion-label>\n        <ion-textarea rows=\"1\" cols=\"1\" [(ngModel)]=\"feedbackdata.type\" name=\"type\" placeholder=\"Enter type\"></ion-textarea>\n      </ion-item>\n  <ion-item>\n    <ion-label>Description</ion-label>\n    <ion-textarea rows=\"3\" cols=\"5\" [(ngModel)]=\"feedbackdata.description\" name=\"description\" placeholder=\"Enter any notes here...\"></ion-textarea>\n  </ion-item>\n</ion-list>\n<div style=\"text-align:center;margin-top:5px;\" (click)=\"submitfeedback()\">\n  <ion-button style=\"width:80%;\">Submit</ion-button>\n</div>\n\n</div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/feedback/feedback.module.ts":
/*!*********************************************!*\
  !*** ./src/app/feedback/feedback.module.ts ***!
  \*********************************************/
/*! exports provided: FeedbackPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FeedbackPageModule", function() { return FeedbackPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _feedback_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./feedback.page */ "./src/app/feedback/feedback.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");








var routes = [
    {
        path: '',
        component: _feedback_page__WEBPACK_IMPORTED_MODULE_6__["FeedbackPage"]
    }
];
var FeedbackPageModule = /** @class */ (function () {
    function FeedbackPageModule() {
    }
    FeedbackPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_feedback_page__WEBPACK_IMPORTED_MODULE_6__["FeedbackPage"]]
        })
    ], FeedbackPageModule);
    return FeedbackPageModule;
}());



/***/ }),

/***/ "./src/app/feedback/feedback.page.scss":
/*!*********************************************!*\
  !*** ./src/app/feedback/feedback.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".likebtn {\n  --border-color: #001483;\n  color: #001483;\n  --border-width: 1px;\n  --color-activated: white;\n  text-transform: none;\n  border: 1px solid #001483;\n  width: 55px;\n  --color-focused: white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  padding: 5px;\n  margin-left: 5px;\n}\n\nion-item {\n  margin-right: 8px;\n  --inner-padding-end: 0px !important;\n}\n\nion-button.loc {\n  --border-color:white;\n  --color:white;\n  --border-width:1px;\n  --color-activated:white;\n  text-transform: none;\n  border: 1px solid white;\n  width: 252px;\n  --color-focused:white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL2ZlZWRiYWNrL2ZlZWRiYWNrLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZmVlZGJhY2svZmVlZGJhY2sucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksdUJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSx3QkFBQTtFQUNBLG9CQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxxREFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ0NKOztBRENBO0VBQ0ksaUJBQUE7RUFDQSxtQ0FBQTtBQ0VKOztBREFBO0VBQ0ksb0JBQUE7RUFDQSxhQUFBO0VBR0Qsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLG9CQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxxREFBQTtBQ0NIIiwiZmlsZSI6InNyYy9hcHAvZmVlZGJhY2svZmVlZGJhY2sucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxpa2VidG57XG4gICAgLS1ib3JkZXItY29sb3I6ICMwMDE0ODM7XG4gICAgY29sb3I6ICMwMDE0ODM7XG4gICAgLS1ib3JkZXItd2lkdGg6IDFweDtcbiAgICAtLWNvbG9yLWFjdGl2YXRlZDogd2hpdGU7XG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gICAgYm9yZGVyOiAxcHggc29saWQgIzAwMTQ4MztcbiAgICB3aWR0aDogNTVweDtcbiAgICAtLWNvbG9yLWZvY3VzZWQ6IHdoaXRlO1xuICAgIGZvbnQtZmFtaWx5OiAnU291cmNlIFNhbnMgUHJvJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICAgIHBhZGRpbmc6IDVweDtcbiAgICBtYXJnaW4tbGVmdDo1cHg7XG59XG5pb24taXRlbXtcbiAgICBtYXJnaW4tcmlnaHQ6OHB4O1xuICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweCAhaW1wb3J0YW50O1xufVxuaW9uLWJ1dHRvbi5sb2N7XG4gICAgLS1ib3JkZXItY29sb3I6d2hpdGU7XG4gICAgLS1jb2xvcjp3aGl0ZTtcbiAgIC8vIGZvbnQtZmFtaWx5Ok1vbnRzZXJyYXQ7XG4gICAvLyBmb250LXNpemU6IDE2cHQ7XG4gICAtLWJvcmRlci13aWR0aDoxcHg7XG4gICAtLWNvbG9yLWFjdGl2YXRlZDp3aGl0ZTtcbiAgIHRleHQtdHJhbnNmb3JtOm5vbmU7XG4gICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgIHdpZHRoOiAyNTJweDtcbiAgIC0tY29sb3ItZm9jdXNlZDp3aGl0ZTtcbiAgIGZvbnQtZmFtaWx5OidTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIFxuICB9IiwiLmxpa2VidG4ge1xuICAtLWJvcmRlci1jb2xvcjogIzAwMTQ4MztcbiAgY29sb3I6ICMwMDE0ODM7XG4gIC0tYm9yZGVyLXdpZHRoOiAxcHg7XG4gIC0tY29sb3ItYWN0aXZhdGVkOiB3aGl0ZTtcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gIGJvcmRlcjogMXB4IHNvbGlkICMwMDE0ODM7XG4gIHdpZHRoOiA1NXB4O1xuICAtLWNvbG9yLWZvY3VzZWQ6IHdoaXRlO1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBwYWRkaW5nOiA1cHg7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG59XG5cbmlvbi1pdGVtIHtcbiAgbWFyZ2luLXJpZ2h0OiA4cHg7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24tYnV0dG9uLmxvYyB7XG4gIC0tYm9yZGVyLWNvbG9yOndoaXRlO1xuICAtLWNvbG9yOndoaXRlO1xuICAtLWJvcmRlci13aWR0aDoxcHg7XG4gIC0tY29sb3ItYWN0aXZhdGVkOndoaXRlO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gIHdpZHRoOiAyNTJweDtcbiAgLS1jb2xvci1mb2N1c2VkOndoaXRlO1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/feedback/feedback.page.ts":
/*!*******************************************!*\
  !*** ./src/app/feedback/feedback.page.ts ***!
  \*******************************************/
/*! exports provided: FeedbackPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FeedbackPage", function() { return FeedbackPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _modal_ratemodal_ratemodal_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../modal/ratemodal/ratemodal.page */ "./src/app/modal/ratemodal/ratemodal.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/user.service */ "./src/app/services/user.service.ts");







var FeedbackPage = /** @class */ (function () {
    //public feedbackDatas:any = {};
    function FeedbackPage(modalCtrl, translate, userService, navctrl) {
        this.modalCtrl = modalCtrl;
        this.translate = translate;
        this.userService = userService;
        this.navctrl = navctrl;
        this.feedback = false;
        this.feedbackandsupport = true;
        this.feedbackdata = {};
        this.userDetails = {};
        this.feedbackdetails = {};
        this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
    }
    FeedbackPage.prototype.ngOnInit = function () {
    };
    FeedbackPage.prototype.presentModal = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var modal;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _modal_ratemodal_ratemodal_page__WEBPACK_IMPORTED_MODULE_3__["RatemodalPage"],
                            componentProps: { value: 123 }
                        })];
                    case 1:
                        modal = _a.sent();
                        return [4 /*yield*/, modal.present()];
                    case 2: return [2 /*return*/, _a.sent()];
                }
            });
        });
    };
    FeedbackPage.prototype.sendfeedback = function () {
        this.feedbackandsupport = false;
        this.feedback = true;
    };
    FeedbackPage.prototype.submitfeedback = function () {
        var _this = this;
        if (this.userDetails) {
            this.feedbackdata = {
                "user_id": this.userDetails.id,
                "role_id": this.userDetails.role_id, "token": this.userDetails.token.original.token,
                "type": this.feedbackdata.type, "description": this.feedbackdata.description
            };
        }
        this.userService.feedback(this.feedbackdata).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.feedbackdetails = res.data.user;
                console.log(_this.feedbackdetails);
                _this.feedback = false;
                _this.feedbackandsupport = true;
            }
            else if (res.status == "fail") {
                alert("token is expired,first you have to login");
                _this.navctrl.navigateForward('/signin');
            }
        });
    };
    FeedbackPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateService"] },
        { type: _services_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
    ]; };
    FeedbackPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-feedback',
            template: __webpack_require__(/*! raw-loader!./feedback.page.html */ "./node_modules/raw-loader/index.js!./src/app/feedback/feedback.page.html"),
            styles: [__webpack_require__(/*! ./feedback.page.scss */ "./src/app/feedback/feedback.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_4__["TranslateService"],
            _services_user_service__WEBPACK_IMPORTED_MODULE_5__["UserService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
    ], FeedbackPage);
    return FeedbackPage;
}());



/***/ })

}]);
//# sourceMappingURL=feedback-feedback-module.js.map