(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["notifications-notifications-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/notifications/notifications.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/notifications/notifications.page.html ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\" mode=\"ios\" class=\"header\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ 'notifications.Notifications' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n  <div class=\"mt20\">\n  <div class=\"box\">\n    <ion-grid>\n      <ion-row>\n          <ion-col size=\"1\">\n              <ion-icon class=\"notif\" name=\"ios-notifications-outline\"></ion-icon>\n          </ion-col>\n          <ion-col size=\"8\">\n            <ion-label class=\"fontSans\">{{ 'notifications.NewIncomingRequest' | translate }}</ion-label><br>\n            <ion-label class=\"fs8 fontSans\">{{ 'notifications.Wishyouhappenrequests' | translate }}</ion-label>\n          </ion-col>\n          <ion-col size=\"1.5\" class=\"itemcntr\">\n            <ion-badge>3</ion-badge>\n          </ion-col> \n          <ion-col size=\"1.5\" class=\"itemcntr\">\n            <ion-icon style=\"width:110%;height:110%\" name=\"ios-arrow-forward\"></ion-icon>\n          </ion-col>\n       </ion-row>\n    </ion-grid>\n  </div>\n  <div class=\"box mt10\">\n      <ion-grid>\n        <ion-row>\n            <ion-col size=\"1\">\n                <ion-icon class=\"notif\" name=\"ios-notifications-outline\"></ion-icon>\n            </ion-col>\n            <ion-col size=\"8\">\n              <ion-label class=\"fontSans\">{{ 'notifications.RequestCancelled' | translate }}</ion-label><br>\n              <ion-label class=\"fs8 fontSans\">{{ 'notifications.Checkandknowthereason' | translate }}</ion-label>\n            </ion-col>\n            <ion-col size=\"1.5\" class=\"itemcntr\">\n              <ion-badge>1</ion-badge>\n            </ion-col> \n            <ion-col size=\"1.5\" class=\"itemcntr\">\n              <ion-icon style=\"width:110%;height:110%\" name=\"ios-arrow-forward\"></ion-icon>\n            </ion-col>\n         </ion-row>\n      </ion-grid>\n    </div>\n    <div class=\"box mt10\">\n        <ion-grid>\n          <ion-row>\n              <ion-col size=\"1\">\n                  <ion-icon class=\"notif\" name=\"ios-notifications-outline\"></ion-icon>\n              </ion-col>\n              <ion-col size=\"8\">\n                <ion-label class=\"fontSans\">{{ 'notifications.schedulix' | translate }}</ion-label><br>\n                <ion-label class=\"fs8 fontSans\">{{ 'notifications.Checktheupdatedoffersandbundles' | translate }}</ion-label>\n              </ion-col>\n              <ion-col size=\"1.5\" class=\"itemcntr\">\n                <ion-badge class=\"badge\">12</ion-badge>\n              </ion-col> \n              <ion-col size=\"1.5\" class=\"itemcntr\">\n                <ion-icon style=\"width:110%;height:110%\" name=\"ios-arrow-forward\"></ion-icon>\n              </ion-col>\n           </ion-row>\n        </ion-grid>\n      </div>\n      <div class=\"box mt10\">\n          <ion-grid>\n            <ion-row>\n                <ion-col size=\"1\">\n                    <ion-icon class=\"notif\" name=\"ios-notifications-outline\"></ion-icon>\n                </ion-col>\n                <ion-col size=\"8\">\n                  <ion-label class=\"fontSans\">{{ 'notifications.RateandReview' | translate }}</ion-label><br>\n                  <ion-label class=\"fs8 fontSans\">{{ 'notifications.Checkclientfeedback' | translate }}</ion-label>\n                </ion-col>\n                <ion-col size=\"1.5\" class=\"itemcntr\">\n                  <ion-badge class=\"badge\">12</ion-badge>\n                </ion-col> \n                <ion-col size=\"1.5\" class=\"itemcntr\">\n                  <ion-icon style=\"width:110%;height:110%\" name=\"ios-arrow-forward\"></ion-icon>\n                </ion-col>\n             </ion-row>\n          </ion-grid>\n        </div>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/notifications/notifications.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/notifications/notifications.module.ts ***!
  \*******************************************************/
/*! exports provided: NotificationsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationsPageModule", function() { return NotificationsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _notifications_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./notifications.page */ "./src/app/notifications/notifications.page.ts");








var routes = [
    {
        path: '',
        component: _notifications_page__WEBPACK_IMPORTED_MODULE_7__["NotificationsPage"]
    }
];
var NotificationsPageModule = /** @class */ (function () {
    function NotificationsPageModule() {
    }
    NotificationsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_notifications_page__WEBPACK_IMPORTED_MODULE_7__["NotificationsPage"]]
        })
    ], NotificationsPageModule);
    return NotificationsPageModule;
}());



/***/ }),

/***/ "./src/app/notifications/notifications.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/notifications/notifications.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background:#F4F4F4;\n}\n\n.box {\n  background-color: #FFFFFF;\n  color: black;\n  margin: 11px;\n}\n\n.mt20 {\n  margin-top: 20px;\n}\n\nion-badge {\n  --background: #E60000;\n  --padding-start: 11px;\n  --padding-end: 16px;\n  --padding-top: 7px;\n  --padding-bottom: 6px;\n  border-radius: 50%;\n}\n\n.itemcntr {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n  align-items: center;\n}\n\n.fs8 {\n  font-size: 8pt;\n}\n\n.fontSans {\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n\n.mt10 {\n  margin-top: 10px;\n}\n\n.badge {\n  --background: #E60000;\n  --padding-start: 7px;\n  --padding-end: 21px;\n  --padding-top: 9px;\n  --padding-bottom: 7px;\n  border-radius: 50%;\n}\n\n.notif {\n  width: 175%;\n  font-size: 21px;\n  padding-top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL25vdGlmaWNhdGlvbnMvbm90aWZpY2F0aW9ucy5wYWdlLnNjc3MiLCJzcmMvYXBwL25vdGlmaWNhdGlvbnMvbm90aWZpY2F0aW9ucy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxvQkFBQTtBQ0NKOztBREVBO0VBRUkseUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQ0FKOztBREdFO0VBQ0ksZ0JBQUE7QUNBTjs7QURFRTtFQUNFLHFCQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQ0NKOztBRENBO0VBQ0ksb0JBQUE7RUFBQSxhQUFBO0VBR0EseUJBQUE7RUFDQSxtQkFBQTtBQ0VKOztBREFFO0VBQ0ksY0FBQTtBQ0dOOztBRERFO0VBQ0UscURBQUE7QUNJSjs7QURGRTtFQUNJLGdCQUFBO0FDS047O0FESEU7RUFDRSxxQkFBQTtFQUNBLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7QUNNSjs7QURKRTtFQUNFLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNPSiIsImZpbGUiOiJzcmMvYXBwL25vdGlmaWNhdGlvbnMvbm90aWZpY2F0aW9ucy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcbiAgICAtLWJhY2tncm91bmQ6I0Y0RjRGNDtcbn1cblxuLmJveHtcbiAgIC8vIGJvcmRlci1yYWRpdXM6OHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNGRkZGRkY7XG4gICAgY29sb3I6YmxhY2s7XG4gICAgbWFyZ2luOiAxMXB4O1xuICAgLy8gYm94LXNoYWRvdzogMC41cHggMC41cHggMC41cHggMC41cHggZ3JleTtcbn1cbiAgLm10MjB7XG4gICAgICBtYXJnaW4tdG9wOjIwcHg7XG4gIH1cbiAgaW9uLWJhZGdle1xuICAgIC0tYmFja2dyb3VuZDogI0U2MDAwMDtcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDExcHg7XG4gICAgLS1wYWRkaW5nLWVuZDogMTZweDtcbiAgICAtLXBhZGRpbmctdG9wOiA3cHg7XG4gICAgLS1wYWRkaW5nLWJvdHRvbTogNnB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cbi5pdGVtY250cntcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIC1tcy1mbGV4LWFsaWduOiBjZW50ZXI7XG4gICAgLXdlYmtpdC1hbGlnbi1pdGVtczogY2VudGVyO1xuICAgIC13ZWJraXQtYm94LWFsaWduOiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjsgICAgICBcbiAgfVxuICAuZnM4e1xuICAgICAgZm9udC1zaXplOjhwdDtcbiAgfVxuICAuZm9udFNhbnN7XG4gICAgZm9udC1mYW1pbHk6J1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgfVxuICAubXQxMHtcbiAgICAgIG1hcmdpbi10b3A6MTBweDtcbiAgfVxuICAuYmFkZ2V7XG4gICAgLS1iYWNrZ3JvdW5kOiAjRTYwMDAwO1xuICAgIC0tcGFkZGluZy1zdGFydDogN3B4O1xuICAgIC0tcGFkZGluZy1lbmQ6IDIxcHg7XG4gICAgLS1wYWRkaW5nLXRvcDogOXB4O1xuICAgIC0tcGFkZGluZy1ib3R0b206IDdweDtcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIH1cbiAgLm5vdGlme1xuICAgIHdpZHRoOiAxNzUlO1xuICAgIGZvbnQtc2l6ZTogMjFweDsgIFxuICAgIHBhZGRpbmctdG9wOiA1cHg7XG4gIH0iLCJpb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDojRjRGNEY0O1xufVxuXG4uYm94IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0ZGRkZGRjtcbiAgY29sb3I6IGJsYWNrO1xuICBtYXJnaW46IDExcHg7XG59XG5cbi5tdDIwIHtcbiAgbWFyZ2luLXRvcDogMjBweDtcbn1cblxuaW9uLWJhZGdlIHtcbiAgLS1iYWNrZ3JvdW5kOiAjRTYwMDAwO1xuICAtLXBhZGRpbmctc3RhcnQ6IDExcHg7XG4gIC0tcGFkZGluZy1lbmQ6IDE2cHg7XG4gIC0tcGFkZGluZy10b3A6IDdweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogNnB4O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG59XG5cbi5pdGVtY250ciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIC1tcy1mbGV4LWFsaWduOiBjZW50ZXI7XG4gIC13ZWJraXQtYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgLXdlYmtpdC1ib3gtYWxpZ246IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmZzOCB7XG4gIGZvbnQtc2l6ZTogOHB0O1xufVxuXG4uZm9udFNhbnMge1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG4ubXQxMCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5iYWRnZSB7XG4gIC0tYmFja2dyb3VuZDogI0U2MDAwMDtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA3cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDIxcHg7XG4gIC0tcGFkZGluZy10b3A6IDlweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogN3B4O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG59XG5cbi5ub3RpZiB7XG4gIHdpZHRoOiAxNzUlO1xuICBmb250LXNpemU6IDIxcHg7XG4gIHBhZGRpbmctdG9wOiA1cHg7XG59Il19 */"

/***/ }),

/***/ "./src/app/notifications/notifications.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/notifications/notifications.page.ts ***!
  \*****************************************************/
/*! exports provided: NotificationsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotificationsPage", function() { return NotificationsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");



var NotificationsPage = /** @class */ (function () {
    function NotificationsPage(translate) {
        this.translate = translate;
    }
    NotificationsPage.prototype.ngOnInit = function () {
    };
    NotificationsPage.ctorParameters = function () { return [
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] }
    ]; };
    NotificationsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-notifications',
            template: __webpack_require__(/*! raw-loader!./notifications.page.html */ "./node_modules/raw-loader/index.js!./src/app/notifications/notifications.page.html"),
            styles: [__webpack_require__(/*! ./notifications.page.scss */ "./src/app/notifications/notifications.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"]])
    ], NotificationsPage);
    return NotificationsPage;
}());



/***/ })

}]);
//# sourceMappingURL=notifications-notifications-module.js.map