(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*********************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm-es5 lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*********************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet-controller_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-controller_8.entry.js",
		"common",
		3
	],
	"./ion-action-sheet-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-ios.entry.js",
		"common",
		4
	],
	"./ion-action-sheet-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-action-sheet-md.entry.js",
		"common",
		5
	],
	"./ion-alert-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-ios.entry.js",
		"common",
		6
	],
	"./ion-alert-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-alert-md.entry.js",
		"common",
		7
	],
	"./ion-app_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-ios.entry.js",
		0,
		"common",
		8
	],
	"./ion-app_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-app_8-md.entry.js",
		0,
		"common",
		9
	],
	"./ion-avatar_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-ios.entry.js",
		"common",
		10
	],
	"./ion-avatar_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-avatar_3-md.entry.js",
		"common",
		11
	],
	"./ion-back-button-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-ios.entry.js",
		"common",
		12
	],
	"./ion-back-button-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-back-button-md.entry.js",
		"common",
		13
	],
	"./ion-backdrop-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-ios.entry.js",
		1,
		"common",
		14
	],
	"./ion-backdrop-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-backdrop-md.entry.js",
		1,
		"common",
		15
	],
	"./ion-button_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-ios.entry.js",
		"common",
		16
	],
	"./ion-button_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-button_2-md.entry.js",
		"common",
		17
	],
	"./ion-card_5-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-ios.entry.js",
		"common",
		18
	],
	"./ion-card_5-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-card_5-md.entry.js",
		"common",
		19
	],
	"./ion-checkbox-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-ios.entry.js",
		"common",
		20
	],
	"./ion-checkbox-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-checkbox-md.entry.js",
		"common",
		21
	],
	"./ion-chip-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-ios.entry.js",
		"common",
		22
	],
	"./ion-chip-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-chip-md.entry.js",
		"common",
		23
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-col_3.entry.js",
		24
	],
	"./ion-datetime_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-ios.entry.js",
		"common",
		25
	],
	"./ion-datetime_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-datetime_3-md.entry.js",
		"common",
		26
	],
	"./ion-fab_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-ios.entry.js",
		"common",
		27
	],
	"./ion-fab_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-fab_3-md.entry.js",
		"common",
		28
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-img.entry.js",
		29
	],
	"./ion-infinite-scroll_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-ios.entry.js",
		"common",
		30
	],
	"./ion-infinite-scroll_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-infinite-scroll_2-md.entry.js",
		"common",
		31
	],
	"./ion-input-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-ios.entry.js",
		"common",
		32
	],
	"./ion-input-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-input-md.entry.js",
		"common",
		33
	],
	"./ion-item-option_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-ios.entry.js",
		"common",
		34
	],
	"./ion-item-option_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item-option_3-md.entry.js",
		"common",
		35
	],
	"./ion-item_8-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-ios.entry.js",
		"common",
		36
	],
	"./ion-item_8-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-item_8-md.entry.js",
		"common",
		37
	],
	"./ion-loading-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-ios.entry.js",
		"common",
		38
	],
	"./ion-loading-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-loading-md.entry.js",
		"common",
		39
	],
	"./ion-menu_4-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_4-ios.entry.js",
		1,
		"common",
		40
	],
	"./ion-menu_4-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-menu_4-md.entry.js",
		1,
		"common",
		41
	],
	"./ion-modal-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-ios.entry.js",
		0,
		"common",
		42
	],
	"./ion-modal-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-modal-md.entry.js",
		0,
		"common",
		43
	],
	"./ion-nav_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-nav_4.entry.js",
		0,
		"common",
		44
	],
	"./ion-popover-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-ios.entry.js",
		0,
		"common",
		45
	],
	"./ion-popover-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-popover-md.entry.js",
		0,
		"common",
		46
	],
	"./ion-progress-bar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-ios.entry.js",
		"common",
		47
	],
	"./ion-progress-bar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-progress-bar-md.entry.js",
		"common",
		48
	],
	"./ion-radio_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-ios.entry.js",
		"common",
		49
	],
	"./ion-radio_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-radio_2-md.entry.js",
		"common",
		50
	],
	"./ion-range-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-ios.entry.js",
		"common",
		51
	],
	"./ion-range-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-range-md.entry.js",
		"common",
		52
	],
	"./ion-refresher_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-ios.entry.js",
		"common",
		53
	],
	"./ion-refresher_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-refresher_2-md.entry.js",
		"common",
		54
	],
	"./ion-reorder_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-ios.entry.js",
		"common",
		55
	],
	"./ion-reorder_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-reorder_2-md.entry.js",
		"common",
		56
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-ripple-effect.entry.js",
		57
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-route_4.entry.js",
		"common",
		58
	],
	"./ion-searchbar-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-ios.entry.js",
		"common",
		59
	],
	"./ion-searchbar-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-searchbar-md.entry.js",
		"common",
		60
	],
	"./ion-segment_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-ios.entry.js",
		"common",
		61
	],
	"./ion-segment_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-segment_2-md.entry.js",
		"common",
		62
	],
	"./ion-select_3-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-ios.entry.js",
		"common",
		63
	],
	"./ion-select_3-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-select_3-md.entry.js",
		"common",
		64
	],
	"./ion-slide_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-ios.entry.js",
		"common",
		65
	],
	"./ion-slide_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-slide_2-md.entry.js",
		"common",
		66
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-spinner.entry.js",
		"common",
		67
	],
	"./ion-split-pane-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-ios.entry.js",
		68
	],
	"./ion-split-pane-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-split-pane-md.entry.js",
		69
	],
	"./ion-tab-bar_2-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-ios.entry.js",
		"common",
		70
	],
	"./ion-tab-bar_2-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab-bar_2-md.entry.js",
		"common",
		71
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-tab_2.entry.js",
		2
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-text.entry.js",
		"common",
		72
	],
	"./ion-textarea-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-ios.entry.js",
		"common",
		73
	],
	"./ion-textarea-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-textarea-md.entry.js",
		"common",
		74
	],
	"./ion-toast-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-ios.entry.js",
		"common",
		75
	],
	"./ion-toast-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toast-md.entry.js",
		"common",
		76
	],
	"./ion-toggle-ios.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-ios.entry.js",
		"common",
		77
	],
	"./ion-toggle-md.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-toggle-md.entry.js",
		"common",
		78
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm-es5/ion-virtual-scroll.entry.js",
		79
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm-es5 lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-app>\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n<!-- AIzaSyCRt0iroi4bWa6q_LcZzAy9ZJdvvOBw94E-->"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/language-popover/language-popover.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/language-popover/language-popover.page.html ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-list>\n  <ion-item button *ngFor=\"let lng of languages\" (click)=\"select(lng.value)\" detail=\"false\">\n    <ion-label text-wrap>\n      {{ lng.text }}\n    </ion-label>\n    <ion-icon slot=\"end\" name=\"checkmark\" *ngIf=\"lng.value == selected\"></ion-icon>\n  </ion-item>\n</ion-list>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modal/appointmentmodal/appointmentmodal.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modal/appointmentmodal/appointmentmodal.page.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n<ion-content>\n<div class=\"txtcntr mt20 pb10 bb1\">\n<ion-label>{{ 'appointmentmodal.areyousure' | translate }}</ion-label>\n</div>\n<div class=\"btn mt5\">\n    <ion-button class=\"changebtn\" fill=\"clear\" (click)=\"closemodal()\" >\n        {{ 'appointmentmodal.oopsno' | translate }}\n    </ion-button>\n    <ion-button class=\"cancelbtn\" fill=\"clear\" >\n        {{ 'appointmentmodal.cancel' | translate }}<br> {{ 'appointmentmodal.appointment' | translate }}\n    </ion-button>\n  </div>\n</ion-content>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/modal/ratemodal/ratemodal.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/modal/ratemodal/ratemodal.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n<ion-content>\n    <div style=\"text-align: left;\n    padding-left: 10px;\">\n        <ion-button fill=\"clear;\" (click)=\"closemodal()\">\n                <ion-icon name=\"close\" ></ion-icon>\n              </ion-button>\n    </div>\n    <div style=\"text-align:center; margin-top: 135px;\">\n<div>\n    <ion-label>{{ 'ratemodal.whatthink' | translate }}</ion-label>\n</div>\n<ion-label>\n    <rating  [rate]=\"rate\"\n    readonly=\"false\" \n    size=\"default\" \n    (ngModelChange)=\"onRateChange($event)\">\n   </rating>\n</ion-label>\n   <div class=\"mt5\">\n    <ion-label class=\"clrg\">{{ 'ratemodal.selectrating' | translate }}</ion-label>\n   </div>\n</div>\n</ion-content>\n"

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"../tab1/tab1.module": [
		"./src/app/tab1/tab1.module.ts",
		"common",
		"tab1-tab1-module"
	],
	"../tab2/tab2.module": [
		"./src/app/tab2/tab2.module.ts",
		"common",
		"tab2-tab2-module"
	],
	"../tab3/tab3.module": [
		"./src/app/tab3/tab3.module.ts",
		"common",
		"tab3-tab3-module"
	],
	"../tab4/tab4.module": [
		"./src/app/tab4/tab4.module.ts",
		"tab4-tab4-module"
	],
	"./about/about.module": [
		"./src/app/about/about.module.ts",
		"about-about-module"
	],
	"./account-details/account-details.module": [
		"./src/app/account-details/account-details.module.ts",
		"account-details-account-details-module"
	],
	"./address/address.module": [
		"./src/app/address/address.module.ts",
		"common",
		"address-address-module"
	],
	"./bookappointment/bookappointment.module": [
		"./src/app/bookappointment/bookappointment.module.ts",
		"common",
		"bookappointment-bookappointment-module"
	],
	"./details-page/details-page.module": [
		"./src/app/details-page/details-page.module.ts",
		"common",
		"details-page-details-page-module"
	],
	"./feedback/feedback.module": [
		"./src/app/feedback/feedback.module.ts",
		"feedback-feedback-module"
	],
	"./language-popover/language-popover.module": [
		"./src/app/language-popover/language-popover.module.ts"
	],
	"./location/location.module": [
		"./src/app/location/location.module.ts",
		"location-location-module"
	],
	"./modal/appointmentmodal/appointmentmodal.module": [
		"./src/app/modal/appointmentmodal/appointmentmodal.module.ts",
		"modal-appointmentmodal-appointmentmodal-module"
	],
	"./modal/ratemodal/ratemodal.module": [
		"./src/app/modal/ratemodal/ratemodal.module.ts",
		"modal-ratemodal-ratemodal-module"
	],
	"./notifications/notifications.module": [
		"./src/app/notifications/notifications.module.ts",
		"notifications-notifications-module"
	],
	"./payments/payments.module": [
		"./src/app/payments/payments.module.ts",
		"payments-payments-module"
	],
	"./review/review.module": [
		"./src/app/review/review.module.ts",
		"common",
		"review-review-module"
	],
	"./settings/settings.module": [
		"./src/app/settings/settings.module.ts",
		"settings-settings-module"
	],
	"./signin/signin.module": [
		"./src/app/signin/signin.module.ts",
		"signin-signin-module"
	],
	"./tab1/tab1.module": [
		"./src/app/tab1/tab1.module.ts",
		"common",
		"tab1-tab1-module"
	],
	"./tab2/tab2.module": [
		"./src/app/tab2/tab2.module.ts",
		"common",
		"tab2-tab2-module"
	],
	"./tabs/tabs.module": [
		"./src/app/tabs/tabs.module.ts",
		"tabs-tabs-module"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    {
        path: '',
        redirectTo: 'location',
        pathMatch: 'full'
    },
    { path: '', loadChildren: './tabs/tabs.module#TabsPageModule' },
    { path: 'tabs/tab2', loadChildren: './tab2/tab2.module#Tab2PageModule' },
    { path: 'tabs/tab1', loadChildren: './tab1/tab1.module#Tab1PageModule' },
    { path: 'tab1', loadChildren: './tab1/tab1.module#Tab1PageModule' },
    { path: 'location', loadChildren: './location/location.module#LocationPageModule' },
    { path: 'language-popover', loadChildren: './language-popover/language-popover.module#LanguagePopoverPageModule' },
    { path: 'account-details', loadChildren: './account-details/account-details.module#AccountDetailsPageModule' },
    { path: 'review', loadChildren: './review/review.module#ReviewPageModule' },
    { path: 'address', loadChildren: './address/address.module#AddressPageModule' },
    { path: 'about', loadChildren: './about/about.module#AboutPageModule' },
    { path: 'payments', loadChildren: './payments/payments.module#PaymentsPageModule' },
    { path: 'settings', loadChildren: './settings/settings.module#SettingsPageModule' },
    { path: 'feedback', loadChildren: './feedback/feedback.module#FeedbackPageModule' },
    { path: 'ratemodal', loadChildren: './modal/ratemodal/ratemodal.module#RatemodalPageModule' },
    { path: 'bookappointment', loadChildren: './bookappointment/bookappointment.module#BookappointmentPageModule' },
    { path: 'details-page', loadChildren: './details-page/details-page.module#DetailsPagePageModule' },
    { path: 'signin', loadChildren: './signin/signin.module#SigninPageModule' },
    { path: 'appointmentmodal', loadChildren: './modal/appointmentmodal/appointmentmodal.module#AppointmentmodalPageModule' },
    { path: 'notifications', loadChildren: './notifications/notifications.module#NotificationsPageModule' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _language_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./language.service */ "./src/app/language.service.ts");






var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, languageService) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.languageService = languageService;
        this.initializeApp();
    }
    AppComponent.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            _this.statusBar.styleDefault();
            _this.splashScreen.hide();
            _this.languageService.setInitialAppLanguage();
        });
    };
    AppComponent.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
        { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"] },
        { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"] },
        { type: _language_service__WEBPACK_IMPORTED_MODULE_5__["LanguageService"] }
    ]; };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html")
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"],
            _language_service__WEBPACK_IMPORTED_MODULE_5__["LanguageService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: createTranslateLoader, AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createTranslateLoader", function() { return createTranslateLoader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _language_popover_language_popover_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./language-popover/language-popover.module */ "./src/app/language-popover/language-popover.module.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/location-accuracy/ngx */ "./node_modules/@ionic-native/location-accuracy/ngx/index.js");
/* harmony import */ var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/diagnostic/ngx */ "./node_modules/@ionic-native/diagnostic/ngx/index.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/http-loader */ "./node_modules/@ngx-translate/http-loader/fesm5/ngx-translate-http-loader.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ "./node_modules/@ionic-native/geolocation/ngx/index.js");
/* harmony import */ var _ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @ionic-native/date-picker/ngx */ "./node_modules/@ionic-native/date-picker/ngx/index.js");
/* harmony import */ var ionic4_rating__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ionic4-rating */ "./node_modules/ionic4-rating/dist/index.js");
/* harmony import */ var _modal_ratemodal_ratemodal_page__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./modal/ratemodal/ratemodal.page */ "./src/app/modal/ratemodal/ratemodal.page.ts");
/* harmony import */ var _modal_appointmentmodal_appointmentmodal_page__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./modal/appointmentmodal/appointmentmodal.page */ "./src/app/modal/appointmentmodal/appointmentmodal.page.ts");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_http__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! @angular/http */ "./node_modules/@angular/http/fesm5/http.js");
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! @angular/fire */ "./node_modules/@angular/fire/index.js");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @angular/fire/auth */ "./node_modules/@angular/fire/auth/index.js");
/* harmony import */ var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! @ionic-native/google-plus/ngx */ "./node_modules/@ionic-native/google-plus/ngx/index.js");
















function createTranslateLoader(http) {
    return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_14__["TranslateHttpLoader"](http, 'assets/i18n/', '.json');
}











var firebaseConfig = {
    apiKey: "AIzaSyCFwW0HZMuakyZ7jRGuEFiSqIRpEfk8AHU",
    authDomain: "shedulix.firebaseapp.com",
    databaseURL: "https://shedulix.firebaseio.com",
    projectId: "shedulix",
    storageBucket: "",
    messagingSenderId: "614341758035",
    appId: "1:614341758035:web:01fab273b843d122"
};
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"], _modal_ratemodal_ratemodal_page__WEBPACK_IMPORTED_MODULE_19__["RatemodalPage"], _modal_appointmentmodal_appointmentmodal_page__WEBPACK_IMPORTED_MODULE_20__["AppointmentmodalPage"]],
            entryComponents: [_modal_ratemodal_ratemodal_page__WEBPACK_IMPORTED_MODULE_19__["RatemodalPage"], _modal_appointmentmodal_appointmentmodal_page__WEBPACK_IMPORTED_MODULE_20__["AppointmentmodalPage"]],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClientModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_22__["FormsModule"],
                _angular_http__WEBPACK_IMPORTED_MODULE_23__["HttpModule"],
                ionic4_rating__WEBPACK_IMPORTED_MODULE_18__["IonicRatingModule"],
                _angular_fire__WEBPACK_IMPORTED_MODULE_24__["AngularFireModule"].initializeApp(firebaseConfig),
                _angular_fire_auth__WEBPACK_IMPORTED_MODULE_25__["AngularFireAuthModule"],
                _ionic_storage__WEBPACK_IMPORTED_MODULE_15__["IonicStorageModule"].forRoot(),
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__["TranslateModule"].forRoot({
                    loader: {
                        provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_13__["TranslateLoader"],
                        useFactory: (createTranslateLoader),
                        deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_12__["HttpClient"]]
                    }
                }), _language_popover_language_popover_module__WEBPACK_IMPORTED_MODULE_7__["LanguagePopoverPageModule"],
            ],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"],
                _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_16__["Geolocation"],
                _ionic_native_date_picker_ngx__WEBPACK_IMPORTED_MODULE_17__["DatePicker"],
                _services_user_service__WEBPACK_IMPORTED_MODULE_21__["UserService"],
                _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_26__["GooglePlus"],
                _ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_10__["LocationAccuracy"],
                _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_11__["Diagnostic"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"] },
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_9__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/language-popover/language-popover.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/language-popover/language-popover.module.ts ***!
  \*************************************************************/
/*! exports provided: LanguagePopoverPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LanguagePopoverPageModule", function() { return LanguagePopoverPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _language_popover_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./language-popover.page */ "./src/app/language-popover/language-popover.page.ts");







var routes = [
    {
        path: '',
        component: _language_popover_page__WEBPACK_IMPORTED_MODULE_6__["LanguagePopoverPage"]
    }
];
var LanguagePopoverPageModule = /** @class */ (function () {
    function LanguagePopoverPageModule() {
    }
    LanguagePopoverPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_language_popover_page__WEBPACK_IMPORTED_MODULE_6__["LanguagePopoverPage"]]
        })
    ], LanguagePopoverPageModule);
    return LanguagePopoverPageModule;
}());



/***/ }),

/***/ "./src/app/language-popover/language-popover.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/language-popover/language-popover.page.scss ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xhbmd1YWdlLXBvcG92ZXIvbGFuZ3VhZ2UtcG9wb3Zlci5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/language-popover/language-popover.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/language-popover/language-popover.page.ts ***!
  \***********************************************************/
/*! exports provided: LanguagePopoverPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LanguagePopoverPage", function() { return LanguagePopoverPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _language_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../language.service */ "./src/app/language.service.ts");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");




var LanguagePopoverPage = /** @class */ (function () {
    function LanguagePopoverPage(languageService, popoverCtrl) {
        this.languageService = languageService;
        this.popoverCtrl = popoverCtrl;
        this.languages = [];
        this.selected = '';
    }
    LanguagePopoverPage.prototype.ngOnInit = function () {
        this.languages = this.languageService.getLanguages();
        this.selected = this.languageService.selected;
    };
    LanguagePopoverPage.prototype.select = function (lng) {
        this.languageService.setLanguage(lng);
        //  localStorage.setItem("language", lng);
        if (this.languages == 'en') {
            document.documentElement.dir = 'ltr';
        }
        else {
            document.documentElement.dir = 'rtl';
        }
        this.popoverCtrl.dismiss();
    };
    LanguagePopoverPage.ctorParameters = function () { return [
        { type: _language_service__WEBPACK_IMPORTED_MODULE_2__["LanguageService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["PopoverController"] }
    ]; };
    LanguagePopoverPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
            selector: 'app-language-popover',
            template: __webpack_require__(/*! raw-loader!./language-popover.page.html */ "./node_modules/raw-loader/index.js!./src/app/language-popover/language-popover.page.html"),
            styles: [__webpack_require__(/*! ./language-popover.page.scss */ "./src/app/language-popover/language-popover.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_language_service__WEBPACK_IMPORTED_MODULE_2__["LanguageService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["PopoverController"]])
    ], LanguagePopoverPage);
    return LanguagePopoverPage;
}());



/***/ }),

/***/ "./src/app/language.service.ts":
/*!*************************************!*\
  !*** ./src/app/language.service.ts ***!
  \*************************************/
/*! exports provided: LanguageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LanguageService", function() { return LanguageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");





var LNG_KEY = 'SELECTED_LANGUAGE';
var LanguageService = /** @class */ (function () {
    function LanguageService(translate, storage, plt) {
        this.translate = translate;
        this.storage = storage;
        this.plt = plt;
        this.selected = '';
    }
    LanguageService.prototype.setInitialAppLanguage = function () {
        //let language = this.translate.getBrowserLang();
        // this.translate.setDefaultLang(language);
        var _this = this;
        this.storage.get(LNG_KEY).then(function (val) {
            if (val) {
                _this.setLanguage(val);
                _this.selected = val;
            }
        });
    };
    LanguageService.prototype.getLanguages = function () {
        return [
            { text: 'English', value: 'en' },
            { text: 'Arabic', value: 'ar' },
        ];
    };
    LanguageService.prototype.setLanguage = function (lng) {
        this.translate.use(lng);
        this.selected = lng;
        this.storage.set(LNG_KEY, lng);
    };
    LanguageService.ctorParameters = function () { return [
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"] }
    ]; };
    LanguageService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"], _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"]])
    ], LanguageService);
    return LanguageService;
}());



/***/ }),

/***/ "./src/app/modal/appointmentmodal/appointmentmodal.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/modal/appointmentmodal/appointmentmodal.page.scss ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".txtcntr {\n  text-align: center;\n}\n\n.mt20 {\n  margin-top: 20px;\n}\n\n.bb1 {\n  border-bottom: 1px solid gray;\n}\n\n.pb10 {\n  padding-bottom: 10px;\n}\n\n.changebtn {\n  --border-color:white;\n  --color:white;\n  --border-width:1px;\n  --color-activated:white;\n  text-transform: none;\n  border: 1px solid white;\n  width: 45%;\n  --color-focused:white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  background-color: #707070;\n  margin-left: 10px;\n}\n\n.cancelbtn {\n  --border-color: #ED145B;\n  --color: #ED145B;\n  --border-width: 1px;\n  --color-activated: white;\n  text-transform: none;\n  border: 1px solid #ED145B;\n  width: 45%;\n  --color-focused: white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  margin-left: 10px;\n}\n\n.mt5 {\n  margin-top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL21vZGFsL2FwcG9pbnRtZW50bW9kYWwvYXBwb2ludG1lbnRtb2RhbC5wYWdlLnNjc3MiLCJzcmMvYXBwL21vZGFsL2FwcG9pbnRtZW50bW9kYWwvYXBwb2ludG1lbnRtb2RhbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtBQ0NKOztBRENBO0VBQ0ksZ0JBQUE7QUNFSjs7QURBQTtFQUNJLDZCQUFBO0FDR0o7O0FEREE7RUFDSSxvQkFBQTtBQ0lKOztBREZBO0VBQ0ksb0JBQUE7RUFDQSxhQUFBO0VBQ0Qsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLG9CQUFBO0VBQ0EsdUJBQUE7RUFDQSxVQUFBO0VBQ0EscUJBQUE7RUFDQSxxREFBQTtFQUNELHlCQUFBO0VBQ0EsaUJBQUE7QUNLRjs7QURIQTtFQUNJLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLHdCQUFBO0VBQ0Esb0JBQUE7RUFDQSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxzQkFBQTtFQUNBLHFEQUFBO0VBQ0EsaUJBQUE7QUNNSjs7QURKQTtFQUNJLGVBQUE7QUNPSiIsImZpbGUiOiJzcmMvYXBwL21vZGFsL2FwcG9pbnRtZW50bW9kYWwvYXBwb2ludG1lbnRtb2RhbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudHh0Y250cntcbiAgICB0ZXh0LWFsaWduOmNlbnRlcjtcbn1cbi5tdDIwe1xuICAgIG1hcmdpbi10b3A6MjBweDtcbn1cbi5iYjF7XG4gICAgYm9yZGVyLWJvdHRvbToxcHggc29saWQgZ3JheTtcbn1cbi5wYjEwe1xuICAgIHBhZGRpbmctYm90dG9tOjEwcHg7XG59XG4uY2hhbmdlYnRue1xuICAgIC0tYm9yZGVyLWNvbG9yOndoaXRlO1xuICAgIC0tY29sb3I6d2hpdGU7XG4gICAtLWJvcmRlci13aWR0aDoxcHg7XG4gICAtLWNvbG9yLWFjdGl2YXRlZDp3aGl0ZTtcbiAgIHRleHQtdHJhbnNmb3JtOm5vbmU7XG4gICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgIHdpZHRoOiA0NSU7XG4gICAtLWNvbG9yLWZvY3VzZWQ6d2hpdGU7XG4gICBmb250LWZhbWlseTonU291cmNlIFNhbnMgUHJvJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNzA3MDcwO1xuICBtYXJnaW4tbGVmdDoxMHB4O1xuICB9XG4uY2FuY2VsYnRue1xuICAgIC0tYm9yZGVyLWNvbG9yOiAjRUQxNDVCO1xuICAgIC0tY29sb3I6ICNFRDE0NUI7XG4gICAgLS1ib3JkZXItd2lkdGg6IDFweDtcbiAgICAtLWNvbG9yLWFjdGl2YXRlZDogd2hpdGU7XG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gICAgYm9yZGVyOiAxcHggc29saWQgI0VEMTQ1QjtcbiAgICB3aWR0aDogNDUlO1xuICAgIC0tY29sb3ItZm9jdXNlZDogd2hpdGU7XG4gICAgZm9udC1mYW1pbHk6ICdTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLWxlZnQ6MTBweDtcbn1cbi5tdDV7XG4gICAgbWFyZ2luLXRvcDo1cHg7XG59IiwiLnR4dGNudHIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5tdDIwIHtcbiAgbWFyZ2luLXRvcDogMjBweDtcbn1cblxuLmJiMSB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBncmF5O1xufVxuXG4ucGIxMCB7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG4uY2hhbmdlYnRuIHtcbiAgLS1ib3JkZXItY29sb3I6d2hpdGU7XG4gIC0tY29sb3I6d2hpdGU7XG4gIC0tYm9yZGVyLXdpZHRoOjFweDtcbiAgLS1jb2xvci1hY3RpdmF0ZWQ6d2hpdGU7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgd2lkdGg6IDQ1JTtcbiAgLS1jb2xvci1mb2N1c2VkOndoaXRlO1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNzA3MDcwO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cblxuLmNhbmNlbGJ0biB7XG4gIC0tYm9yZGVyLWNvbG9yOiAjRUQxNDVCO1xuICAtLWNvbG9yOiAjRUQxNDVCO1xuICAtLWJvcmRlci13aWR0aDogMXB4O1xuICAtLWNvbG9yLWFjdGl2YXRlZDogd2hpdGU7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICBib3JkZXI6IDFweCBzb2xpZCAjRUQxNDVCO1xuICB3aWR0aDogNDUlO1xuICAtLWNvbG9yLWZvY3VzZWQ6IHdoaXRlO1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cblxuLm10NSB7XG4gIG1hcmdpbi10b3A6IDVweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/modal/appointmentmodal/appointmentmodal.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/modal/appointmentmodal/appointmentmodal.page.ts ***!
  \*****************************************************************/
/*! exports provided: AppointmentmodalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppointmentmodalPage", function() { return AppointmentmodalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");




var AppointmentmodalPage = /** @class */ (function () {
    function AppointmentmodalPage(modelctr, translate) {
        this.modelctr = modelctr;
        this.translate = translate;
    }
    AppointmentmodalPage.prototype.ngOnInit = function () {
    };
    AppointmentmodalPage.prototype.closemodal = function () {
        this.modelctr.dismiss({
            'dismissed': true
        });
    };
    AppointmentmodalPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] }
    ]; };
    AppointmentmodalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-appointmentmodal',
            template: __webpack_require__(/*! raw-loader!./appointmentmodal.page.html */ "./node_modules/raw-loader/index.js!./src/app/modal/appointmentmodal/appointmentmodal.page.html"),
            styles: [__webpack_require__(/*! ./appointmentmodal.page.scss */ "./src/app/modal/appointmentmodal/appointmentmodal.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"]])
    ], AppointmentmodalPage);
    return AppointmentmodalPage;
}());



/***/ }),

/***/ "./src/app/modal/ratemodal/ratemodal.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/modal/ratemodal/ratemodal.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".clrg {\n  color: green;\n}\n\n.mt5 {\n  margin-top: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL21vZGFsL3JhdGVtb2RhbC9yYXRlbW9kYWwucGFnZS5zY3NzIiwic3JjL2FwcC9tb2RhbC9yYXRlbW9kYWwvcmF0ZW1vZGFsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7QUNDSjs7QURDQTtFQUNJLGVBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL21vZGFsL3JhdGVtb2RhbC9yYXRlbW9kYWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNscmd7XG4gICAgY29sb3I6Z3JlZW47XG59XG4ubXQ1e1xuICAgIG1hcmdpbi10b3A6NXB4O1xufSIsIi5jbHJnIHtcbiAgY29sb3I6IGdyZWVuO1xufVxuXG4ubXQ1IHtcbiAgbWFyZ2luLXRvcDogNXB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/modal/ratemodal/ratemodal.page.ts":
/*!***************************************************!*\
  !*** ./src/app/modal/ratemodal/ratemodal.page.ts ***!
  \***************************************************/
/*! exports provided: RatemodalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RatemodalPage", function() { return RatemodalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");




var RatemodalPage = /** @class */ (function () {
    function RatemodalPage(modelctr, translate) {
        this.modelctr = modelctr;
        this.translate = translate;
        this.rate = 0;
    }
    RatemodalPage.prototype.ngOnInit = function () {
    };
    RatemodalPage.prototype.onRateChange = function (event) {
        console.log('Your rate:', event);
    };
    RatemodalPage.prototype.closemodal = function () {
        this.modelctr.dismiss();
    };
    RatemodalPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] }
    ]; };
    RatemodalPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-ratemodal',
            template: __webpack_require__(/*! raw-loader!./ratemodal.page.html */ "./node_modules/raw-loader/index.js!./src/app/modal/ratemodal/ratemodal.page.html"),
            styles: [__webpack_require__(/*! ./ratemodal.page.scss */ "./src/app/modal/ratemodal/ratemodal.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"]])
    ], RatemodalPage);
    return RatemodalPage;
}());



/***/ }),

/***/ "./src/app/services/user.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/user.service.ts ***!
  \******************************************/
/*! exports provided: UserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserService", function() { return UserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");





var httpOptions = {
    headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpHeaders"]({ 'Content-Type': 'application/json' })
};
var UserService = /** @class */ (function () {
    function UserService(http) {
        this.http = http;
    }
    UserService.prototype.login = function (user) {
        var url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + "login";
        return this.http.post(url, user, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("Logged In"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.register = function (user) {
        var url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + "register";
        return this.http.post(url, user, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("Logged In"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.sendOtp = function (sendotp) {
        var url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + "send-otp";
        return this.http.post(url, sendotp, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("Logged In"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.loginCheckMobile = function (loginmobile) {
        var url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + "login-check-mobile";
        return this.http.post(url, loginmobile, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("Login with mobile"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.accountDetails = function (accountDetails) {
        var url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + "account-details";
        return this.http.post(url, accountDetails, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("success"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.personalDetails = function (personaldetails) {
        var url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + "personal_detail";
        return this.http.post(url, personaldetails, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("Login with mobiles"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.personalInformation = function (personalinformations) {
        return this.http.get(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + 'personal-information?user_id=' + personalinformations.user_id + '&role_id=' + personalinformations.role_id + '&token=' + personalinformations.token).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("Login with mobiles"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.feedback = function (feedback) {
        var url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + "feedback";
        return this.http.post(url, feedback, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("success"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.personalReview = function (personalreview) {
        return this.http.get(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + 'personal-review?user_id=' + personalreview.user_id + '&role_id=' + personalreview.role_id + '&token=' + personalreview.token).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("Login with mobiles"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.updateAddress = function (addressData) {
        var url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + "personal-address";
        return this.http.post(url, addressData, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("Success"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.profileimage = function (profileimage, fd) {
        var url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + "profile-image";
        return this.http.post(url, profileimage, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("success"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.prototype.loginWithFB = function (fbData) {
        var url = _environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].baseUrl + "fb/callback";
        return this.http.post(url, fbData, httpOptions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function (response) { return console.log("Success"); }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])(function (e) {
            console.error("Error occurred: ", e);
            throw e;
        }));
    };
    UserService.ctorParameters = function () { return [
        { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] }
    ]; };
    UserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]])
    ], UserService);
    return UserService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    baseUrl: 'http://52.28.122.46/api/',
    googleWebClientId: "590332400755-2fahapdla0b1sk92e7btf5n5vrm8eglj.apps.googleusercontent.com"
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/dileep/projects/ionic/schedulix-mobile-app/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map