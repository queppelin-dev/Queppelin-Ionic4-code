(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["location-location-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/location/location.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/location/location.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-content style=\"text-align: center;overflow-y: auto;\" [ngClass]=\"{'bg1':themes == 'white' }\">\n  <ion-item style=\"padding-top:20px;\">\n    <div class=\"col themes1\" slot=\"start\" (click)=\"setThemes('white')\"></div>\n    <div class=\"col themes2\" slot=\"start\" (click)=\"setThemes('black')\"></div>\n    <!-- <ion-icon style=\"color:white;\" name=\"more\" slot=\"icon-only\" (click)=\"openLanguagePopover($event)\" slot=\"end\">\n    </ion-icon> -->\n  </ion-item>\n\n  <div style=\"padding-top:20px;text-align: right; padding-right: 12px;\">\n  <!-- <div (click)=\"openLanguagePopover($event)\">\n    <ion-icon style=\"color:green;\" name=\"more\" slot=\"icon-only\">\n    </ion-icon>\n  </div> -->\n  </div>\n  <div *ngIf=\"location\">\n  <div class=\"pl5 pr5\">\n   \n    <ion-label class=\"title\">schedul<span class=\"tit\">ix</span></ion-label><br/>\n    <ion-label class=\"enable\"> {{ 'location.enable' | translate }}</ion-label>\n    <div class=\"mt30 mb40\">\n      <img style=\"max-width:50%;\" src=\"assets/images/location.svg\" class=\"img\">\n    </div>\n  </div>\n  <div class=\"content pl5 pr5\">\n    <ion-label class=\"fms\">{{ 'location.content' | translate }}</ion-label>\n  </div>\n  <div class=\"content mt10 pl5 pr5\">\n      <ion-label class=\"fms\">{{ 'location.uselocation' | translate }} </ion-label>\n  </div>\n  <div class=\"btn pl5 pr5 mt50\" style=\"text-align:center;\">\n    <ion-button class=\"loc\" fill=\"clear\" (click)=\"enableLocation()\" >\n      {{ 'location.enablebtn' | translate }}\n    </ion-button><br/>\n    <ion-button  fill=\"clear\" class=\"notnowbtn\" (click)=\"gototabs()\">\n      {{ 'location.notnowbtn' | translate }}\n    </ion-button>\n\n  </div>\n</div>\n<div *ngIf=\"locationEnable\">\n  <div class=\"pl5 pr5\" style=\"padding-top:0px;\">\n    <ion-label class=\"title\">schedul<span class=\"tit\">ix</span></ion-label><br/>\n    <ion-label class=\"enable\">{{ 'location.enable' | translate }}</ion-label>\n  </div>\n\n  <div style=\"position:absolute;bottom:170px;right:40px;\">\n    <img style=\"max-width:70%;\" src=\"assets/images/Arrow.svg\">\n  </div>\n  <div style=\"position:absolute;bottom:35px;left:17px;\">\n  <div class=\"content pl5 pr5\">\n    <ion-label class=\"fms\" text-center>{{ 'location.content' | translate }}</ion-label>\n  </div>\n  <div class=\"content mt10 pl5 pr5\">\n      <ion-label class=\"fms\" text-center>{{ 'location.uselocation' | translate }}</ion-label>\n  </div>\n</div>\n</div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/location/location.module.ts":
/*!*********************************************!*\
  !*** ./src/app/location/location.module.ts ***!
  \*********************************************/
/*! exports provided: LocationPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationPageModule", function() { return LocationPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _location_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./location.page */ "./src/app/location/location.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");








var routes = [
    {
        path: '',
        component: _location_page__WEBPACK_IMPORTED_MODULE_6__["LocationPage"]
    }
];
var LocationPageModule = /** @class */ (function () {
    function LocationPageModule() {
    }
    LocationPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_location_page__WEBPACK_IMPORTED_MODULE_6__["LocationPage"]]
        })
    ], LocationPageModule);
    return LocationPageModule;
}());



/***/ }),

/***/ "./src/app/location/location.page.scss":
/*!*********************************************!*\
  !*** ./src/app/location/location.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".title {\n  font-size: 32pt;\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n}\n\n.tit {\n  color: #ED145B;\n}\n\n.enable {\n  font-size: 14pt;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  color: white;\n}\n\nion-content {\n  --background:black;\n}\n\n.mt30 {\n  margin-top: 30px;\n}\n\n.mb40 {\n  margin-bottom: 40px;\n}\n\n.content {\n  font-size: 11pt;\n  font-family: Source Sans Pro;\n  font-style: regular;\n  color: white;\n}\n\n.mt10 {\n  margin-top: 10px;\n}\n\nion-button.loc {\n  --border-color:white;\n  --color:white;\n  --border-width:1px;\n  --color-activated:white;\n  text-transform: none;\n  border: 1px solid white;\n  width: 252px;\n  --color-focused:white;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n\nion-button {\n  --color:white;\n  --color-activated:white;\n  text-transform: none;\n}\n\n.pl5 {\n  padding-left: 5px;\n}\n\n.pr5 {\n  padding-right: 5px;\n}\n\n.mt50 {\n  margin-top: 50px;\n}\n\n/*.btn{\n // background-color: #f41c5c;\n  color: white;\n  text-align: center;\n  text-decoration: none;\n  display: inline-block;\n  font-size: 16px;\n  margin: 4px 2px;\n  cursor: pointer;\n  //border-radius: 75px;\n  --padding-start: 27px;\n  --padding-end: 26px;\n  width: 162px;\n  height: 50px;\n  text-transform: none;\n}*/\n\n.fms {\n  font-family: \"Montserrat\", sans-serif !important;\n  font-size: 13pt;\n}\n\n.notnow {\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n\n.themes1 {\n  width: 25px;\n  height: 25px;\n  background: white;\n  border-radius: 50%;\n}\n\n.themes2 {\n  width: 25px;\n  height: 25px;\n  background: black;\n  border-radius: 50%;\n}\n\nion-item {\n  --background: gray;\n}\n\n.bg1 {\n  --background:white;\n}\n\n.bg1 .title {\n  color: black !important;\n}\n\n.bg1 .enable {\n  color: black !important;\n}\n\n.bg1 .fms {\n  color: black !important;\n}\n\n.bg1 ion-button.loc {\n  border-color: black;\n  --color: black;\n  --border-width: 1px;\n  --color-activated: black;\n  text-transform: none;\n  --color-focused: black;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n\n.bg1 .notnowbtn {\n  color: black !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL2xvY2F0aW9uL2xvY2F0aW9uLnBhZ2Uuc2NzcyIsInNyYy9hcHAvbG9jYXRpb24vbG9jYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0EsZUFBQTtFQUNBLGdEQUFBO0VBQ0EsWUFBQTtBQ0NBOztBRENBO0VBQ0UsY0FBQTtBQ0VGOztBREFBO0VBQ0ksZUFBQTtFQUNBLHFEQUFBO0VBQ0EsWUFBQTtBQ0dKOztBRERBO0VBQ0ksa0JBQUE7QUNJSjs7QURGQTtFQUNFLGdCQUFBO0FDS0Y7O0FESEE7RUFDRSxtQkFBQTtBQ01GOztBREpBO0VBQ0UsZUFBQTtFQUNFLDRCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FDT0o7O0FETEE7RUFDRSxnQkFBQTtBQ1FGOztBRE5BO0VBQ0Usb0JBQUE7RUFDQSxhQUFBO0VBR0Qsa0JBQUE7RUFDQSx1QkFBQTtFQUNBLG9CQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxxREFBQTtBQ09EOztBREpBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0Qsb0JBQUE7QUNPRDs7QURMQTtFQUNFLGlCQUFBO0FDUUY7O0FETkE7RUFDRSxrQkFBQTtBQ1NGOztBRFBBO0VBQ0UsZ0JBQUE7QUNVRjs7QURSQTs7Ozs7Ozs7Ozs7Ozs7O0VBQUE7O0FBZ0JBO0VBQ0UsZ0RBQUE7RUFDQSxlQUFBO0FDV0Y7O0FEVEE7RUFDRSxxREFBQTtBQ1lGOztBRFRBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDWUY7O0FEVEE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNZRjs7QURUQTtFQUNFLGtCQUFBO0FDWUY7O0FEVEE7RUFDRSxrQkFBQTtBQ1lGOztBRFhFO0VBQ0UsdUJBQUE7QUNhSjs7QURYRTtFQUNFLHVCQUFBO0FDYUo7O0FEWEU7RUFDRSx1QkFBQTtBQ2FKOztBRFhFO0VBQ0UsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSx3QkFBQTtFQUNBLG9CQUFBO0VBQ0Esc0JBQUE7RUFDQSxxREFBQTtBQ2FKOztBRFhFO0VBQ0UsdUJBQUE7QUNhSiIsImZpbGUiOiJzcmMvYXBwL2xvY2F0aW9uL2xvY2F0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50aXRsZXtcbmZvbnQtc2l6ZTozMnB0O1xuZm9udC1mYW1pbHk6ICdNb250c2VycmF0Jywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuY29sb3I6d2hpdGU7XG59XG4udGl0e1xuICBjb2xvcjojRUQxNDVCO1xufVxuLmVuYWJsZXtcbiAgICBmb250LXNpemU6MTRwdDtcbiAgICBmb250LWZhbWlseTonU291cmNlIFNhbnMgUHJvJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICAgIGNvbG9yOndoaXRlO1xufVxuaW9uLWNvbnRlbnR7XG4gICAgLS1iYWNrZ3JvdW5kOmJsYWNrO1xufVxuLm10MzB7XG4gIG1hcmdpbi10b3A6MzBweDtcbn1cbi5tYjQwe1xuICBtYXJnaW4tYm90dG9tOjQwcHg7XG59XG4uY29udGVudHtcbiAgZm9udC1zaXplOjExcHQ7XG4gICAgZm9udC1mYW1pbHk6U291cmNlIFNhbnMgUHJvO1xuICAgIGZvbnQtc3R5bGU6IHJlZ3VsYXI7XG4gICAgY29sb3I6d2hpdGU7XG59XG4ubXQxMHtcbiAgbWFyZ2luLXRvcDoxMHB4O1xufVxuaW9uLWJ1dHRvbi5sb2N7XG4gIC0tYm9yZGVyLWNvbG9yOndoaXRlO1xuICAtLWNvbG9yOndoaXRlO1xuIC8vIGZvbnQtZmFtaWx5Ok1vbnRzZXJyYXQ7XG4gLy8gZm9udC1zaXplOiAxNnB0O1xuIC0tYm9yZGVyLXdpZHRoOjFweDtcbiAtLWNvbG9yLWFjdGl2YXRlZDp3aGl0ZTtcbiB0ZXh0LXRyYW5zZm9ybTpub25lO1xuIGJvcmRlcjogMXB4IHNvbGlkIHdoaXRlO1xuIHdpZHRoOiAyNTJweDtcbiAtLWNvbG9yLWZvY3VzZWQ6d2hpdGU7XG4gZm9udC1mYW1pbHk6J1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcblxufVxuaW9uLWJ1dHRvbntcbiAgLS1jb2xvcjp3aGl0ZTtcbiAgLS1jb2xvci1hY3RpdmF0ZWQ6d2hpdGU7XG4gdGV4dC10cmFuc2Zvcm06bm9uZTtcbn1cbi5wbDV7XG4gIHBhZGRpbmctbGVmdDo1cHg7XG59XG4ucHI1e1xuICBwYWRkaW5nLXJpZ2h0OjVweDtcbn1cbi5tdDUwe1xuICBtYXJnaW4tdG9wOjUwcHg7XG59XG4vKi5idG57XG4gLy8gYmFja2dyb3VuZC1jb2xvcjogI2Y0MWM1YztcbiAgY29sb3I6IHdoaXRlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbjogNHB4IDJweDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICAvL2JvcmRlci1yYWRpdXM6IDc1cHg7XG4gIC0tcGFkZGluZy1zdGFydDogMjdweDtcbiAgLS1wYWRkaW5nLWVuZDogMjZweDtcbiAgd2lkdGg6IDE2MnB4O1xuICBoZWlnaHQ6IDUwcHg7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xufSovXG4uZm1ze1xuICBmb250LWZhbWlseTogJ01vbnRzZXJyYXQnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZToxM3B0O1xufVxuLm5vdG5vd3tcbiAgZm9udC1mYW1pbHk6J1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cblxuLnRoZW1lczEge1xuICB3aWR0aDogMjVweDtcbiAgaGVpZ2h0OiAyNXB4O1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuXG4udGhlbWVzMiB7XG4gIHdpZHRoOiAyNXB4O1xuICBoZWlnaHQ6IDI1cHg7XG4gIGJhY2tncm91bmQ6IGJsYWNrO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiBncmF5O1xufVxuXG4uYmcxIHtcbiAgLS1iYWNrZ3JvdW5kOndoaXRlO1xuICAudGl0bGUge1xuICAgIGNvbG9yOmJsYWNrICFpbXBvcnRhbnQ7XG4gIH1cbiAgLmVuYWJsZSB7XG4gICAgY29sb3I6YmxhY2sgIWltcG9ydGFudDtcbiAgfVxuICAuZm1zIHtcbiAgICBjb2xvcjpibGFjayAhaW1wb3J0YW50O1xuICB9XG4gIGlvbi1idXR0b24ubG9jIHtcbiAgICBib3JkZXItY29sb3I6IGJsYWNrO1xuICAgIC0tY29sb3I6IGJsYWNrO1xuICAgIC0tYm9yZGVyLXdpZHRoOiAxcHg7XG4gICAgLS1jb2xvci1hY3RpdmF0ZWQ6IGJsYWNrO1xuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICAgIC0tY29sb3ItZm9jdXNlZDogYmxhY2s7XG4gICAgZm9udC1mYW1pbHk6ICdTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIH1cbiAgLm5vdG5vd2J0biB7XG4gICAgY29sb3I6YmxhY2sgIWltcG9ydGFudDtcbiAgfVxufSIsIi50aXRsZSB7XG4gIGZvbnQtc2l6ZTogMzJwdDtcbiAgZm9udC1mYW1pbHk6IFwiTW9udHNlcnJhdFwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLnRpdCB7XG4gIGNvbG9yOiAjRUQxNDVCO1xufVxuXG4uZW5hYmxlIHtcbiAgZm9udC1zaXplOiAxNHB0O1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBjb2xvcjogd2hpdGU7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOmJsYWNrO1xufVxuXG4ubXQzMCB7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG59XG5cbi5tYjQwIHtcbiAgbWFyZ2luLWJvdHRvbTogNDBweDtcbn1cblxuLmNvbnRlbnQge1xuICBmb250LXNpemU6IDExcHQ7XG4gIGZvbnQtZmFtaWx5OiBTb3VyY2UgU2FucyBQcm87XG4gIGZvbnQtc3R5bGU6IHJlZ3VsYXI7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLm10MTAge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG5pb24tYnV0dG9uLmxvYyB7XG4gIC0tYm9yZGVyLWNvbG9yOndoaXRlO1xuICAtLWNvbG9yOndoaXRlO1xuICAtLWJvcmRlci13aWR0aDoxcHg7XG4gIC0tY29sb3ItYWN0aXZhdGVkOndoaXRlO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gIHdpZHRoOiAyNTJweDtcbiAgLS1jb2xvci1mb2N1c2VkOndoaXRlO1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG5pb24tYnV0dG9uIHtcbiAgLS1jb2xvcjp3aGl0ZTtcbiAgLS1jb2xvci1hY3RpdmF0ZWQ6d2hpdGU7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xufVxuXG4ucGw1IHtcbiAgcGFkZGluZy1sZWZ0OiA1cHg7XG59XG5cbi5wcjUge1xuICBwYWRkaW5nLXJpZ2h0OiA1cHg7XG59XG5cbi5tdDUwIHtcbiAgbWFyZ2luLXRvcDogNTBweDtcbn1cblxuLyouYnRue1xuIC8vIGJhY2tncm91bmQtY29sb3I6ICNmNDFjNWM7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZm9udC1zaXplOiAxNnB4O1xuICBtYXJnaW46IDRweCAycHg7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgLy9ib3JkZXItcmFkaXVzOiA3NXB4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDI3cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDI2cHg7XG4gIHdpZHRoOiAxNjJweDtcbiAgaGVpZ2h0OiA1MHB4O1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbn0qL1xuLmZtcyB7XG4gIGZvbnQtZmFtaWx5OiBcIk1vbnRzZXJyYXRcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDEzcHQ7XG59XG5cbi5ub3Rub3cge1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG4udGhlbWVzMSB7XG4gIHdpZHRoOiAyNXB4O1xuICBoZWlnaHQ6IDI1cHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG59XG5cbi50aGVtZXMyIHtcbiAgd2lkdGg6IDI1cHg7XG4gIGhlaWdodDogMjVweDtcbiAgYmFja2dyb3VuZDogYmxhY2s7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IGdyYXk7XG59XG5cbi5iZzEge1xuICAtLWJhY2tncm91bmQ6d2hpdGU7XG59XG4uYmcxIC50aXRsZSB7XG4gIGNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xufVxuLmJnMSAuZW5hYmxlIHtcbiAgY29sb3I6IGJsYWNrICFpbXBvcnRhbnQ7XG59XG4uYmcxIC5mbXMge1xuICBjb2xvcjogYmxhY2sgIWltcG9ydGFudDtcbn1cbi5iZzEgaW9uLWJ1dHRvbi5sb2Mge1xuICBib3JkZXItY29sb3I6IGJsYWNrO1xuICAtLWNvbG9yOiBibGFjaztcbiAgLS1ib3JkZXItd2lkdGg6IDFweDtcbiAgLS1jb2xvci1hY3RpdmF0ZWQ6IGJsYWNrO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgLS1jb2xvci1mb2N1c2VkOiBibGFjaztcbiAgZm9udC1mYW1pbHk6IFwiU291cmNlIFNhbnMgUHJvXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cbi5iZzEgLm5vdG5vd2J0biB7XG4gIGNvbG9yOiBibGFjayAhaW1wb3J0YW50O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/location/location.page.ts":
/*!*******************************************!*\
  !*** ./src/app/location/location.page.ts ***!
  \*******************************************/
/*! exports provided: LocationPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LocationPage", function() { return LocationPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/location-accuracy/ngx */ "./node_modules/@ionic-native/location-accuracy/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _language_popover_language_popover_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../language-popover/language-popover.page */ "./src/app/language-popover/language-popover.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/diagnostic/ngx */ "./node_modules/@ionic-native/diagnostic/ngx/index.js");
/* harmony import */ var _language_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./../language.service */ "./src/app/language.service.ts");
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ "./node_modules/@ionic-native/geolocation/ngx/index.js");










var LocationPage = /** @class */ (function () {
    function LocationPage(locationAccuracy, navCtrl, diagnostic, translate, popoverCtrl, alertCtrl, languageService, geolocation) {
        this.locationAccuracy = locationAccuracy;
        this.navCtrl = navCtrl;
        this.diagnostic = diagnostic;
        this.translate = translate;
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.languageService = languageService;
        this.geolocation = geolocation;
        this.location = true;
        this.locationEnable = false;
        this.themes = 'black';
    }
    LocationPage.prototype.ngOnInit = function () {
        localStorage.setItem("language", 'en');
        this.languageService.setLanguage('en');
    };
    LocationPage.prototype.enableLocation = function () {
        var _this = this;
        this.diagnostic.isLocationEnabled().then(function (yes) {
            if (!yes) {
                _this.locationAccuracy.canRequest().then(function (canRequest) {
                    _this.location = false;
                    _this.locationEnable = true;
                    _this.locationAccuracy.request(_this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(function () {
                        _this.getCurrentlocation();
                        console.log('Request successful');
                        _this.navCtrl.navigateForward('/tabs');
                    }, function (error) { return console.log('Error requesting location permissions'); });
                });
            }
            if (yes) {
                _this.location = false;
                _this.locationEnable = false;
                _this.navCtrl.navigateForward('/tabs');
            }
        });
    };
    LocationPage.prototype.gototabs = function () {
        this.location = false;
        this.locationEnable = false;
        this.navCtrl.navigateForward('/tabs');
    };
    LocationPage.prototype.openLanguagePopover = function (ev) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var popover;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.popoverCtrl.create({
                            component: _language_popover_language_popover_page__WEBPACK_IMPORTED_MODULE_4__["LanguagePopoverPage"],
                            event: ev
                        })];
                    case 1:
                        popover = _a.sent();
                        return [4 /*yield*/, popover.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LocationPage.prototype.setThemes = function (option) {
        if (option == 'white') {
            this.themes = 'white';
            localStorage.setItem("themes", this.themes);
        }
        else if (option == 'black') {
            this.themes = 'black';
            localStorage.setItem("themes", this.themes);
        }
    };
    LocationPage.prototype.getCurrentlocation = function () {
        var _this = this;
        this.geolocation.getCurrentPosition().then(function (resp) {
            _this.currentlocation = { "lat": resp.coords.latitude, "long": resp.coords.longitude };
            localStorage.setItem("latLong", JSON.stringify({ "lat": resp.coords.latitude, "long": resp.coords.longitude }));
        }).catch(function (error) {
            console.log('Error getting location', error);
        });
    };
    LocationPage.ctorParameters = function () { return [
        { type: _ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_2__["LocationAccuracy"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
        { type: _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__["Diagnostic"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
        { type: _language_service__WEBPACK_IMPORTED_MODULE_7__["LanguageService"] },
        { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__["Geolocation"] }
    ]; };
    LocationPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-location',
            template: __webpack_require__(/*! raw-loader!./location.page.html */ "./node_modules/raw-loader/index.js!./src/app/location/location.page.html"),
            styles: [__webpack_require__(/*! ./location.page.scss */ "./src/app/location/location.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_location_accuracy_ngx__WEBPACK_IMPORTED_MODULE_2__["LocationAccuracy"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
            _ionic_native_diagnostic_ngx__WEBPACK_IMPORTED_MODULE_6__["Diagnostic"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_5__["TranslateService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
            _language_service__WEBPACK_IMPORTED_MODULE_7__["LanguageService"],
            _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_8__["Geolocation"]])
    ], LocationPage);
    return LocationPage;
}());



/***/ })

}]);
//# sourceMappingURL=location-location-module.js.map