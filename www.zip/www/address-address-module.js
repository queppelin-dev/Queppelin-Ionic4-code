(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["address-address-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/address/address.page.html":
/*!*********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/address/address.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\" mode=\"ios\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ 'address.address' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"title\">\n    <p class=\"title-style\">{{ 'address.forsomeservice' | translate }}</p>\n  </div>\n  <ion-row>\n    <ion-col size=\"12\">\n    <ion-item>\n      <!-- <ion-label position=\"floating\">Address</ion-label> -->\n      <ion-input  placeholder=\"Address\" [(ngModel)]=\"addressDetails.address\"></ion-input>\n      <!-- <ion-input *ngIf=\"!personalinformations.get_user_address\">Not available</ion-input> -->\n    </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <ion-item>\n        <ion-select class=\"dropDown\" placeholder=\"Country\" [(ngModel)]=\"addressDetails.country_id\" (ionChange)=\"getStateData()\">\n          <ion-select-option [value]=item.country_id *ngFor = \"let item of countryList\">{{item.country_name}}</ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n    <ion-col>\n      <ion-item>\n        <ion-select class=\"dropDown\" placeholder=\"State\" [(ngModel)]=\"addressDetails.state_id\" (ionChange)=\"getCityData()\">\n          <ion-select-option [value]=item.state_id   *ngFor = \"let item of stateList\">{{item.state_name}}</ion-select-option>\n        </ion-select>\n      </ion-item>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n      <ion-col>\n        <ion-item>\n          <ion-select class=\"dropDown\" placeholder=\"City\" [(ngModel)]=\"addressDetails.city_id\">\n            <ion-select-option [value]=item.city_id *ngFor = \"let item of cityList\">{{item.city_name}}</ion-select-option>\n          </ion-select>\n        </ion-item>\n      </ion-col>\n      <ion-col>\n        <ion-item>\n         <ion-input type=\"text\" placeholder=\"Post Code\" [(ngModel)]=\"addressDetails.zip_code\"></ion-input>\n        </ion-item>\n      </ion-col>\n    </ion-row>\n\n  <!--<div id=\"map_canvas\"></div>-->\n  <div #mapElement class=\"map\"></div><br><br>\n  \n  <ion-button class=\"savebtn\" expand=\"full\" (click)=\"updateAddress()\">SAVE</ion-button>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/address/address.module.ts":
/*!*******************************************!*\
  !*** ./src/app/address/address.module.ts ***!
  \*******************************************/
/*! exports provided: AddressPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddressPageModule", function() { return AddressPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _address_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./address.page */ "./src/app/address/address.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");








var routes = [
    {
        path: '',
        component: _address_page__WEBPACK_IMPORTED_MODULE_6__["AddressPage"]
    }
];
var AddressPageModule = /** @class */ (function () {
    function AddressPageModule() {
    }
    AddressPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_address_page__WEBPACK_IMPORTED_MODULE_6__["AddressPage"]]
        })
    ], AddressPageModule);
    return AddressPageModule;
}());



/***/ }),

/***/ "./src/app/address/address.page.scss":
/*!*******************************************!*\
  !*** ./src/app/address/address.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".title {\n  height: 50px;\n  background: #E6E6E6;\n}\n\n.title-style {\n  font-size: 14px;\n  color: #999999;\n  padding-left: 16px;\n  padding-right: 16px;\n  padding-top: 15px;\n  margin: 0px;\n}\n\nion-content {\n  --background:#f4f4f4;\n}\n\n.list-md {\n  background: none;\n}\n\nion-item {\n  --background:#f4f4f4 !important;\n}\n\n#map_canvas {\n  height: 500px;\n  padding-left: 8px;\n  padding-right: 8px;\n}\n\n.map {\n  height: 50%;\n}\n\n.dropDown {\n  max-width: 100%;\n}\n\n.savebtn {\n  --background: #000000;\n  padding-left: 16px;\n  padding-right: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL2FkZHJlc3MvYWRkcmVzcy5wYWdlLnNjc3MiLCJzcmMvYXBwL2FkZHJlc3MvYWRkcmVzcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVBO0VBQ0ksb0JBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0FDQ0o7O0FERUE7RUFDSSwrQkFBQTtBQ0NKOztBREVBO0VBQ0ksYUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURDRTtFQUNFLFdBQUE7QUNFSjs7QURDRTtFQUNJLGVBQUE7QUNFTjs7QURDRTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQ0VKIiwiZmlsZSI6InNyYy9hcHAvYWRkcmVzcy9hZGRyZXNzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50aXRsZSB7XG4gICAgaGVpZ2h0OiA1MHB4O1xuICAgIGJhY2tncm91bmQ6ICNFNkU2RTY7XG59XG5cbi50aXRsZS1zdHlsZSB7XG4gICAgZm9udC1zaXplOiAxNHB4O1xuICAgIGNvbG9yOiAjOTk5OTk5O1xuICAgIHBhZGRpbmctbGVmdDogMTZweDtcbiAgICBwYWRkaW5nLXJpZ2h0OiAxNnB4O1xuICAgIHBhZGRpbmctdG9wOiAxNXB4O1xuICAgIG1hcmdpbjogMHB4O1xufVxuXG5pb24tY29udGVudHtcbiAgICAtLWJhY2tncm91bmQ6I2Y0ZjRmNDtcbn1cblxuLmxpc3QtbWQge1xuICAgIGJhY2tncm91bmQ6bm9uZTtcbn1cblxuaW9uLWl0ZW0ge1xuICAgIC0tYmFja2dyb3VuZDojZjRmNGY0ICFpbXBvcnRhbnQ7XG59XG5cbiNtYXBfY2FudmFzIHtcbiAgICBoZWlnaHQ6IDUwMHB4O1xuICAgIHBhZGRpbmctbGVmdDogOHB4O1xuICAgIHBhZGRpbmctcmlnaHQ6IDhweDtcbiAgfVxuICAubWFwIHtcbiAgICBoZWlnaHQ6IDUwJTtcbiAgfVxuXG4gIC5kcm9wRG93bntcbiAgICAgIG1heC13aWR0aDogMTAwJTtcbiAgfSBcbiAgXG4gIC5zYXZlYnRue1xuICAgIC0tYmFja2dyb3VuZDogIzAwMDAwMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gICAgcGFkZGluZy1yaWdodDogMTZweDtcbiAgfSIsIi50aXRsZSB7XG4gIGhlaWdodDogNTBweDtcbiAgYmFja2dyb3VuZDogI0U2RTZFNjtcbn1cblxuLnRpdGxlLXN0eWxlIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBjb2xvcjogIzk5OTk5OTtcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxNnB4O1xuICBwYWRkaW5nLXRvcDogMTVweDtcbiAgbWFyZ2luOiAwcHg7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiNmNGY0ZjQ7XG59XG5cbi5saXN0LW1kIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6I2Y0ZjRmNCAhaW1wb3J0YW50O1xufVxuXG4jbWFwX2NhbnZhcyB7XG4gIGhlaWdodDogNTAwcHg7XG4gIHBhZGRpbmctbGVmdDogOHB4O1xuICBwYWRkaW5nLXJpZ2h0OiA4cHg7XG59XG5cbi5tYXAge1xuICBoZWlnaHQ6IDUwJTtcbn1cblxuLmRyb3BEb3duIHtcbiAgbWF4LXdpZHRoOiAxMDAlO1xufVxuXG4uc2F2ZWJ0biB7XG4gIC0tYmFja2dyb3VuZDogIzAwMDAwMDtcbiAgcGFkZGluZy1sZWZ0OiAxNnB4O1xuICBwYWRkaW5nLXJpZ2h0OiAxNnB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/address/address.page.ts":
/*!*****************************************!*\
  !*** ./src/app/address/address.page.ts ***!
  \*****************************************/
/*! exports provided: AddressPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddressPage", function() { return AddressPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var _services_business_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/business.service */ "./src/app/services/business.service.ts");






var AddressPage = /** @class */ (function () {
    function AddressPage(platform, translate, userService, businessService) {
        this.platform = platform;
        this.translate = translate;
        this.userService = userService;
        this.businessService = businessService;
        this.personalinformations = {};
        this.userDetails = {};
        this.personalData = {};
        this.addressData = {};
        this.countryData = {};
        this.countryList = [];
        this.stateList = [];
        this.cityList = [];
        this.counteryShortData = [];
        this.addressDetails = {};
        this.currentlocation = {};
        this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
        console.log(this.userDetails);
        this.currentlocation = JSON.parse(localStorage.getItem("latLong"));
        console.log(this.userDetails);
    }
    AddressPage.prototype.ngOnInit = function () {
        // this.getPersonalInformation();
        this.getCountryList();
    };
    AddressPage.prototype.ngAfterContentInit = function () {
        // this.map = new google.maps.Map(
        //     this.mapElement.nativeElement,
        //     {
        //       center: {lat:this.currentlocation.lat, lng:this.currentlocation.long},
        //       zoom: 16
        //     });
    };
    AddressPage.prototype.getPersonalInformation = function () {
        var _this = this;
        if (this.userDetails) {
            this.personalinformations = {
                "user_id": this.userDetails.id,
                "role_id": this.userDetails.role_id,
                "token": this.userDetails.token.original.token
            };
            console.log(this.personalinformations);
        }
        this.userService.personalInformation(this.personalinformations).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.personalinformations = res.data.user;
                _this.addressDetails = _this.personalinformations.get_user_address;
                if (_this.addressDetails) {
                    _this.map = new google.maps.Map(_this.mapElement.nativeElement, {
                        center: { lat: Number(_this.addressDetails.latitude), lng: Number(_this.addressDetails.longitude) },
                        zoom: 17
                    });
                }
            }
        });
    };
    AddressPage.prototype.getCountryList = function () {
        var _this = this;
        this.businessService.counteryList(this.addressData).subscribe(function (res) {
            console.log(res);
            _this.countryList = res.data.user;
        });
    };
    AddressPage.prototype.updateAddress = function () {
        var addressData = { "user_id": this.userDetails.id, "role_id": this.userDetails.role_id, "address": this.addressDetails.address, "city_id": this.addressDetails.city_id,
            "state_id": this.addressDetails.state_id, "country_id": this.addressDetails.country_id, "zip_code": this.addressDetails.zip_code, "country_postal_code": this.addressDetails.zip_code,
            "latitude": this.currentlocation.lat, "longitude": this.currentlocation.long, "token": this.userDetails.token.original.token };
        this.userService.updateAddress(addressData).subscribe(function (res) {
            console.log(res);
            alert("Address updated successfully");
        });
    };
    AddressPage.prototype.getUniqueSatet = function (arr) {
        var set = new Set();
        return arr.map(function (v, index) {
            if (set.has(v.state_id)) {
                return false;
            }
            else {
                set.add(v.state_id);
                return index;
            }
        }).filter(function (e) { return e; }).map(function (e) { return arr[e]; });
    };
    AddressPage.prototype.getUniqueCity = function (arr) {
        var set = new Set();
        return arr.map(function (v, index) {
            if (set.has(v.city_id)) {
                return false;
            }
            else {
                set.add(v.city_id);
                return index;
            }
        }).filter(function (e) { return e; }).map(function (e) { return arr[e]; });
    };
    AddressPage.prototype.getStateData = function () {
        var _this = this;
        this.addressData = { "country_id": this.addressDetails.country_id };
        this.businessService.counteryList(this.addressData).subscribe(function (res) {
            console.log(res);
            var CounteryData = res.data.user;
            _this.stateList = _this.getUniqueSatet(CounteryData);
            console.log(_this.stateList);
        });
    };
    AddressPage.prototype.getCityData = function () {
        var _this = this;
        this.addressData = { "country_id": this.addressDetails.country_id, "state_id": this.addressDetails.state_id };
        this.businessService.counteryList(this.addressData).subscribe(function (res) {
            console.log(res);
            var CounteryData = res.data.user;
            _this.cityList = _this.getUniqueCity(CounteryData);
            console.log(_this.counteryShortData);
        });
    };
    AddressPage.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] },
        { type: _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"] },
        { type: _services_business_service__WEBPACK_IMPORTED_MODULE_5__["BusinessService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('mapElement', { read: true, static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], AddressPage.prototype, "mapElement", void 0);
    AddressPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-address',
            template: __webpack_require__(/*! raw-loader!./address.page.html */ "./node_modules/raw-loader/index.js!./src/app/address/address.page.html"),
            styles: [__webpack_require__(/*! ./address.page.scss */ "./src/app/address/address.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"],
            _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"],
            _services_business_service__WEBPACK_IMPORTED_MODULE_5__["BusinessService"]])
    ], AddressPage);
    return AddressPage;
}());



/***/ })

}]);
//# sourceMappingURL=address-address-module.js.map