(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab4-tab4-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/tab4/tab4.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/tab4/tab4.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>My Profile</ion-title>\r\n  </ion-toolbar>\r\n</ion-header> -->\r\n\r\n<ion-content>\r\n  <div class=\"cover\">\r\n    <ion-grid>\r\n      <ion-row>\r\n        <ion-col size=\"3\">\r\n        <!-- <img *ngIf=\"imagedetails.image\" src=\"{{imagedetails.image}}\" class=\"profilePic\" style=\"position:relative;\"> -->\r\n        <img  src=\"assets/userImage/avatar.png\" class=\"profilePic\" style=\"position:relative;\">\r\n        <div class=\"editimage\" (click)=\"uploadimage()\">\r\n        <img src=\"assets/images/edits.svg\">\r\n        </div>\r\n        </ion-col>\r\n        <ion-col>\r\n          <div class=\"covertxt\">\r\n            <ion-label class=\"fontMontserrat\">Mohamed Ahmed Zaky</ion-label><br>\r\n            <img src=\"assets/images/location1.svg\"><ion-label class=\"fontSans fs8\">&nbsp;&nbsp;8KM, Dark Horse RD, 1940, 3232</ion-label>\r\n          </div>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </div>\r\n\r\n  <div class=\"favoriteService\">\r\n    <h6 class=\"favoriteStyle\">{{ 'tab4.getbyinvite' | translate }}</h6>\r\n  </div>\r\n\r\n  <ion-list>\r\n    <ion-item (click)=\"goToAccountDetailPage()\">\r\n      {{ 'tab4.account' | translate }}\r\n      <ion-icon class= \"icon-color\" name=\"ios-arrow-forward\" slot=\"end\"></ion-icon>\r\n    </ion-item>\r\n    <ion-item (click)=\"goToAddressPage()\">\r\n      {{ 'tab4.Address' | translate }}\r\n      <ion-icon class= \"icon-color\" name=\"ios-arrow-forward\" slot=\"end\"></ion-icon>\r\n    </ion-item>\r\n    <ion-item  (click)=\"goToReviewPage()\">\r\n      {{ 'tab4.reviews' | translate }}\r\n      <ion-icon class= \"icon-color\" name=\"ios-arrow-forward\" slot=\"end\"></ion-icon>\r\n    </ion-item>\r\n   <!--<ion-item (click)=\"goToPaymentPage()\">\r\n      {{ 'tab4.payments' | translate }}\r\n      <ion-icon class= \"icon-color\" name=\"ios-arrow-forward\" slot=\"end\"></ion-icon>\r\n    </ion-item>-->\r\n    <ion-item (click)=\"goToSettingPage()\">\r\n      {{ 'tab4.settings' | translate }}\r\n      <ion-icon class= \"icon-color\" name=\"ios-arrow-forward\" slot=\"end\"></ion-icon>\r\n    </ion-item>\r\n    <ion-item (click)=\"goToFeedabackPage()\">\r\n      {{ 'tab4.feedback' | translate }}\r\n      <ion-icon class= \"icon-color\" name=\"ios-arrow-forward\" slot=\"end\"></ion-icon>\r\n    </ion-item>\r\n    <ion-item (click)=\"goToAboutPage()\">\r\n      {{ 'tab4.About Schedulix' | translate }}\r\n      <ion-icon class= \"icon-color\" name=\"ios-arrow-forward\" slot=\"end\"></ion-icon>\r\n    </ion-item>\r\n    <ion-item (click)=\"logout()\">\r\n      {{ 'tab4.Logout' | translate }}\r\n      <ion-icon class= \"icon-color\" name=\"ios-arrow-forward\" slot=\"end\"></ion-icon>\r\n    </ion-item> \r\n  </ion-list>\r\n\r\n</ion-content>\r\n"

/***/ }),

/***/ "./src/app/tab4/tab4.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab4/tab4.module.ts ***!
  \*************************************/
/*! exports provided: Tab4PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab4PageModule", function() { return Tab4PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _tab4_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab4.page */ "./src/app/tab4/tab4.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");








var routes = [
    {
        path: '',
        component: _tab4_page__WEBPACK_IMPORTED_MODULE_6__["Tab4Page"]
    }
];
var Tab4PageModule = /** @class */ (function () {
    function Tab4PageModule() {
    }
    Tab4PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_tab4_page__WEBPACK_IMPORTED_MODULE_6__["Tab4Page"]]
        })
    ], Tab4PageModule);
    return Tab4PageModule;
}());



/***/ }),

/***/ "./src/app/tab4/tab4.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab4/tab4.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".cover {\n  height: 15%;\n  background: #2a2a2a;\n  color: #ffffff;\n}\n\n.profilePic {\n  max-width: 85%;\n}\n\n.covertxt {\n  text-align: left;\n  margin-top: 8px;\n}\n\n.fontMontserrat {\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n  font-size: 16px;\n}\n\n.fontSans {\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  color: white;\n}\n\n.fs8 {\n  font-size: 8pt;\n}\n\n.favoriteService {\n  height: 10% auto;\n  background: #ED145B;\n}\n\n.favoriteStyle {\n  color: #ffffff;\n  font-size: 14px;\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  padding: 10px;\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n\n.item-native {\n  --border-style: dashed !important;\n}\n\n.icon-color {\n  color: #cccccc;\n}\n\n:host {\n  --border-style: dashed !important;\n}\n\n.editimage {\n  position: absolute;\n  bottom: 9px;\n  right: 9px;\n  background: white;\n  border-radius: 50%;\n  height: 20px;\n  width: 20px;\n  padding-left: 6px;\n  padding-top: 2px;\n  padding-right: 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL3RhYjQvdGFiNC5wYWdlLnNjc3MiLCJzcmMvYXBwL3RhYjQvdGFiNC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUE7RUFDSSxjQUFBO0FDQ0o7O0FERUE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLGdEQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLHFEQUFBO0VBQ0EsWUFBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtBQ0NKOztBREVBO0VBQ0ksZ0JBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxxREFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURFQTtFQUNJLGlDQUFBO0FDQ0o7O0FERUE7RUFDRyxjQUFBO0FDQ0g7O0FERUE7RUFFSSxpQ0FBQTtBQ0FKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvdGFiNC90YWI0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb3ZlciB7XHJcbiAgICBoZWlnaHQ6IDE1JTtcclxuICAgIGJhY2tncm91bmQ6ICMyYTJhMmE7XHJcbiAgICBjb2xvcjogI2ZmZmZmZjtcclxufVxyXG5cclxuLnByb2ZpbGVQaWMge1xyXG4gICAgbWF4LXdpZHRoOiA4NSU7XHJcbn1cclxuXHJcbi5jb3ZlcnR4dHtcclxuICAgIHRleHQtYWxpZ246bGVmdDtcclxuICAgIG1hcmdpbi10b3A6IDhweDtcclxufVxyXG5cclxuLmZvbnRNb250c2VycmF0e1xyXG4gICAgZm9udC1mYW1pbHk6ICdNb250c2VycmF0Jywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG4gICAgY29sb3I6d2hpdGU7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuXHJcbi5mb250U2Fuc3tcclxuICAgIGZvbnQtZmFtaWx5OidTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICBjb2xvcjp3aGl0ZTtcclxufVxyXG5cclxuLmZzOHtcclxuICAgIGZvbnQtc2l6ZTo4cHQ7XHJcbn1cclxuXHJcbi5mYXZvcml0ZVNlcnZpY2Uge1xyXG4gICAgaGVpZ2h0OiAxMCUgYXV0bztcclxuICAgIGJhY2tncm91bmQ6ICNFRDE0NUI7XHJcbn1cclxuXHJcbi5mYXZvcml0ZVN0eWxlIHtcclxuICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgZm9udC1mYW1pbHk6J1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbn1cclxuXHJcbi5pdGVtLW5hdGl2ZSB7XHJcbiAgICAtLWJvcmRlci1zdHlsZTogZGFzaGVkICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5pY29uLWNvbG9yIHtcclxuICAgY29sb3I6I2NjY2NjYztcclxufVxyXG5cclxuOmhvc3Qge1xyXG5cclxuICAgIC0tYm9yZGVyLXN0eWxlOiBkYXNoZWQgIWltcG9ydGFudDtcclxufVxyXG4uZWRpdGltYWdle1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiA5cHg7XHJcbiAgICByaWdodDogOXB4O1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBoZWlnaHQ6IDIwcHg7XHJcbiAgICB3aWR0aDogMjBweDtcclxuICAgIHBhZGRpbmctbGVmdDogNnB4O1xyXG4gICAgcGFkZGluZy10b3A6IDJweDtcclxuICAgIHBhZGRpbmctcmlnaHQ6NHB4O1xyXG59IiwiLmNvdmVyIHtcbiAgaGVpZ2h0OiAxNSU7XG4gIGJhY2tncm91bmQ6ICMyYTJhMmE7XG4gIGNvbG9yOiAjZmZmZmZmO1xufVxuXG4ucHJvZmlsZVBpYyB7XG4gIG1heC13aWR0aDogODUlO1xufVxuXG4uY292ZXJ0eHQge1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBtYXJnaW4tdG9wOiA4cHg7XG59XG5cbi5mb250TW9udHNlcnJhdCB7XG4gIGZvbnQtZmFtaWx5OiBcIk1vbnRzZXJyYXRcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cblxuLmZvbnRTYW5zIHtcbiAgZm9udC1mYW1pbHk6IFwiU291cmNlIFNhbnMgUHJvXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uZnM4IHtcbiAgZm9udC1zaXplOiA4cHQ7XG59XG5cbi5mYXZvcml0ZVNlcnZpY2Uge1xuICBoZWlnaHQ6IDEwJSBhdXRvO1xuICBiYWNrZ3JvdW5kOiAjRUQxNDVCO1xufVxuXG4uZmF2b3JpdGVTdHlsZSB7XG4gIGNvbG9yOiAjZmZmZmZmO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtZmFtaWx5OiBcIlNvdXJjZSBTYW5zIFByb1wiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuXG4uaXRlbS1uYXRpdmUge1xuICAtLWJvcmRlci1zdHlsZTogZGFzaGVkICFpbXBvcnRhbnQ7XG59XG5cbi5pY29uLWNvbG9yIHtcbiAgY29sb3I6ICNjY2NjY2M7XG59XG5cbjpob3N0IHtcbiAgLS1ib3JkZXItc3R5bGU6IGRhc2hlZCAhaW1wb3J0YW50O1xufVxuXG4uZWRpdGltYWdlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDlweDtcbiAgcmlnaHQ6IDlweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgaGVpZ2h0OiAyMHB4O1xuICB3aWR0aDogMjBweDtcbiAgcGFkZGluZy1sZWZ0OiA2cHg7XG4gIHBhZGRpbmctdG9wOiAycHg7XG4gIHBhZGRpbmctcmlnaHQ6IDRweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/tab4/tab4.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab4/tab4.page.ts ***!
  \***********************************/
/*! exports provided: Tab4Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab4Page", function() { return Tab4Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/user.service */ "./src/app/services/user.service.ts");





var Tab4Page = /** @class */ (function () {
    function Tab4Page(navCtrl, translate, userService) {
        this.navCtrl = navCtrl;
        this.translate = translate;
        this.userService = userService;
        this.userDetails = {};
        this.imagedata = {};
        this.showphotopath = false;
        this.selectedFile = null;
        this.language = localStorage.getItem("language");
        if (this.language == 'ar') {
            document.documentElement.dir = 'rtl';
        }
        else if (this.language == 'en') {
            document.documentElement.dir = 'ltr';
        }
        this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
    }
    Tab4Page.prototype.ngOnInit = function () {
    };
    Tab4Page.prototype.goToAccountDetailPage = function () {
        this.navCtrl.navigateForward('/account-details');
    };
    Tab4Page.prototype.goToReviewPage = function () {
        this.navCtrl.navigateForward('/review');
    };
    Tab4Page.prototype.goToAddressPage = function () {
        this.navCtrl.navigateForward('/address');
    };
    Tab4Page.prototype.goToAboutPage = function () {
        this.navCtrl.navigateForward('/about');
    };
    Tab4Page.prototype.goToSettingPage = function () {
        this.navCtrl.navigateForward('/settings');
    };
    Tab4Page.prototype.goToFeedabackPage = function () {
        this.navCtrl.navigateForward('/feedback');
    };
    /*goToPaymentPage() {
      this.navCtrl.navigateForward('/payments');
    }*/
    Tab4Page.prototype.onFileSelected = function (event) {
        console.log(event);
        this.selectedFile = event.target.files[0];
    };
    Tab4Page.prototype.uploadimage = function () {
        var _this = this;
        var fd = new FormData();
        fd.append('image', this.selectedFile, this.selectedFile.name);
        if (this.userDetails) {
            this.imagedata = {
                "user_id": this.userDetails.id,
                "image_name": this.imagedata.upimgfile, "token": this.userDetails.token.original.token
            };
        }
        console.log('image', this.imagedata);
        this.userService.profileimage(this.imagedata, fd).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.imagedetails = res.data.user;
                console.log('image', _this.imagedetails);
            }
        });
    };
    Tab4Page.prototype.logout = function () {
        localStorage.clear();
        this.navCtrl.navigateForward('tabs/tab1');
        // this.navCtrl.navigateForward('tabs/tab1');
        // this.navCtrl.setRoot(this.navCtrl.getActive().component);
    };
    Tab4Page.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] },
        { type: _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"] }
    ]; };
    Tab4Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tab4',
            template: __webpack_require__(/*! raw-loader!./tab4.page.html */ "./node_modules/raw-loader/index.js!./src/app/tab4/tab4.page.html"),
            styles: [__webpack_require__(/*! ./tab4.page.scss */ "./src/app/tab4/tab4.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"],
            _services_user_service__WEBPACK_IMPORTED_MODULE_4__["UserService"]])
    ], Tab4Page);
    return Tab4Page;
}());



/***/ })

}]);
//# sourceMappingURL=tab4-tab4-module.js.map