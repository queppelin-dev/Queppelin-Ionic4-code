(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["account-details-account-details-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/account-details/account-details.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/account-details/account-details.page.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ 'account-details.account' | translate }}</ion-title>\n  </ion-toolbar>\n</ion-header> -->\n<ion-header>\n    <ion-toolbar color=\"primary\" mode=\"ios\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button></ion-back-button>\n      </ion-buttons>\n      <ion-title>{{ 'account-details.account' | translate }}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n<ion-content>\n\n  <div class=\"title\">\n    <h5 class=\"title-style\">{{ 'account-details.personal' | translate }}</h5>\n  </div>\n  <div>\n  <ion-list>\n    <ion-item>\n      <img src=\"assets/images/smartphone.svg\">\n      <h6 class=\"text-style\" *ngIf=\"acountDetails.name\">{{  acountDetails.name }} </h6>\n      <h6 class=\"text-style\" *ngIf=\"!acountDetails.name\">Name is not available </h6>\n    </ion-item>\n    <ion-item>\n      <img src=\"assets/images/smartphone.svg\">\n      <h6 class=\"text-style\" *ngIf=\"acountDetails.email\">{{  acountDetails.email }}</h6>\n      <h6 class=\"text-style\" *ngIf=\"!acountDetails.email\">email is not available</h6>\n      <button slot=\"end\" class=\"btn\">{{ 'account-details.changebtn' | translate }}</button>\n    </ion-item>\n    <ion-item>\n      <img src=\"assets/images/smartphone.svg\">\n      <h6 class=\"text-style\" *ngIf=\"acountDetails.mobile\">{{ acountDetails.mobile  }}</h6>\n      <h6 class=\"text-style\" *ngIf=\"!acountDetails.mobile\">Mobile no is not available</h6>\n      <button slot=\"end\" class=\"btn\">{{ 'account-details.changebtn' | translate }}</button>\n    </ion-item>\n    <ion-item>\n      <img src=\"assets/images/smartphone.svg\">\n      <h6 class=\"text-style\" *ngIf=\"acountDetails.dob\">{{ acountDetails.dob }}</h6>\n      <h6 class=\"text-style\" *ngIf=\"!acountDetails.dob\">Birth Date is not available</h6>\n    </ion-item>\n  </ion-list>\n  <div class=\"title\">\n    <h5 class=\"title-style\">{{ 'account-details.servicetype' | translate }}</h5>\n  </div>\n  \n    <h5 class=\"text-center\">{{ 'account-details.firstshow' | translate }}</h5>\n   <div style=\"text-align:center;margin-top:10px;\">\n   <ion-label class=\"tab\">\n     <!-- <ion-col class=\"tabs-style\" style=\"color:red;\" *ngIf=\"acountDetailwoman\">\n      {{ accountDetailwoman }}\n      </ion-col> -->\n      <ion-col class=\"tabs-style\">\n        {{ 'account-details.woman' | translate }}\n      </ion-col>\n      <!-- <ion-col class=\"tabs-style\" style=\"color:red;\" *ngIf=\"acountDetailman\">\n        {{ accountDetailman }}\n        </ion-col> -->\n      <ion-col  class=\"tabs-style bl1 br1\">\n       {{ 'account-details.man' | translate }}\n      </ion-col>\n      <!-- <ion-col class=\"tabs-style\" style=\"color:red;\" *ngIf=\"accountDetailboth\">\n          {{ accountDetailboth }}\n      </ion-col> -->\n      <ion-col class=\"tabs-style\" >\n          {{ 'account-details.both' | translate }}\n      </ion-col>\n    </ion-label>\n    <!-- <ion-input placeholder = \"{{ acountDetails.services_type }}\"></ion-input> -->\n    </div>\n  </div>\n    <div class=\"save-button\">\n      <ion-button expand=\"full\" style=\"background:#000000;\" (click)=\"savebtn()\">{{ 'account-details.savebtn' | translate }}</ion-button>\n    </div>\n  \n\n\n</ion-content>\n"

/***/ }),

/***/ "./src/app/account-details/account-details.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/account-details/account-details.module.ts ***!
  \***********************************************************/
/*! exports provided: AccountDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountDetailsPageModule", function() { return AccountDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _account_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./account-details.page */ "./src/app/account-details/account-details.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");








var routes = [
    {
        path: '',
        component: _account_details_page__WEBPACK_IMPORTED_MODULE_6__["AccountDetailsPage"]
    }
];
var AccountDetailsPageModule = /** @class */ (function () {
    function AccountDetailsPageModule() {
    }
    AccountDetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_account_details_page__WEBPACK_IMPORTED_MODULE_6__["AccountDetailsPage"]]
        })
    ], AccountDetailsPageModule);
    return AccountDetailsPageModule;
}());



/***/ }),

/***/ "./src/app/account-details/account-details.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/account-details/account-details.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content {\n  --background:#f4f4f4;\n}\n\n.list-md {\n  background: none;\n}\n\nion-item {\n  --background:#f4f4f4 !important;\n}\n\n.title {\n  height: 50px;\n  background: #E6E6E6;\n  color: #2a2a2a !important;\n}\n\n.title-style {\n  font-size: 16px;\n  color: #636162;\n  padding-left: 16px;\n  padding-top: 15px;\n  padding-right: 16px;\n}\n\nh1, h2, h3, h4, h5, h6 {\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n\n.text-style {\n  color: #636162;\n  font-size: 16px;\n  padding-left: 16px;\n  padding-right: 16px;\n}\n\n.text-center {\n  text-align: center;\n  color: #636162;\n  font-size: 16px;\n  padding-top: 16px;\n}\n\n.tab {\n  border: 1px solid #999999;\n  margin: 16px;\n  border-radius: 5px;\n}\n\n.tabs-style {\n  text-align: center;\n  color: #636162;\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n\n.save-button {\n  margin: 16px;\n  padding-top: 50px;\n}\n\n.vl {\n  border-left: 1px solid #999999;\n  height: 20px;\n}\n\n.btn {\n  border: 1px solid #636162;\n  padding-top: 5px;\n  padding-bottom: 5px;\n  color: #636162;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL2FjY291bnQtZGV0YWlscy9hY2NvdW50LWRldGFpbHMucGFnZS5zY3NzIiwic3JjL2FwcC9hY2NvdW50LWRldGFpbHMvYWNjb3VudC1kZXRhaWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLG9CQUFBO0FDQ0o7O0FERUE7RUFDSSxnQkFBQTtBQ0NKOztBREVBO0VBQ0ksK0JBQUE7QUNDSjs7QURFQTtFQUNJLFlBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0FDQ0o7O0FERUE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ0NKOztBREVBO0VBQ0kseUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7QUNDSjs7QURFQTtFQUNHLFlBQUE7RUFDQSxpQkFBQTtBQ0NIOztBREVBO0VBQ0ksOEJBQUE7RUFDQSxZQUFBO0FDQ0o7O0FERUU7RUFDRSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9hY2NvdW50LWRldGFpbHMvYWNjb3VudC1kZXRhaWxzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50e1xyXG4gICAgLS1iYWNrZ3JvdW5kOiNmNGY0ZjQ7XHJcbn1cclxuXHJcbi5saXN0LW1kIHtcclxuICAgIGJhY2tncm91bmQ6bm9uZTtcclxufVxyXG5cclxuaW9uLWl0ZW0ge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiNmNGY0ZjQgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnRpdGxlIHtcclxuICAgIGhlaWdodDogNTBweDtcclxuICAgIGJhY2tncm91bmQ6ICNFNkU2RTY7XHJcbiAgICBjb2xvcjojMmEyYTJhICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi50aXRsZS1zdHlsZSB7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBjb2xvcjogIzYzNjE2MjtcclxuICAgIHBhZGRpbmctbGVmdDogMTZweDtcclxuICAgIHBhZGRpbmctdG9wOiAxNXB4O1xyXG4gICAgcGFkZGluZy1yaWdodDoxNnB4O1xyXG59XHJcblxyXG5oMSwgaDIsIGgzLCBoNCwgaDUsIGg2IHtcclxuICAgIG1hcmdpbi10b3A6IDBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDBweDtcclxufVxyXG5cclxuLnRleHQtc3R5bGUge1xyXG4gICAgY29sb3I6ICM2MzYxNjI7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDE2cHg7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OjE2cHg7XHJcbn1cclxuXHJcbi50ZXh0LWNlbnRlciB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogIzYzNjE2MjtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIHBhZGRpbmctdG9wOiAxNnB4O1xyXG59XHJcblxyXG4udGFiIHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICM5OTk5OTk7XHJcbiAgICBtYXJnaW46IDE2cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbn1cclxuXHJcbi50YWJzLXN0eWxlIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjNjM2MTYyO1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxufVxyXG5cclxuLnNhdmUtYnV0dG9uIHtcclxuICAgbWFyZ2luOiAxNnB4O1xyXG4gICBwYWRkaW5nLXRvcDo1MHB4O1xyXG59XHJcblxyXG4udmwge1xyXG4gICAgYm9yZGVyLWxlZnQ6IDFweCBzb2xpZCAjOTk5OTk5O1xyXG4gICAgaGVpZ2h0OiAyMHB4O1xyXG4gIH1cclxuXHJcbiAgLmJ0biB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjNjM2MTYyO1xyXG4gICAgcGFkZGluZy10b3A6IDVweDtcclxuICAgIHBhZGRpbmctYm90dG9tOiA1cHg7XHJcbiAgICBjb2xvcjogIzYzNjE2MjtcclxuICB9XHJcbiAgLmJsMXtcclxuICAgICAvLyBib3JkZXItbGVmdDoxcHggc29saWQgZ3JheTtcclxuICB9XHJcbiAgLmJyMXtcclxuICAgICAvLyBib3JkZXItcmlnaHQ6MXB4IHNvbGlkIGdyYXk7XHJcbiAgfSIsImlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiNmNGY0ZjQ7XG59XG5cbi5saXN0LW1kIHtcbiAgYmFja2dyb3VuZDogbm9uZTtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6I2Y0ZjRmNCAhaW1wb3J0YW50O1xufVxuXG4udGl0bGUge1xuICBoZWlnaHQ6IDUwcHg7XG4gIGJhY2tncm91bmQ6ICNFNkU2RTY7XG4gIGNvbG9yOiAjMmEyYTJhICFpbXBvcnRhbnQ7XG59XG5cbi50aXRsZS1zdHlsZSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6ICM2MzYxNjI7XG4gIHBhZGRpbmctbGVmdDogMTZweDtcbiAgcGFkZGluZy10b3A6IDE1cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDE2cHg7XG59XG5cbmgxLCBoMiwgaDMsIGg0LCBoNSwgaDYge1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbn1cblxuLnRleHQtc3R5bGUge1xuICBjb2xvcjogIzYzNjE2MjtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBwYWRkaW5nLWxlZnQ6IDE2cHg7XG4gIHBhZGRpbmctcmlnaHQ6IDE2cHg7XG59XG5cbi50ZXh0LWNlbnRlciB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICM2MzYxNjI7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgcGFkZGluZy10b3A6IDE2cHg7XG59XG5cbi50YWIge1xuICBib3JkZXI6IDFweCBzb2xpZCAjOTk5OTk5O1xuICBtYXJnaW46IDE2cHg7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cblxuLnRhYnMtc3R5bGUge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjNjM2MTYyO1xuICBwYWRkaW5nLXRvcDogMTBweDtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG5cbi5zYXZlLWJ1dHRvbiB7XG4gIG1hcmdpbjogMTZweDtcbiAgcGFkZGluZy10b3A6IDUwcHg7XG59XG5cbi52bCB7XG4gIGJvcmRlci1sZWZ0OiAxcHggc29saWQgIzk5OTk5OTtcbiAgaGVpZ2h0OiAyMHB4O1xufVxuXG4uYnRuIHtcbiAgYm9yZGVyOiAxcHggc29saWQgIzYzNjE2MjtcbiAgcGFkZGluZy10b3A6IDVweDtcbiAgcGFkZGluZy1ib3R0b206IDVweDtcbiAgY29sb3I6ICM2MzYxNjI7XG59Il19 */"

/***/ }),

/***/ "./src/app/account-details/account-details.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/account-details/account-details.page.ts ***!
  \*********************************************************/
/*! exports provided: AccountDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountDetailsPage", function() { return AccountDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/user.service */ "./src/app/services/user.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");





var AccountDetailsPage = /** @class */ (function () {
    function AccountDetailsPage(translate, userService, navCtrl) {
        this.translate = translate;
        this.userService = userService;
        this.navCtrl = navCtrl;
        this.userServiceData = {};
        this.accountServiceData = {};
        this.acountDetails = {};
        this.userDetails = {};
        this.accountDetails = {};
        this.accountDetailboth = {};
        this.accountDetailman = {};
        this.accountDetailwoman = {};
        this.personalDetails = {};
        // this.getAccountDetails();
        this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
        //this.accountDetails = JSON.parse(localStorage.getItem("accountDetails"));          
    }
    AccountDetailsPage.prototype.ngOnInit = function () {
        this.getAccountDetails();
    };
    AccountDetailsPage.prototype.getAccountDetails = function () {
        var _this = this;
        if (this.userDetails) {
            this.userServiceData = { "user_id": this.userDetails.id, "role_id": this.userDetails.role_id, "token": this.userDetails.token.original.token };
        }
        this.userService.accountDetails(this.userServiceData).subscribe(function (res) {
            // console.log('reviewList' + res);
            if (res.status == "success") {
                _this.acountDetails = res.data.user[0];
                console.log(_this.acountDetails);
                if (_this.acountDetails.services_type == 'Both') {
                    _this.accountDetailboth = _this.acountDetails.services_type;
                    console.log('both', _this.accountDetailboth);
                }
                else if (_this.acountDetails.services_type == 'Man') {
                    _this.accountDetailman = _this.acountDetails.services_type;
                    console.log('man', _this.accountDetailman);
                }
                else if (_this.acountDetails.services_type == 'Woman') {
                    _this.accountDetailwoman = _this.acountDetails.services_type;
                    console.log('Woman', _this.accountDetailwoman);
                }
                // localStorage.setItem("accountDetails", JSON.stringify(res.data.user[0]));
                _this.userServiceData = {};
            }
            if (res.data.user == null) {
                alert('Token has been expired,first you have to login');
                _this.navCtrl.navigateForward('/signin');
            }
        });
    };
    AccountDetailsPage.prototype.savebtn = function () {
        var _this = this;
        if (this.userDetails && this.acountDetails) {
            this.accountServiceData = { "user_id": this.userDetails.id, "role_id": this.userDetails.role_id, "token": this.userDetails.token.original.token,
                "name": this.acountDetails.name, "email": this.acountDetails.email, "mobile": this.acountDetails.mobile,
                "dob": this.acountDetails.dob, "services_type": this.acountDetails.services_type };
            this.userService.personalDetails(this.accountServiceData).subscribe(function (res) {
                // console.log('reviewList' + res);
                if (res.status == "success") {
                    _this.personalDetails = res.data.user;
                    console.log(res.data.user);
                    _this.accountServiceData = {};
                    _this.navCtrl.navigateForward('/tabs/tab4');
                }
            });
        }
    };
    AccountDetailsPage.ctorParameters = function () { return [
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] },
        { type: _services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] }
    ]; };
    AccountDetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-account-details',
            template: __webpack_require__(/*! raw-loader!./account-details.page.html */ "./node_modules/raw-loader/index.js!./src/app/account-details/account-details.page.html"),
            styles: [__webpack_require__(/*! ./account-details.page.scss */ "./src/app/account-details/account-details.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"],
            _services_user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]])
    ], AccountDetailsPage);
    return AccountDetailsPage;
}());



/***/ })

}]);
//# sourceMappingURL=account-details-account-details-module.js.map