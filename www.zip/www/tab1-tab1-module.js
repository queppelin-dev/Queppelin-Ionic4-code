(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab1-tab1-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/tab1/tab1.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/tab1/tab1.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-label slot=\"start\"><span class=\"tit\">schedu</span><span class=\"tit clr\">lix</span><br/>\n    <span class=\"explore\">{{ 'tab1.explore' | translate }}</span></ion-label>\n    <ion-label class=\"notification\"  slot=\"end\"><img style=\"max-width:105%;padding:4px;\" slot=\"end\" src=\"assets/images/notification.svg\">\n     <ion-badge>2</ion-badge>\n    </ion-label>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"bg\" [ngClass]=\"{'bg1':themes == 'white' }\">\n   <div *ngIf=\"firstTimeLogin == 'yes'\" style=\"margin-top:10px;text-align:center;\">\n    <div class=\"welcome\">\n   <ion-label>Welcome back {{userDetails.name}}</ion-label>\n    </div>\n  </div> \n  <div *ngIf=\"aferappointment\">\n    <div style=\"margin-top:10px;margin-left:10px;margin-right:10px;\">\n        <ion-label class=\"fms clrw fs10\">{{'tab1.confirm' | translate }}</ion-label>\n        <div class=\"box blg\">\n          <ion-grid>\n          <ion-row>\n            <ion-col size=\"4\" style=\"text-align:center;\">\n            <ion-label class=\"fmc\"><span class=\"fs12\">{{appointmentlist[0].appointment_date}}</span><br><br><span class=\"fs12\">{{appointmentlist[0].appointment_time}}</span></ion-label>\n            </ion-col>\n            <ion-col size=\"1\" style=\"border-right:1px solid gray;\">\n            </ion-col>\n            <ion-col size=\"6\" style=\"text-align:left;\">\n                <ion-label class=\"fmc\"><span class=\"fs9 clrg\">{{ 'tab3.confirmed' | translate }}</span><br><span class=\"fs13\" *ngIf=\"appointmentlist.name\">{{appointmentlist[0].name}}</span><span class=\"fs13\" *ngIf=\"!appointmentlist.name\">Make By GLR</span><br><span class=\"fs9 clrgr\">{{appointmentlist[0].with_service[0]?.name}}</span></ion-label>\n              </ion-col>\n              <ion-col size=\"1\" class=\"col1\">\n                  <ion-icon name=\"ios-arrow-forward\"></ion-icon>\n                </ion-col>\n          </ion-row>\n        </ion-grid>\n          </div>\n        </div>\n  </div>\n  <div class=\"containsbox\" style=\"margin-top:10px;\">\n    <ion-slides>\n    <ion-slide *ngFor=\"let item of businessfavwithoutlist\" (click)=\"goToDetailsPage(item)\">\n    <div class=\"contents\">\n      <div class=\"cardcontent\">\n        <img class=\"card\" *ngIf=\"!item.image\" src=\"assets/images/Card products backgroud.svg\">\n        <img class=\"card\" *ngIf=\"item.image\" src=\"{{item.image}}\">\n        <div class=\"content\">\n          <ion-grid  style=\"padding: 0px;\">\n            <ion-row>\n              <ion-col size=\"2\">\n              <img class= \"image\" *ngIf=\"!item.business_logo\" src=\"assets/images/logo.svg\">\n              <img class= \"image\" *ngIf=\"item.business_logo\" src=\"{{item.business_logo}}\">\n              </ion-col>\n              <ion-col size=\"5.5\" style=\"padding-left: 0px; padding-right: 0px;\">\n                <div style=\"text-align:left;\">\n                  <ion-label class=\"fontMoteret clrw\">{{item.name}}</ion-label><br>\n                  <img src=\"assets/images/location1.svg\"><ion-label class=\"fontSans clrw fs8\">&nbsp;&nbsp;{{item?.distance}}, {{item.address}}</ion-label>\n                </div>\n              </ion-col>\n              <ion-col size=\"4.5\" style=\"padding-left: 0px; padding-right: 0px;\">\n              <div class=\"ratings\">\n                <div class=\"empty-stars\"></div>\n                <div class=\"full-stars\" [ngClass]=\"{'full-stars1':position}\" [ngStyle]=\"{'width':item.ratingPercent}\"></div>\n              </div>\n                <div>\n                <ion-label style=\"font-size:10px;color:white;\">{{item.review}} {{ 'tab1.review' | translate }}</ion-label>\n              </div> \n              </ion-col>\n            </ion-row>\n          </ion-grid>\n        </div>\n      </div>\n    </div>\n    </ion-slide>\n    </ion-slides>\n\n  </div>\n  <div class=\"contains\" style=\"margin-left:10px;margin-top: 25px;\">\n    <ion-slides>\n      <ion-slide *ngFor=\"let items of customData\"  (click)=\"gotoexplorepage(items)\">\n        <div class=\"box\" style=\"border-radius:8px;margin-right:5px !important;\" >\n          <ion-label><img src=\"{{items.image}}\"><br/>\n            <span class=\"fontSans clrw fs8\">{{ items.name}}</span>\n          </ion-label>\n        </div>\n      </ion-slide>\n    </ion-slides>\n  </div>\n  <div class=\"contains\" style=\"margin-left:10px;margin-top: 10px;\" >\n      <ion-slides>\n        <ion-slide *ngFor=\"let items of categorylistDatas\" (click)=\"gotoexplorepage(items)\">\n    <div class=\"box\" style=\"border-radius:8px;margin-right:5px !important;\">\n      <ion-label><img src=\"{{items.image}}\"><br/>\n    <span class=\"fontSans clrw fs8\">{{ items.name }}</span></ion-label>\n    </div>\n  \n   </ion-slide>\n    </ion-slides>\n  </div>\n <!--<div class=\"contains\" style=\"margin-left:10px;margin-top: 25px;\">\n      <ion-slides>\n        <ion-slide *ngFor=\"let item of categorylistDatas\">\n    <div class=\"box\" style=\"border-radius:8px;margin-right:5px !important;\">\n      <ion-label><img src=\"{{item.image}}\"><br/>\n    <span class=\"fontSans clrw fs8\">{{ item.name }}</span></ion-label>\n    </div>\n    <div class=\"box\" style=\"padding:8px;margin-left:10px !important;\">\n        <ion-label><img src=\"assets/images/Education.svg\"><br/>\n      <span class=\"fontSans clrw fs8\">{{ 'tab1.education' | translate }}</span></ion-label>\n      </div>\n    </ion-slide>\n    </ion-slides>\n  </div>-->\n    \n    <!---<div class=\"contains\" style=\"margin-left:10px;margin-top: 25px;\">\n      <ion-slides>\n        <ion-slide>\n    <div class=\"box\" style=\"border-radius:8px;margin-right:0px !important;\" (click)=\"Health()\">\n      <ion-label><img src=\"assets/images/Health & Wellness.svg\"><br/>\n    <span class=\"fontSans clrw fs8\">{{ 'tab1.health' | translate }}</span></ion-label>\n    </div>\n    <div class=\"box\" style=\"padding:8px;margin-left:10px !important;\" (click)=\"Education()\">\n        <ion-label><img src=\"assets/images/Education.svg\"><br/>\n      <span class=\"fontSans clrw fs8\">{{ 'tab1.education' | translate }}</span></ion-label>\n      </div>\n  </ion-slide>\n  <ion-slide>\n      <div class=\"box\" (click)=\"Medicine()\">\n        <ion-label><img src=\"assets/images/Medicine.svg\"><br/>\n      <span class=\"fontSans clrw fs8\">{{ 'tab1.medicine' | translate }}</span></ion-label>\n      </div>\n      <div class=\"box\" (click)=\"Fitness()\">\n          <ion-label><img src=\"assets/images/Fitness & Recreation.svg\"><br/>\n        <span class=\"fontSans clrw fs8\">{{ 'tab1.fitness' | translate }}</span></ion-label>\n        </div>\n    </ion-slide>\n    </ion-slides>\n    </div>\n    <div class=\"contains mt10\" style=\"margin-left:10px;\">\n        <ion-slides>\n          <ion-slide>\n      <div class=\"box\" style=\"margin-right:0px !important;\" (click)=\"Salon()\">\n        <ion-label><img src=\"assets/images/Salon & Beauty.svg\"><br/>\n      <span class=\"fontSans clrw fs8\">{{ 'tab1.salon' | translate }}</span></ion-label>\n      </div>\n      <div class=\"box\" style=\"margin-left:10px !important;\" (click)=\"Professional()\">\n          <ion-label><img src=\"assets/images/Salon & Beauty (1).svg\"><br/>\n        <span class=\"fontSans clrw fs8\">{{ 'tab1.professional' | translate }}</span></ion-label>\n        </div>\n    </ion-slide>\n    <ion-slide>\n        <div class=\"box\" (click)=\"Goverment()\">\n          <ion-label><img src=\"assets/images/Government Services.svg\"><br/>\n        <span class=\"fontSans clrw fs8\">{{ 'tab1.goverment' | translate }} </span></ion-label>\n        </div>\n        <div class=\"box\" (click)=\"Other()\">\n            <ion-label><img src=\"assets/images/Other Services.svg\"><br/>\n          <span class=\"fontSans clrw fs8\">{{ 'tab1.other' | translate }}</span></ion-label>\n          </div>\n      </ion-slide>\n      </ion-slides>\n      </div>-->\n      <div class=\"ml15 mr15 mt10\">\n        <ion-label class=\"fontMoteret clrwb fs16\">{{ 'tab1.myfav' | translate }}&nbsp;<span class=\"clr\">{{ 'tab1.appointment' | translate }}</span></ion-label><br/>\n        <ion-label class=\"fontSans clrwb fs9\">{{ 'tab1.nofav' | translate }}</ion-label>\n      </div>\n      <div class=\"contents\" *ngFor=\"let item of businessfavwithlist\" (click)=\"goToDetailsPage(item)\">\n        <div class=\"cardcontent\">\n          <img class=\"card\" *ngIf=\"!item.image\" src=\"assets/images/Card products backgroud.svg\">\n          <img class=\"card\" *ngIf=\"item.image\" src=\"{{item.image}}\">\n          <div class=\"content\">\n            <ion-grid  style=\"padding: 0px;\">\n              <ion-row>\n                <ion-col size=\"2\">\n                <img class= \"image\" *ngIf=\"!item.business_logo\" src=\"assets/images/logo.svg\">\n                <img class= \"image\" *ngIf=\"item.business_logo\" src=\"{{item.business_logo}}\">\n                </ion-col>\n                <ion-col size=\"6\" style=\"padding-left: 0px; padding-right: 0px;\">\n                  <div style=\"text-align:left;\">\n                    <ion-label class=\"fontMoteret clrw\">{{item.name}}</ion-label><br>\n                    <img src=\"assets/images/location1.svg\"><ion-label class=\"fontSans clrw fs8\">&nbsp;&nbsp;{{item?.distance}}, {{item.address}}</ion-label>\n                  </div>\n                </ion-col>\n                <ion-col size=\"4\" style=\"padding-left: 0px; padding-right: 0px;\">\n             \n                 <div class=\"ratings\">\n                  <div class=\"empty-stars\"></div>\n                  <div class=\"full-stars\" [ngClass]=\"{'full-stars1':position}\" [ngStyle]=\"{'width':item.ratingPercent}\"></div>\n                </div>\n                  <div>\n                  <ion-label style=\"font-size:10px;color:white;\">{{item.review}} {{ 'tab1.review' | translate }}</ion-label>\n                </div> \n                </ion-col>\n              </ion-row>\n            </ion-grid>\n          </div>\n        </div>\n      </div>\n       \n</ion-content>"

/***/ }),

/***/ "./src/app/tab1/tab1.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/*! exports provided: Tab1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1PageModule", function() { return Tab1PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab1.page */ "./src/app/tab1/tab1.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var ionic4_rating__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ionic4-rating */ "./node_modules/ionic4-rating/dist/index.js");









//import { StarRating } from 'ionic4-star-rating';
var Tab1PageModule = /** @class */ (function () {
    function Tab1PageModule() {
    }
    Tab1PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
                ionic4_rating__WEBPACK_IMPORTED_MODULE_8__["IonicRatingModule"],
                _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab1_page__WEBPACK_IMPORTED_MODULE_6__["Tab1Page"] }])
            ],
            declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_6__["Tab1Page"]]
        })
    ], Tab1PageModule);
    return Tab1PageModule;
}());



/***/ }),

/***/ "./src/app/tab1/tab1.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.clr {\n  color: #ED145B;\n}\nion-toolbar {\n  --background:#2A2A2A;\n  padding: 5px;\n}\n/* .notification{\n   width:18px;\n   margin-right:5px;\n }*/\n.contents {\n  margin: 10px;\n}\n.bg {\n  --background:#000000;\n}\n.clrwb {\n  color: white;\n}\n.bg1 {\n  --background:white;\n}\n.bg1 .clrwb {\n  color: black;\n}\n.content {\n  background: rgba(42, 42, 42, 0.6);\n  width: 100%;\n  position: absolute;\n  bottom: 26px;\n}\nion-slides {\n  --bullet-background:none;\n  --bullet-background-active:none;\n}\n.explore {\n  font-family: \"Source Sans Pro\", sans-serif !important;\n  font-size: 11pt;\n  color: white;\n}\n.tit {\n  font-size: 15pt;\n  font-family: \"Montserrat\", sans-serif !important;\n  color: white;\n  font-weight: bold;\n}\n.notification {\n  margin-right: 5px;\n  border: 1px solid white;\n  border-radius: 50%;\n  height: 30px;\n  width: 30px;\n  text-align: center;\n  position: relative;\n}\nion-badge {\n  --background: #ED145B;\n  --padding: 3px;\n  --padding-start: 3px;\n  --padding-end: 2px;\n  --padding-top: 1px;\n  --padding-bottom: 1px;\n  position: absolute;\n  top: 7px;\n  right: 13px;\n  border-radius: 50%;\n}\n.box {\n  background: #2A2A2A;\n  height: 100px;\n  width: 100%;\n  text-align: center;\n  padding: 5px;\n  border-radius: 8px;\n  margin-right: 10px;\n}\n.fontSans {\n  font-family: \"Source Sans Pro\", sans-serif !important;\n}\n.fs8 {\n  font-size: 8pt;\n}\n.fontMoteret {\n  font-family: \"Montserrat\", sans-serif !important;\n}\n.clrw {\n  color: white;\n}\n.ml15 {\n  margin-left: 15px;\n}\n.clr {\n  color: #ED145B;\n}\n.fs16 {\n  font-size: 13pt;\n}\n.fs9 {\n  font-size: 9pt;\n}\n.favcontent {\n  background: rgba(42, 42, 42, 0.6);\n  height: 50px;\n  width: 100%;\n  position: absolute;\n  bottom: 10px;\n}\n.fs8 {\n  font-size: 8pt;\n}\n.card {\n  display: block;\n  width: 100%;\n  border-radius: 10px;\n}\n.cardcontent {\n  position: relative;\n  margin-top: 20px;\n  text-align: center;\n}\n.contains .swiper-slide {\n  width: 45% !important;\n}\n.contains .swiper-slide:last-child {\n  width: 45% !important;\n}\n.containsbox .swiper-slide {\n  width: 90% !important;\n}\n.containsbox .swiper-slide:last-child {\n  width: 90% !important;\n}\nion-slide.md.swiper-slide.swiper-zoom-container.hydrated.swiper-slide-active {\n  margin-right: 3px;\n}\n/*.fs10{\n  font-size:10pt;\n}*/\n.mr15 {\n  margin-right: 15px;\n}\n.mt10 {\n  margin-top: 10px;\n}\n.image {\n  border-radius: 50%;\n  width: 38px;\n}\n/* new star rating */\n.ratings {\n  position: relative;\n  vertical-align: middle;\n  display: inline-block;\n  color: #b1b1b1;\n  overflow: hidden;\n}\n.full-stars {\n  position: absolute;\n  left: 0;\n  top: 0;\n  white-space: nowrap;\n  overflow: hidden;\n  color: #fde16d;\n}\n.empty-stars:before, .full-stars:before {\n  content: \"★★★★★\";\n  font-size: 14pt;\n}\n.empty-stars:before {\n  -webkit-text-stroke: 1px #848484;\n}\n.full-stars:before {\n  -webkit-text-stroke: 1px orange;\n}\n/* Webkit-text-stroke is not supported on firefox or IE */\n/* Firefox */\n@-moz-document url-prefix() {\n  .full-stars {\n    color: #ECBE24;\n  }\n}\n.full-stars1 {\n  position: absolute;\n  right: 0;\n  top: 0;\n  white-space: nowrap;\n  overflow: hidden;\n  color: #fde16d;\n}\n.md .swiper-slide .swiper-slide-active,\n.ios .swiper-slide .swiper-slide-active,\n.wp .swiper-slide .swiper-slide-active {\n  width: 100px;\n}\n.welcome {\n  background-color: #BA2B59;\n  border: none;\n  color: white;\n  padding: 20px;\n  text-align: center;\n  text-decoration: none;\n  display: inline-block;\n  font-size: 16px;\n  margin: 4px 2px;\n  cursor: pointer;\n  border-radius: 27px;\n  width: 90%;\n}\n/* tab3 css */\n.fmc {\n  color: white;\n  font-family: \"Cairo\", sans-serif;\n}\n.box {\n  border-radius: 8px;\n  background-color: #2A2A2A;\n  color: white;\n  margin-top: 15px;\n}\n.blr {\n  border-left: 5px solid #ED145B;\n}\n.blg {\n  border-left: 5px solid #16A085;\n}\n.fs12 {\n  font-size: 12pt;\n}\n.fs23 {\n  font-size: 23pt;\n}\n.fs13 {\n  font-size: 13pt;\n}\n.fs9 {\n  font-size: 9pt;\n}\n.clrw {\n  color: white;\n}\n.clrg {\n  color: #16A085;\n}\n.clrgr {\n  color: #999999;\n}\n.col1 {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n  align-items: center;\n}\n.fs10 {\n  font-size: 10pt;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiMS90YWIxLnBhZ2Uuc2NzcyIsIi9ob21lL2RpbGVlcC9wcm9qZWN0cy9pb25pYy9zY2hlZHVsaXgtbW9iaWxlLWFwcC9zcmMvYXBwL3RhYjEvdGFiMS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FDRWQ7RUFDRSxjQUFBO0FEQUo7QUNFRTtFQUNFLG9CQUFBO0VBQ0EsWUFBQTtBRENKO0FDQ0M7OztHQUFBO0FBSUM7RUFDRSxZQUFBO0FERUo7QUNBRTtFQUNFLG9CQUFBO0FER0o7QUNBRTtFQUNFLFlBQUE7QURHSjtBQ0RFO0VBQ0Usa0JBQUE7QURJSjtBQ0hJO0VBQ0UsWUFBQTtBREtOO0FDRkU7RUFDRSxpQ0FBQTtFQUVBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7QURJSjtBQ0RBO0VBQ0Usd0JBQUE7RUFDQSwrQkFBQTtBRElGO0FDRkE7RUFDRSxxREFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FES0Y7QUNIQTtFQUNFLGVBQUE7RUFDQSxnREFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBRE1GO0FDSkE7RUFDRSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QURPRjtBQ0xBO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QURRRjtBQ05BO0VBQ0UsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsV0FBQTtFQUVBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QURRRjtBQ05BO0VBQ0UscURBQUE7QURTRjtBQ1BBO0VBQ0UsY0FBQTtBRFVGO0FDUkE7RUFDRSxnREFBQTtBRFdGO0FDVEE7RUFDRSxZQUFBO0FEWUY7QUNWQTtFQUNFLGlCQUFBO0FEYUY7QUNYQTtFQUNFLGNBQUE7QURjRjtBQ1pBO0VBQ0UsZUFBQTtBRGVGO0FDYkE7RUFDRSxjQUFBO0FEZ0JGO0FDZEE7RUFDRSxpQ0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FEaUJGO0FDZkE7RUFDRSxjQUFBO0FEa0JGO0FDaEJBO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFFQSxtQkFBQTtBRGtCRjtBQ2hCQTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBRG1CRjtBQ2RBO0VBQ0UscUJBQUE7QURpQkY7QUNoQkM7RUFDRSxxQkFBQTtBRGtCSDtBQ2JFO0VBQ0UscUJBQUE7QURnQko7QUNmSTtFQUNFLHFCQUFBO0FEaUJOO0FDYkE7RUFDRSxpQkFBQTtBRGdCRjtBQ2RBOztFQUFBO0FBR0E7RUFDRSxrQkFBQTtBRGlCRjtBQ2ZBO0VBQ0UsZ0JBQUE7QURrQkY7QUNmQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtBRGtCRjtBQ2RBLG9CQUFBO0FBQ0E7RUFDRSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EscUJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QURpQkY7QUNmQTtFQUNFLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLE1BQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBRGtCRjtBQ2hCQTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtBRG1CRjtBQ2pCQTtFQUNFLGdDQUFBO0FEb0JGO0FDbEJBO0VBQ0UsK0JBQUE7QURxQkY7QUNuQkEseURBQUE7QUFFQSxZQUFBO0FBQ0E7RUFDRTtJQUNJLGNBQUE7RURxQko7QUFDRjtBQ25CQTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBRHFCRjtBQ2hCSTs7O0VBQ0csWUFBQTtBRHFCUDtBQ2xCQztFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxVQUFBO0FEcUJEO0FDbEJBLGFBQUE7QUFDQTtFQUNFLFlBQUE7RUFDQSxnQ0FBQTtBRHFCRjtBQ25CQTtFQUNFLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QURzQkY7QUNwQkE7RUFDRSw4QkFBQTtBRHVCRjtBQ3JCQTtFQUNFLDhCQUFBO0FEd0JGO0FDdEJBO0VBQ0UsZUFBQTtBRHlCRjtBQ3ZCQTtFQUNFLGVBQUE7QUQwQkY7QUN4QkE7RUFDRSxlQUFBO0FEMkJGO0FDekJBO0VBQ0UsY0FBQTtBRDRCRjtBQzFCQTtFQUNFLFlBQUE7QUQ2QkY7QUMzQkE7RUFDRSxjQUFBO0FEOEJGO0FDNUJBO0VBQ0UsY0FBQTtBRCtCRjtBQzdCQTtFQUNFLG9CQUFBO0VBQUEsYUFBQTtFQUdBLHlCQUFBO0VBQ0EsbUJBQUE7QURnQ0Y7QUM5QkE7RUFDRSxlQUFBO0FEaUNGIiwiZmlsZSI6InNyYy9hcHAvdGFiMS90YWIxLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBjaGFyc2V0IFwiVVRGLThcIjtcbi5jbHIge1xuICBjb2xvcjogI0VEMTQ1Qjtcbn1cblxuaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6IzJBMkEyQTtcbiAgcGFkZGluZzogNXB4O1xufVxuXG4vKiAubm90aWZpY2F0aW9ue1xuICAgd2lkdGg6MThweDtcbiAgIG1hcmdpbi1yaWdodDo1cHg7XG4gfSovXG4uY29udGVudHMge1xuICBtYXJnaW46IDEwcHg7XG59XG5cbi5iZyB7XG4gIC0tYmFja2dyb3VuZDojMDAwMDAwO1xufVxuXG4uY2xyd2Ige1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5iZzEge1xuICAtLWJhY2tncm91bmQ6d2hpdGU7XG59XG4uYmcxIC5jbHJ3YiB7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuLmNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDQyLCA0MiwgNDIsIDAuNik7XG4gIHdpZHRoOiAxMDAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMjZweDtcbn1cblxuaW9uLXNsaWRlcyB7XG4gIC0tYnVsbGV0LWJhY2tncm91bmQ6bm9uZTtcbiAgLS1idWxsZXQtYmFja2dyb3VuZC1hY3RpdmU6bm9uZTtcbn1cblxuLmV4cGxvcmUge1xuICBmb250LWZhbWlseTogXCJTb3VyY2UgU2FucyBQcm9cIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDExcHQ7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLnRpdCB7XG4gIGZvbnQtc2l6ZTogMTVwdDtcbiAgZm9udC1mYW1pbHk6IFwiTW9udHNlcnJhdFwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5ub3RpZmljYXRpb24ge1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgYm9yZGVyOiAxcHggc29saWQgd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgaGVpZ2h0OiAzMHB4O1xuICB3aWR0aDogMzBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbmlvbi1iYWRnZSB7XG4gIC0tYmFja2dyb3VuZDogI0VEMTQ1QjtcbiAgLS1wYWRkaW5nOiAzcHg7XG4gIC0tcGFkZGluZy1zdGFydDogM3B4O1xuICAtLXBhZGRpbmctZW5kOiAycHg7XG4gIC0tcGFkZGluZy10b3A6IDFweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMXB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogN3B4O1xuICByaWdodDogMTNweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuXG4uYm94IHtcbiAgYmFja2dyb3VuZDogIzJBMkEyQTtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZzogNXB4O1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cblxuLmZvbnRTYW5zIHtcbiAgZm9udC1mYW1pbHk6IFwiU291cmNlIFNhbnMgUHJvXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cblxuLmZzOCB7XG4gIGZvbnQtc2l6ZTogOHB0O1xufVxuXG4uZm9udE1vdGVyZXQge1xuICBmb250LWZhbWlseTogXCJNb250c2VycmF0XCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cblxuLmNscncge1xuICBjb2xvcjogd2hpdGU7XG59XG5cbi5tbDE1IHtcbiAgbWFyZ2luLWxlZnQ6IDE1cHg7XG59XG5cbi5jbHIge1xuICBjb2xvcjogI0VEMTQ1Qjtcbn1cblxuLmZzMTYge1xuICBmb250LXNpemU6IDEzcHQ7XG59XG5cbi5mczkge1xuICBmb250LXNpemU6IDlwdDtcbn1cblxuLmZhdmNvbnRlbnQge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDQyLCA0MiwgNDIsIDAuNik7XG4gIGhlaWdodDogNTBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAxMHB4O1xufVxuXG4uZnM4IHtcbiAgZm9udC1zaXplOiA4cHQ7XG59XG5cbi5jYXJkIHtcbiAgZGlzcGxheTogYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuXG4uY2FyZGNvbnRlbnQge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLmNvbnRhaW5zIC5zd2lwZXItc2xpZGUge1xuICB3aWR0aDogNDUlICFpbXBvcnRhbnQ7XG59XG4uY29udGFpbnMgLnN3aXBlci1zbGlkZTpsYXN0LWNoaWxkIHtcbiAgd2lkdGg6IDQ1JSAhaW1wb3J0YW50O1xufVxuXG4uY29udGFpbnNib3ggLnN3aXBlci1zbGlkZSB7XG4gIHdpZHRoOiA5MCUgIWltcG9ydGFudDtcbn1cbi5jb250YWluc2JveCAuc3dpcGVyLXNsaWRlOmxhc3QtY2hpbGQge1xuICB3aWR0aDogOTAlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1zbGlkZS5tZC5zd2lwZXItc2xpZGUuc3dpcGVyLXpvb20tY29udGFpbmVyLmh5ZHJhdGVkLnN3aXBlci1zbGlkZS1hY3RpdmUge1xuICBtYXJnaW4tcmlnaHQ6IDNweDtcbn1cblxuLyouZnMxMHtcbiAgZm9udC1zaXplOjEwcHQ7XG59Ki9cbi5tcjE1IHtcbiAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xufVxuXG4ubXQxMCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5pbWFnZSB7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgd2lkdGg6IDM4cHg7XG59XG5cbi8qIG5ldyBzdGFyIHJhdGluZyAqL1xuLnJhdGluZ3Mge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgY29sb3I6ICNiMWIxYjE7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi5mdWxsLXN0YXJzIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICB0b3A6IDA7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGNvbG9yOiAjZmRlMTZkO1xufVxuXG4uZW1wdHktc3RhcnM6YmVmb3JlLCAuZnVsbC1zdGFyczpiZWZvcmUge1xuICBjb250ZW50OiBcIuKYheKYheKYheKYheKYhVwiO1xuICBmb250LXNpemU6IDE0cHQ7XG59XG5cbi5lbXB0eS1zdGFyczpiZWZvcmUge1xuICAtd2Via2l0LXRleHQtc3Ryb2tlOiAxcHggIzg0ODQ4NDtcbn1cblxuLmZ1bGwtc3RhcnM6YmVmb3JlIHtcbiAgLXdlYmtpdC10ZXh0LXN0cm9rZTogMXB4IG9yYW5nZTtcbn1cblxuLyogV2Via2l0LXRleHQtc3Ryb2tlIGlzIG5vdCBzdXBwb3J0ZWQgb24gZmlyZWZveCBvciBJRSAqL1xuLyogRmlyZWZveCAqL1xuQC1tb3otZG9jdW1lbnQgdXJsLXByZWZpeCgpIHtcbiAgLmZ1bGwtc3RhcnMge1xuICAgIGNvbG9yOiAjRUNCRTI0O1xuICB9XG59XG4uZnVsbC1zdGFyczEge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAwO1xuICB0b3A6IDA7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGNvbG9yOiAjZmRlMTZkO1xufVxuXG4ubWQgLnN3aXBlci1zbGlkZSAuc3dpcGVyLXNsaWRlLWFjdGl2ZSxcbi5pb3MgLnN3aXBlci1zbGlkZSAuc3dpcGVyLXNsaWRlLWFjdGl2ZSxcbi53cCAuc3dpcGVyLXNsaWRlIC5zd2lwZXItc2xpZGUtYWN0aXZlIHtcbiAgd2lkdGg6IDEwMHB4O1xufVxuXG4ud2VsY29tZSB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNCQTJCNTk7XG4gIGJvcmRlcjogbm9uZTtcbiAgY29sb3I6IHdoaXRlO1xuICBwYWRkaW5nOiAyMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbjogNHB4IDJweDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBib3JkZXItcmFkaXVzOiAyN3B4O1xuICB3aWR0aDogOTAlO1xufVxuXG4vKiB0YWIzIGNzcyAqL1xuLmZtYyB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZm9udC1mYW1pbHk6IFwiQ2Fpcm9cIiwgc2Fucy1zZXJpZjtcbn1cblxuLmJveCB7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzJBMkEyQTtcbiAgY29sb3I6IHdoaXRlO1xuICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuXG4uYmxyIHtcbiAgYm9yZGVyLWxlZnQ6IDVweCBzb2xpZCAjRUQxNDVCO1xufVxuXG4uYmxnIHtcbiAgYm9yZGVyLWxlZnQ6IDVweCBzb2xpZCAjMTZBMDg1O1xufVxuXG4uZnMxMiB7XG4gIGZvbnQtc2l6ZTogMTJwdDtcbn1cblxuLmZzMjMge1xuICBmb250LXNpemU6IDIzcHQ7XG59XG5cbi5mczEzIHtcbiAgZm9udC1zaXplOiAxM3B0O1xufVxuXG4uZnM5IHtcbiAgZm9udC1zaXplOiA5cHQ7XG59XG5cbi5jbHJ3IHtcbiAgY29sb3I6IHdoaXRlO1xufVxuXG4uY2xyZyB7XG4gIGNvbG9yOiAjMTZBMDg1O1xufVxuXG4uY2xyZ3Ige1xuICBjb2xvcjogIzk5OTk5OTtcbn1cblxuLmNvbDEge1xuICBkaXNwbGF5OiBmbGV4O1xuICAtbXMtZmxleC1hbGlnbjogY2VudGVyO1xuICAtd2Via2l0LWFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIC13ZWJraXQtYm94LWFsaWduOiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5cbi5mczEwIHtcbiAgZm9udC1zaXplOiAxMHB0O1xufSIsIlxuICBcbiAgLmNscntcbiAgICBjb2xvcjojRUQxNDVCO1xuICB9XG4gIGlvbi10b29sYmFye1xuICAgIC0tYmFja2dyb3VuZDojMkEyQTJBO1xuICAgIHBhZGRpbmc6NXB4O1xuICB9XG4gLyogLm5vdGlmaWNhdGlvbntcbiAgICB3aWR0aDoxOHB4O1xuICAgIG1hcmdpbi1yaWdodDo1cHg7XG4gIH0qL1xuICAuY29udGVudHN7XG4gICAgbWFyZ2luOjEwcHg7XG4gIH1cbiAgLmJne1xuICAgIC0tYmFja2dyb3VuZDojMDAwMDAwO1xuXG4gIH1cbiAgLmNscndie1xuICAgIGNvbG9yOndoaXRlO1xuICB9XG4gIC5iZzF7XG4gICAgLS1iYWNrZ3JvdW5kOndoaXRlO1xuICAgIC5jbHJ3YntcbiAgICAgIGNvbG9yOmJsYWNrO1xuICAgIH1cbiAgfVxuICAuY29udGVudHtcbiAgICBiYWNrZ3JvdW5kOiByZ2JhKDQyLDQyLDQyLDAuNik7XG4gICAvLyBoZWlnaHQ6IDQ4cHg7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIGJvdHRvbTogMjZweDtcbiAgfVxuXG5pb24tc2xpZGVze1xuICAtLWJ1bGxldC1iYWNrZ3JvdW5kIDpub25lO1xuICAtLWJ1bGxldC1iYWNrZ3JvdW5kLWFjdGl2ZTpub25lO1xufVxuLmV4cGxvcmV7XG4gIGZvbnQtZmFtaWx5OidTb3VyY2UgU2FucyBQcm8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZToxMXB0O1xuICBjb2xvcjp3aGl0ZTtcbn1cbi50aXR7XG4gIGZvbnQtc2l6ZToxNXB0O1xuICBmb250LWZhbWlseTogJ01vbnRzZXJyYXQnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG4gIGNvbG9yOndoaXRlO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgfVxuLm5vdGlmaWNhdGlvbiB7XG4gIG1hcmdpbi1yaWdodDogNXB4O1xuICBib3JkZXI6IDFweCBzb2xpZCB3aGl0ZTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBoZWlnaHQ6IDMwcHg7XG4gIHdpZHRoOiAzMHB4O1xuICB0ZXh0LWFsaWduOmNlbnRlcjtcbiAgcG9zaXRpb246cmVsYXRpdmU7XG59XG5pb24tYmFkZ2V7XG4gIC0tYmFja2dyb3VuZDogI0VEMTQ1QjtcbiAgLS1wYWRkaW5nOiAzcHg7XG4gIC0tcGFkZGluZy1zdGFydDogM3B4O1xuICAtLXBhZGRpbmctZW5kOiAycHg7XG4gIC0tcGFkZGluZy10b3A6IDFweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogMXB4O1xuICBwb3NpdGlvbjphYnNvbHV0ZTtcbiAgdG9wOiA3cHg7XG4gIHJpZ2h0OiAxM3B4O1xuICBib3JkZXItcmFkaXVzOjUwJTtcbn1cbi5ib3h7XG4gIGJhY2tncm91bmQ6ICMyQTJBMkE7XG4gIGhlaWdodDogMTAwcHg7XG4gIHdpZHRoOiAxMDAlO1xuIC8vIHdpZHRoOjUwJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA1cHg7XG4gIGJvcmRlci1yYWRpdXM6OHB4O1xuICBtYXJnaW4tcmlnaHQ6MTBweDtcbn1cbi5mb250U2Fuc3tcbiAgZm9udC1mYW1pbHk6J1NvdXJjZSBTYW5zIFBybycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cbi5mczh7XG4gIGZvbnQtc2l6ZTo4cHQ7XG59XG4uZm9udE1vdGVyZXR7XG4gIGZvbnQtZmFtaWx5OiAnTW9udHNlcnJhdCcsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cbi5jbHJ3e1xuICBjb2xvcjp3aGl0ZTtcbn1cbi5tbDE1e1xuICBtYXJnaW4tbGVmdDoxNXB4O1xufVxuLmNscntcbiAgY29sb3I6I0VEMTQ1Qjtcbn1cbi5mczE2e1xuICBmb250LXNpemU6MTNwdDtcbn1cbi5mczl7XG4gIGZvbnQtc2l6ZTo5cHQ7XG59XG4uZmF2Y29udGVudHtcbiAgYmFja2dyb3VuZDogcmdiYSg0Miw0Miw0MiwwLjYpO1xuICBoZWlnaHQ6IDUwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMTBweDtcbn1cbi5mczh7XG4gIGZvbnQtc2l6ZTo4cHQ7XG59XG4uY2FyZHtcbiAgZGlzcGxheTpibG9jaztcbiAgd2lkdGg6MTAwJTtcbiAvLyBoZWlnaHQ6IDE4MHB4ICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG4uY2FyZGNvbnRlbnR7XG4gIHBvc2l0aW9uOnJlbGF0aXZlO1xuICBtYXJnaW4tdG9wOjIwcHg7XG4gIHRleHQtYWxpZ246Y2VudGVyO1xuIC8vIG1hcmdpbi1sZWZ0OjNweDtcbiAvLyBtYXJnaW4tcmlnaHQ6M3B4O1xufVxuLmNvbnRhaW5ze1xuLnN3aXBlci1zbGlkZSB7XG4gIHdpZHRoOiA0NSUgIWltcG9ydGFudDtcblx0JjpsYXN0LWNoaWxkIHtcblx0ICB3aWR0aDogNDUlICFpbXBvcnRhbnQ7XG5cdH1cbn1cbn1cbi5jb250YWluc2JveHtcbiAgLnN3aXBlci1zbGlkZSB7XG4gICAgd2lkdGg6IDkwJSAhaW1wb3J0YW50O1xuICAgICY6bGFzdC1jaGlsZCB7XG4gICAgICB3aWR0aDogOTAlICFpbXBvcnRhbnQ7XG4gICAgfVxuICB9XG4gIH1cbmlvbi1zbGlkZS5tZC5zd2lwZXItc2xpZGUuc3dpcGVyLXpvb20tY29udGFpbmVyLmh5ZHJhdGVkLnN3aXBlci1zbGlkZS1hY3RpdmUge1xuICBtYXJnaW4tcmlnaHQ6IDNweDtcbn1cbi8qLmZzMTB7XG4gIGZvbnQtc2l6ZToxMHB0O1xufSovXG4ubXIxNXtcbiAgbWFyZ2luLXJpZ2h0OjE1cHg7XG59XG4ubXQxMHtcbiAgbWFyZ2luLXRvcDoxMHB4O1xufVxuXG4uaW1hZ2Uge1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIHdpZHRoOiAzOHB4O1xufVxuXG5cbi8qIG5ldyBzdGFyIHJhdGluZyAqL1xuLnJhdGluZ3Mge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgY29sb3I6ICNiMWIxYjE7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4uZnVsbC1zdGFycyB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMDtcbiAgdG9wOiAwO1xuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBjb2xvcjogI2ZkZTE2ZDtcbn1cbi5lbXB0eS1zdGFyczpiZWZvcmUsIC5mdWxsLXN0YXJzOmJlZm9yZSB7XG4gIGNvbnRlbnQ6XCJcXDI2MDVcXDI2MDVcXDI2MDVcXDI2MDVcXDI2MDVcIjtcbiAgZm9udC1zaXplOiAxNHB0O1xufVxuLmVtcHR5LXN0YXJzOmJlZm9yZSB7XG4gIC13ZWJraXQtdGV4dC1zdHJva2U6IDFweCAjODQ4NDg0O1xufVxuLmZ1bGwtc3RhcnM6YmVmb3JlIHtcbiAgLXdlYmtpdC10ZXh0LXN0cm9rZTogMXB4IG9yYW5nZTtcbn1cbi8qIFdlYmtpdC10ZXh0LXN0cm9rZSBpcyBub3Qgc3VwcG9ydGVkIG9uIGZpcmVmb3ggb3IgSUUgKi9cblxuLyogRmlyZWZveCAqL1xuQC1tb3otZG9jdW1lbnQgdXJsLXByZWZpeCgpIHtcbiAgLmZ1bGwtc3RhcnMge1xuICAgICAgY29sb3I6ICNFQ0JFMjQ7XG4gIH1cbn1cbi5mdWxsLXN0YXJzMXtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDowO1xuICB0b3A6IDA7XG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XG4gIG92ZXJmbG93OiBoaWRkZW47XG4gIGNvbG9yOiAjZmRlMTZkO1xufVxuLm1kLFxuLmlvcyxcbi53cCB7XG4gICAgLnN3aXBlci1zbGlkZSAuc3dpcGVyLXNsaWRlLWFjdGl2ZXtcbiAgICAgICB3aWR0aDogMTAwcHg7Ly95b3VyIHdpZHRoIGhlcmVcbiAgIH1cbiB9XG4gLndlbGNvbWV7XG4gYmFja2dyb3VuZC1jb2xvcjogI0JBMkI1OTtcbiBib3JkZXI6IG5vbmU7XG4gY29sb3I6IHdoaXRlO1xuIHBhZGRpbmc6IDIwcHg7XG4gdGV4dC1hbGlnbjogY2VudGVyO1xuIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gZm9udC1zaXplOiAxNnB4O1xuIG1hcmdpbjogNHB4IDJweDtcbiBjdXJzb3I6IHBvaW50ZXI7XG4gYm9yZGVyLXJhZGl1czogMjdweDtcbiB3aWR0aDogOTAlO1xufVxuXG4vKiB0YWIzIGNzcyAqL1xuLmZtY3tcbiAgY29sb3I6IHdoaXRlO1xuICBmb250LWZhbWlseTogJ0NhaXJvJywgc2Fucy1zZXJpZjtcbn1cbi5ib3h7XG4gIGJvcmRlci1yYWRpdXM6OHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMkEyQTJBO1xuICBjb2xvcjp3aGl0ZTtcbiAgbWFyZ2luLXRvcDoxNXB4O1xufVxuLmJscntcbiAgYm9yZGVyLWxlZnQ6NXB4IHNvbGlkICNFRDE0NUI7XG59XG4uYmxne1xuICBib3JkZXItbGVmdDo1cHggc29saWQgIzE2QTA4NTtcbn1cbi5mczEye1xuICBmb250LXNpemU6MTJwdDtcbn1cbi5mczIze1xuICBmb250LXNpemU6MjNwdDtcbn1cbi5mczEze1xuICBmb250LXNpemU6MTNwdDtcbn1cbi5mczl7XG4gIGZvbnQtc2l6ZTo5cHQ7XG59XG4uY2xyd3tcbiAgY29sb3I6d2hpdGU7XG59XG4uY2xyZ3tcbiAgY29sb3I6IzE2QTA4NTtcbn1cbi5jbHJncntcbiAgY29sb3I6Izk5OTk5OTtcbn1cbi5jb2wxe1xuICBkaXNwbGF5OiBmbGV4O1xuICAtbXMtZmxleC1hbGlnbjogY2VudGVyO1xuICAtd2Via2l0LWFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIC13ZWJraXQtYm94LWFsaWduOiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7ICAgICAgXG59XG4uZnMxMHtcbiAgZm9udC1zaXplOjEwcHQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/tab1/tab1.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/*! exports provided: Tab1Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1Page", function() { return Tab1Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/@ngx-translate/core.es5.js");
/* harmony import */ var _services_business_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/business.service */ "./src/app/services/business.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/fesm5/ionic-storage.js");





//import { Events } from 'ionic-angular';



var Tab1Page = /** @class */ (function () {
    // public Math.round(parseFloat(rating)="3.2";
    function Tab1Page(platform, translate, popoverCtrl, alertCtrl, businessService, navCtrl, router, storage) {
        this.platform = platform;
        this.translate = translate;
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.businessService = businessService;
        this.navCtrl = navCtrl;
        this.router = router;
        this.storage = storage;
        this.favwithlist = false;
        this.favwithoutlist = true;
        this.themes = 'black';
        //public businessData:Business;
        this.businessData = [];
        this.customData = [];
        this.customDatas = [];
        this.categorylistData = [];
        this.categorylistDatas = [];
        this.businessDatas = [];
        this.position = false;
        this.categoryData = {};
        this.businessCategoryServiceData = {};
        this.businessDetails = {};
        this.categorybusinessDetails = {};
        this.userDetails = {};
        this.businessfavData = {};
        this.categorylist = {};
        this.categories = [];
        this.afterlogin = false;
        this.appointmentlist = {};
        this.aferappointment = false;
        this.language = localStorage.getItem("language");
        this.themes = localStorage.getItem("themes");
        //this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
        // console.log('details', this.userDetails);
        this.currentlocation = JSON.parse(localStorage.getItem("latLong"));
        if (this.language == 'ar') {
            document.documentElement.dir = 'rtl';
            this.position = true;
        }
        //  this.getBusinessList();
        this.getCategoryService();
        this.getcategorylist();
        this.getfavlistwithoutcustomer();
    }
    Tab1Page.prototype.ionViewDidLoad = function () {
    };
    Tab1Page.prototype.ngOnInit = function () {
        this.appointmentlist = JSON.parse(localStorage.getItem("appointmentlist"));
        if (this.appointmentlist) {
            this.aferappointment = true;
            this.afterlogin = false;
        }
        //  alert(1)
        // if (this.userDetails) {
        //   alert(2)
        //   this.getfavlistwithcustomer();
        // }
    };
    Tab1Page.prototype.ionViewDidEnter = function () {
        this.appointmentlist = JSON.parse(localStorage.getItem("appointmentlist"));
        this.firstTimeLogin = localStorage.getItem("firststTimeLogin");
        if (this.appointmentlist) {
            this.afterlogin = false;
            this.aferappointment = true;
        }
        this.userDetails = JSON.parse(localStorage.getItem("userDetails"));
        console.log('appointlist', this.appointmentlist);
        if (this.userDetails) {
            this.getfavlistwithcustomer();
            this.afterlogin = true;
        }
        else {
            this.businessfavwithlist = [];
        }
    };
    Tab1Page.prototype.ionViewDidLeave = function () {
        this.firstTimeLogin = "no";
        localStorage.setItem("firststTimeLogin", "no");
    };
    Tab1Page.prototype.getfavlistwithoutcustomer = function () {
        var _this = this;
        this.businessService.favlistwithoutcustomer().subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.favwithoutlist = true;
                _this.favwithlist = false;
                _this.businessfavwithoutlist = res.data.user;
                console.log('favlist', _this.businessfavwithoutlist);
                for (var i = 0; i < _this.businessfavwithoutlist.length; i++) {
                    localStorage.setItem("businessData", JSON.stringify(_this.businessfavwithoutlist));
                    var maxRating = 5;
                    var apiRating = _this.businessfavwithoutlist[i].review_count;
                    _this.businessfavwithoutlist[i].ratingPercent = Math.floor((apiRating / maxRating) * 100) + '%';
                    if (_this.currentlocation) {
                        _this.businessfavwithoutlist[i].distance = _this.businessService.getDistanceFromLatLonInKm(_this.currentlocation.lat, _this.currentlocation.long, _this.businessfavwithoutlist[i].latitude, _this.businessfavwithoutlist[i].longitude);
                    }
                    // alert( this.businessList[i].ratingPercent)
                }
            }
        });
    };
    Tab1Page.prototype.getfavlistwithcustomer = function () {
        var _this = this;
        this.businessfavData = {
            "user_id": this.userDetails.id,
            "role_id": this.userDetails.role_id,
            "token": this.userDetails.token.original.token
        };
        this.businessService.favlistwithcustomer(this.businessfavData).subscribe(function (res) {
            console.log(res);
            if (res.status == "success") {
                _this.favwithlist = true;
                _this.favwithoutlist = false;
                _this.businessfavwithlist = res.data.user;
                console.log('favlists', _this.businessfavwithlist);
                for (var i = 0; i < _this.businessfavwithlist.length; i++) {
                    if (_this.currentlocation) {
                        _this.businessfavwithlist[i].distance = _this.businessService.getDistanceFromLatLonInKm(_this.currentlocation.lat, _this.currentlocation.long, _this.businessfavwithlist[i].latitude, _this.businessfavwithlist[i].longitude);
                    }
                    localStorage.setItem("businessData", JSON.stringify(_this.businessfavwithlist));
                    var maxRating = 5;
                    var apiRating = _this.businessfavwithlist[i].review_count;
                    _this.businessfavwithlist[i].ratingPercent = Math.floor((apiRating / maxRating) * 100) + '%';
                    // alert( this.businessList[i].ratingPercent)
                }
            }
        });
    };
    Tab1Page.prototype.getcategorylist = function () {
        var _this = this;
        this.businessService.categorylist().subscribe(function (res) {
            console.log('catglist', res);
            if (res.status == "success") {
                _this.categorylist = res.data.user;
                localStorage.setItem("categoryData", JSON.stringify(_this.categorylist));
                var categorylistlength = _this.categorylist.length / 2;
                console.log('length', categorylistlength);
                for (var i = 0; i < categorylistlength; i++) {
                    if (_this.categorylist[i].image != null) {
                        // if (i % 2 == 0) {
                        // console.log('lmnst', this.categorylist[i]);
                        // this.categorylist[i].image1 = this.categorylist[i].image;
                        // this.categorylist[i].name1 = this.categorylist[i].name;
                        // console.log('image1', this.customData.image1)
                        _this.customData.push(_this.categorylist[i]);
                        // }
                        // else if (i % 2 != 0) {
                        //   this.categorylist[i].image2 = this.categorylist[i].image;
                        //   this.categorylist[i].name2 = this.categorylist[i].name;
                        //   this.customData.push(this.categorylist[i]);
                        // }
                    }
                }
                for (var i = categorylistlength; i < _this.categorylist.length; i++) {
                    if (_this.categorylist[i].image != null) {
                        _this.categorylistDatas.push(_this.categorylist[i]);
                        console.log('catdata2', _this.categorylistData);
                    }
                }
            }
        });
    };
    Tab1Page.prototype.gotoexplorepage = function (items) {
        console.log('items', items);
        localStorage.setItem("categoryID", items.id);
        //  let navigationExtras: NavigationExtras = {
        //    queryParams: {
        //     categoryId: items.id
        //    } 
        //  };
        //this.router.navigate(['tab2']);
        this.navCtrl.navigateForward('/tabs/tab2');
        //console.log('businessct', this.categorybusinessDetails)
    };
    /* getBusinessList() {
       this.businessService.businessList().subscribe((res : Business)=>{
         console.log(res);
         if(res.status == "success"){
            this.businessList = res.data.user;
            for( let i = 0; i < this.businessList.length; i++ ){
             
               if(this.businessList[i].name != null) {
                
                 this.businessData.push(this.businessList[i]);
                 localStorage.setItem("businessData", JSON.stringify(this.businessData));
  
                 console.log(this.businessData);
                 var maxRating = 5;
                 var apiRating = this.businessList[i].review_count;
               this.businessList[i].ratingPercent = Math.floor((apiRating / maxRating) * 100)+'%';
                // alert( this.businessList[i].ratingPercent)
                
               }
            }
         }
       });
     }*/
    Tab1Page.prototype.getCategoryService = function () {
        var _this = this;
        this.categoryData.categoryid;
        this.businessService.category(this.categoryData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.categorys = res.data.user;
                console.log(_this.categorys);
            }
        });
    };
    /* goToNotificationsPage() {
       this.navCtrl.navigateForward('/notifications');
     }*/
    Tab1Page.prototype.onRateChange = function (event) {
        console.log('Your rate:', event);
        this.rating = event;
    };
    Tab1Page.prototype.goToDetailsPage = function (item) {
        console.log('item', item);
        var navigationExtras = {
            queryParams: {
                businessDetails: JSON.stringify(item)
            }
        };
        this.router.navigate(['details-page'], navigationExtras);
        console.log('business', this.businessDetails);
    };
    Tab1Page.prototype.Education = function () {
        var _this = this;
        this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 7 };
        this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.conditionbusinesslist = res.data.user;
                localStorage.setItem("conditionbusinesslisteducation", JSON.stringify(res.data.user));
                _this.navCtrl.navigateForward('/tabs/tab2');
            }
        });
    };
    Tab1Page.prototype.Salon = function () {
        var _this = this;
        this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 4 };
        this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.conditionbusinesslist = res.data.user;
                localStorage.setItem("conditionbusinesslistsalon", JSON.stringify(res.data.user));
                _this.navCtrl.navigateForward('/tabs/tab2');
            }
        });
    };
    Tab1Page.prototype.Medicine = function () {
        var _this = this;
        this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 3 };
        this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.conditionbusinesslist = res.data.user;
                _this.navCtrl.navigateForward('/tabs/tab2');
            }
        });
    };
    Tab1Page.prototype.Fitness = function () {
        var _this = this;
        this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 5 };
        this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.conditionbusinesslist = res.data.user;
                _this.navCtrl.navigateForward('/tabs/tab2');
            }
        });
    };
    Tab1Page.prototype.Health = function () {
        var _this = this;
        this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 12 };
        this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.conditionbusinesslist = res.data.user;
                _this.navCtrl.navigateForward('/tabs/tab2');
            }
        });
    };
    Tab1Page.prototype.Other = function () {
        var _this = this;
        this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 9 };
        this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.conditionbusinesslist = res.data.user;
                _this.navCtrl.navigateForward('/tabs/tab2');
            }
        });
    };
    Tab1Page.prototype.Professional = function () {
        var _this = this;
        this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 9 };
        this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.conditionbusinesslist = res.data.user;
                _this.navCtrl.navigateForward('/tabs/tab2');
            }
        });
    };
    Tab1Page.prototype.Goverment = function () {
        var _this = this;
        this.businessCategoryServiceData = { "categoryid": this.categorys.main_category_id = 2 };
        this.businessService.conditionBusinessList(this.businessCategoryServiceData).subscribe(function (res) {
            console.log(res);
            if (res.status == 'success') {
                _this.conditionbusinesslist = res.data.user;
                _this.navCtrl.navigateForward('/tabs/tab2');
            }
        });
    };
    Tab1Page.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
        { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
        { type: _services_business_service__WEBPACK_IMPORTED_MODULE_4__["BusinessService"] },
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
        { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"] }
    ]; };
    Tab1Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-tab1',
            template: __webpack_require__(/*! raw-loader!./tab1.page.html */ "./node_modules/raw-loader/index.js!./src/app/tab1/tab1.page.html"),
            styles: [__webpack_require__(/*! ./tab1.page.scss */ "./src/app/tab1/tab1.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_3__["TranslateService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _services_business_service__WEBPACK_IMPORTED_MODULE_4__["BusinessService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"],
            _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"]])
    ], Tab1Page);
    return Tab1Page;
}());



/***/ })

}]);
//# sourceMappingURL=tab1-tab1-module.js.map